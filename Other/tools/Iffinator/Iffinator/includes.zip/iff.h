#include "vector.h"
#include "convert.h"

/*************************\
**   IFF File Routines   **
**   For IFF Files used  **
**    in The Sims (tm)   **
**                       **
**    (C) ChEeTaH 2002   **
** www.thesimszone.co.uk **
\*************************/


//--------------Type Declarations--------------

typedef struct
        {
        AnsiString       Type;
        int              Offset;
        int              Size;
        AnsiString       Label;
        int              ID;
        int              TypeNo;
        int              DataOffset;
        int              DataSize;
        char            *Data;
        } CIFFType;

typedef struct
        {
        int                PaletteID;
        Graphics::TBitmap *Sprite;
        Graphics::TBitmap *Alpha;
        Graphics::TBitmap *ZBuffer;
        } CSprite;

typedef struct
        {
        int              Version;
        int              SpriteCount;
        int              PaletteID;
        vector<CSprite>  Sprites;
        } CSPR2Chunk;

typedef struct
        {
        int               Direction;
        int               Zoom;
        int               ItemCount;
        int               MinX;
        int               MinY;
        vector<int>       SPRID;
        vector<int>       SPRNo;
        vector<int>       pixelx;
        vector<int>       pixely;
        vector<int>       zbufx;
        vector<int>       flipped;
        vector<int>       zbufz;
        vector<int>       flags;
        vector<CSprite>   sprites;
        Graphics::TBitmap *GrpImage;
        } CDrawGroup;

typedef struct
        {
        int                Version;
        int                DGRPCount;
        vector<CDrawGroup> Groups;
        } CDGRPChunk;

typedef struct
        {
        DWORD                   Version;
        bool                    IsSub;
        WORD                    Master;
        WORD                    SubSect;
        DWORD                   GUID;
        WORD                    Price;
        int                     PreviewOffsetX;
        int                     PreviewOffsetY;        
        Graphics::TBitmap      *Preview;
        } COBJDChunk;

typedef struct
        {
        AnsiString         Name; // Unused for NPCs
        AnsiString         FileName;
        // Personality
        unsigned short     Neat, Outgoing, Active, Playful, Nice;
        unsigned short     PetQuiet, PetFriendly, PetPlayful, PetSmart, PetLoyal; // used to ease naming of pet skills
        // Skills
        unsigned short     Cooking, Mechanical, Charisma, Body, Logic, Creativity;
        unsigned short     HouseBreaking, Hunting, Tricks, Obedience, Furniture;
        //                         Dog,     Cat    Dog/Cat, Dog/Cat,    Unused 
        // Interests
        unsigned short     Travel, Money, Politics, Sixties, Weather, Sports, Music,
                           Outdoors, Exercise, Food, Parties, Style, Hollywood, Technology, Romance;
        unsigned short     Toys, Aliens, Pets, School; // Kids

        // Other
        unsigned short     Career, Promotion;
        bool               Adult;
        int                SimType; // 0=Sim, 1=NPC, 2=Dog, 3=Cat 
        int                Race;
        WORD               Zodiac;
        AnsiString         ZodiacStr;
        bool               Female;
        WORD               RelID;
        DWORD              CharID;
        int                Relations;

        int                FameScore, FameStars;

        AnsiString         Bio;
        Graphics::TBitmap  *Thumbnail;
        } CCharacter;

typedef struct
        {
        int                ID; // IFF ID number
        AnsiString         Name;
        int                FamID;
        int                MemberCount;
        vector<CCharacter> Members;
        int                Money;
        int                Value;
        bool               Homeless;
        int                House;
        int                Friends;
        } CFamily;

class TSingleStr : public TPersistent
{
public:
        unsigned char      Language;
        AnsiString         String;
        AnsiString         Note;
	virtual __fastcall TSingleStr(void);        
};
//---------------------------------------------------------------------------

__fastcall TSingleStr::TSingleStr(void) : TPersistent()
{
        Language = 0;
        String = "";
        Note = "";
}
//---------------------------------------------------------------------------

//--------------IFF Section--------------

vector<CIFFType> GetIFFTypes(AnsiString FileName)
{
vector<CIFFType> IFFTypes;
char *Buffer;
AnsiString TempStr;
TFileStream *IFFFile;

try
        {
        IFFFile = new TFileStream(FileName, fmOpenRead | fmShareDenyWrite);
        }
catch (...)
        {
        return IFFTypes;
        }

IFFFile->Seek(64, soFromBeginning);
IFFTypes.resize(0);
//Go through all types, write info in arrays
while (IFFFile->Position < IFFFile->Size)
        {
        IFFTypes.resize(IFFTypes.size() + 1);
        IFFTypes[IFFTypes.size() - 1].Offset = IFFFile->Position;

        Buffer = new char[4];
        TempStr.SetLength(4);
        TempStr = "";
        IFFFile->Read(Buffer, 4);
        TempStr = Buffer;
        TempStr.SetLength(4);
        IFFTypes[IFFTypes.size() - 1].Type = TempStr;
        delete Buffer;

        Buffer = new char[4];
        IFFFile->Read(Buffer, 4);
        IFFTypes[IFFTypes.size() - 1].Size = HexToInt(Buffer, 4);
        delete Buffer;

        if (IFFTypes[IFFTypes.size() - 1].Size <= 0)
                {
                // Error in file - delete last (current) entry
                IFFTypes.resize(IFFTypes.size() - 1);
                break;
                }

        Buffer = new char[2];
        IFFFile->Read(Buffer, 2);
        IFFTypes[IFFTypes.size() - 1].ID = HexToInt(Buffer, 2);
        delete Buffer;
        Buffer = new char[2];
        IFFFile->Read(Buffer, 2);
        IFFTypes[IFFTypes.size() - 1].TypeNo = HexToInt(Buffer, 2);
        delete Buffer;

        Buffer = new char[64];
        TempStr.SetLength(64);
        TempStr = "";
        IFFFile->Read(Buffer, 64);
        TempStr.SetLength(0);
        for (int i = 0; i < 64 && Buffer[i] != 0x00; i++)
                {
                TempStr.SetLength(i+1);
                TempStr[i+1] = Buffer[i];
                }
        IFFTypes[IFFTypes.size() - 1].Label = TempStr;
        delete Buffer;        
        
        //Read Data
        IFFTypes[IFFTypes.size() - 1].DataOffset = IFFTypes[IFFTypes.size() - 1].Offset + 76;
        IFFTypes[IFFTypes.size() - 1].DataSize = IFFTypes[IFFTypes.size() - 1].Size - 76;
        IFFTypes[IFFTypes.size() - 1].Data = new char[IFFTypes[IFFTypes.size() - 1].DataSize];
        IFFFile->Read(IFFTypes[IFFTypes.size() - 1].Data, IFFTypes[IFFTypes.size() - 1].DataSize);
        }

//------------Clean up------------

//int iHandle = IFFFile->Handle;
//FileClose(iHandle);
delete IFFFile;

return IFFTypes;
}
//---------------------------------------------------------------------------

CIFFType GetSingleType(AnsiString FileName, AnsiString Type, int ID)
{
CIFFType SingleType;
char *Buffer;
AnsiString TempStr;
TFileStream *IFFFile;

try
        {
        IFFFile = new TFileStream(FileName, fmOpenRead | fmShareDenyWrite);
        }
catch (...)
        {
        SingleType.Type = "";
        SingleType.Offset = -1;
        SingleType.Size = -1;
        SingleType.Label = "";
        SingleType.ID = -1;
        SingleType.TypeNo = -1;
        SingleType.DataOffset = -1;
        SingleType.DataSize = -1;
        return SingleType;
        }

IFFFile->Seek(64, soFromBeginning);
//Go through all types, write info in arrays
while (IFFFile->Position < IFFFile->Size &&
       (SingleType.Type != Type || SingleType.ID != ID))
        {
        SingleType.Offset = IFFFile->Position;

        Buffer = new char[4];
        TempStr.SetLength(4);
        TempStr = "";
        IFFFile->Read(Buffer, 4);
        TempStr = Buffer;
        TempStr.SetLength(4);
        SingleType.Type = TempStr;
        delete Buffer;
        
        Buffer = new char[4];
        IFFFile->Read(Buffer, 4);
        SingleType.Size = HexToInt(Buffer, 4);
        delete Buffer;

        Buffer = new char[2];
        IFFFile->Read(Buffer, 2);
        SingleType.ID = HexToInt(Buffer, 2);
        delete Buffer;

        if (SingleType.Type == Type && SingleType.ID == ID)
                {
                Buffer = new char[2];
                IFFFile->Read(Buffer, 2);
                SingleType.TypeNo = HexToInt(Buffer, 2);
                delete Buffer;

                Buffer = new char[64];
                TempStr.SetLength(64);
                TempStr = "";
                IFFFile->Read(Buffer, 64);
                TempStr.SetLength(0);
                for (int i = 0; i < 64 && Buffer[i] != 0x00; i++)
                        {
                        TempStr.SetLength(i+1);
                        TempStr[i+1] = Buffer[i];
                        }
                SingleType.Label = TempStr;
                delete Buffer;
                
                SingleType.DataOffset = SingleType.Offset + 76;
                SingleType.DataSize = SingleType.Size - 76;

                //Read Data
                SingleType.Data = new char[SingleType.DataSize];
                IFFFile->Read(SingleType.Data, SingleType.DataSize);
                }
        else
                {
                //Skip Data - 10 bytes have been read
                if (SingleType.Size > 75)
                        IFFFile->Seek(SingleType.Size - 10, soFromCurrent);
                else
                        {
                        // Error in file!
                        SingleType.Type = "";
                        SingleType.ID = -1;
                        break;
                        }
                }
        }
if (SingleType.Type != Type || SingleType.ID != ID)
        {
        SingleType.Type = "";
        SingleType.Offset = -1;
        SingleType.Size = -1;
        SingleType.Label = "";
        SingleType.ID = -1;
        SingleType.TypeNo = -1;
        SingleType.DataOffset = -1;
        SingleType.DataSize = -1;
//        delete SingleType.Data;
        }

//------------Clean up------------

//int iHandle = IFFFile->Handle;
//FileClose(iHandle);
delete IFFFile;

return SingleType;
}
//---------------------------------------------------------------------------

vector<CIFFType> GetTypes(AnsiString FileName, AnsiString Type)
{
vector<CIFFType> IFFTypes;
char *Buffer;
AnsiString TempStr;
TFileStream *IFFFile;

try
        {
        IFFFile = new TFileStream(FileName, fmOpenRead | fmShareDenyWrite);
        }
catch (...)
        {
        return IFFTypes;
        }

IFFFile->Seek(64, soFromBeginning);
IFFTypes.resize(0);
//Go through all types, write info in arrays
while (IFFFile->Position < IFFFile->Size)
        {
        Buffer = new char[4];
        TempStr.SetLength(4);
        TempStr = "";
        IFFFile->Read(Buffer, 4);
        TempStr = Buffer;
        TempStr.SetLength(4);
        delete Buffer;        
        if (TempStr == Type)
                {
                IFFTypes.resize(IFFTypes.size() + 1);
                IFFTypes[IFFTypes.size() - 1].Type = TempStr;
                IFFTypes[IFFTypes.size() - 1].Offset = IFFFile->Position - 4;

                Buffer = new char[4];
                IFFFile->Read(Buffer, 4);
                IFFTypes[IFFTypes.size() - 1].Size = HexToInt(Buffer, 4);
                delete Buffer;
                if (IFFTypes[IFFTypes.size() - 1].Size <= 0)
                        {
                        // error in file - break
                        IFFTypes.resize(IFFTypes.size() - 1);
                        break;
                        }

                Buffer = new char[2];
                IFFFile->Read(Buffer, 2);
                IFFTypes[IFFTypes.size() - 1].ID = HexToInt(Buffer, 2);
                delete Buffer;
                Buffer = new char[2];
                IFFFile->Read(Buffer, 2);
                IFFTypes[IFFTypes.size() - 1].TypeNo = HexToInt(Buffer, 2);
                delete Buffer;

                Buffer = new char[64];
                TempStr.SetLength(64);
                TempStr = "";
                IFFFile->Read(Buffer, 64);
                TempStr.SetLength(0);
                for (int i = 0; i < 64 && Buffer[i] != 0x00; i++)
                        {
                        TempStr.SetLength(i+1);
                        TempStr[i+1] = Buffer[i];
                        }
                IFFTypes[IFFTypes.size() - 1].Label = TempStr;
                delete Buffer;                

                //Read Data
                IFFTypes[IFFTypes.size() - 1].DataOffset = IFFTypes[IFFTypes.size() - 1].Offset + 76;
                IFFTypes[IFFTypes.size() - 1].DataSize = IFFTypes[IFFTypes.size() - 1].Size - 76;
                IFFTypes[IFFTypes.size() - 1].Data = new char[IFFTypes[IFFTypes.size() - 1].DataSize];
                IFFFile->Read(IFFTypes[IFFTypes.size() - 1].Data, IFFTypes[IFFTypes.size() - 1].DataSize);
                }
        else
                {
                Buffer = new char[4];
                IFFFile->Read(Buffer, 4);
                IFFFile->Seek(HexToInt(Buffer, 4) - 8, soFromCurrent);
                delete Buffer;
                }
        }

//------------Clean up------------

//int iHandle = IFFFile->Handle;
//FileClose(iHandle);
delete IFFFile;

return IFFTypes;
}
//---------------------------------------------------------------------------

//--------------SPR2 Section--------------

CSPR2Chunk ReadSPR2(AnsiString FileName, int ChunkID)
{
CSPR2Chunk Sprites;
CIFFType SPR2Data;
SPR2Data = GetSingleType(FileName, "SPR2", ChunkID);

if (SPR2Data.Type.UpperCase() != "SPR2")
        {
        return Sprites;
        }

//further initialization
int Version, SprCount, PaletteID, SprLoc;
TMemoryStream *SPRData = new TMemoryStream();
SPRData->Write(SPR2Data.Data, SPR2Data.DataSize);
SPRData->Seek(0, soFromBeginning);

        SPRData->Read(&Version, 4);
        SPRData->Read(&SprCount, 4);
        SPRData->Read(&PaletteID, 4);

        // Now check things
        if (Version != 1000)
                {
                Sprites.Version = -1;
                Sprites.SpriteCount = -1;
                Sprites.PaletteID = -1;
                delete SPRData;
                return Sprites; // whatever you want
                }
        if (SprCount == 0)
                {
                Sprites.Version = -1;
                Sprites.SpriteCount = -1;
                Sprites.PaletteID = -1;
                delete SPRData;
                return Sprites; // whatever you want
                }

        Sprites.Version = Version;
        Sprites.SpriteCount = SprCount;
        Sprites.Sprites.resize(SprCount);
        Sprites.PaletteID = PaletteID;

        for (int i = 0; i < SprCount; i++)
                {
                // Now go to the requested sprite
                SPRData->Seek((4*i) + 12, soFromBeginning);
                SPRData->Read(&SprLoc, 4);
                SPRData->Seek(SprLoc, soFromBeginning);

                WORD Width, Height, PaltID;
                unsigned long Flags;

                //At beginning of sprite: get size
                SPRData->Read(&Width, 2);
                SPRData->Read(&Height, 2);
                SPRData->Read(&Flags, 4);

                //Get Palette ID
                SPRData->Read(&PaltID, 2);

                SPRData->Seek(6, soFromCurrent); // These are indeed not very important

                //Set offset of Line data for later use
                //First load palette
                CIFFType Palette = GetSingleType(FileName, "PALT", PaltID);
                TMemoryStream *PaletteData = new TMemoryStream();
                if (Palette.Type.UpperCase() != "PALT")
                        {
                        Palette = GetSingleType(FileName, "PALT", PaletteID);
                        }
                if (Palette.Type.UpperCase() != "PALT")
                        {
                        delete PaletteData;
                        delete SPRData;
                        Sprites.Version = -1;
                        Sprites.SpriteCount = -1;
                        Sprites.PaletteID = -1;
                        return Sprites;
                        }
                PaletteData->SetSize(Palette.DataSize);
                PaletteData->Clear();
                PaletteData->Write(Palette.Data, Palette.DataSize);

                PaletteData->Seek(16, soFromBeginning); // You now ignore Version, Count, Unused and Unused (4 x 4 bytes)
                TColor PALT[256];
                char *Buffer;
                for (int j = 0; j < 256; j++)
                        {
                        Buffer = new char[3];
                        PaletteData->Read(Buffer, 3);
                        PALT[j] = RGB(Buffer[0], Buffer[1], Buffer[2]);
                        delete Buffer;
                        }

                int X, Y;
                BYTE Color;
                Y = 0;
                X = 0;
                Sprites.Sprites[i].Sprite = new Graphics::TBitmap;                
                Sprites.Sprites[i].Sprite->Width = Width;
                Sprites.Sprites[i].Sprite->Height = Height;
                //Clear image
                Sprites.Sprites[i].Sprite->Canvas->Pen->Color = clFuchsia;
                Sprites.Sprites[i].Sprite->Canvas->Brush->Color = clFuchsia;
                Sprites.Sprites[i].Sprite->Canvas->Rectangle(0, 0, Width, Height);
                Sprites.Sprites[i].Sprite->TransparentColor = clFuchsia;

                while (1)
                        {
                        WORD CurWord;
                        SPRData->Read(&CurWord, 2);
                        WORD opcode = CurWord >> 13;
                        WORD data = CurWord & 0x1fff;

                        switch (opcode)
                        {
                        case 0: // new line - 0x00
                                X = 0;
                                Y++;
                                break;
                        case 1: // that's Z-buffer, then Pixel - 0x20
                                for (;data;data--)
                                {
                                BYTE Zbuffer;
                                SPRData->Read(&Zbuffer, 1);
                                SPRData->Read(&Color, 1);
                                Sprites.Sprites[i].Sprite->Canvas->Pixels[X][Y] = PALT[Color];
                                X++;
                                }
                                SPRData->Seek((SPRData->Position)&1, soFromCurrent); // This is alignment
                                break;
                        case 2: // that's Z-buffer, then Pixel, then Alpha Channel - 0x40
                                for (;data;data--)
                                        {
                                        BYTE Zbuffer, Achannel;
                                        SPRData->Read(&Zbuffer, 1);
                                        SPRData->Read(&Color, 1);
                                        SPRData->Read(&Achannel, 1);
                                        Sprites.Sprites[i].Sprite->Canvas->Pixels[X][Y] = PALT[Color];
                                        X++;
                                        }
                                SPRData->Seek((SPRData->Position)&1, soFromCurrent); // This is alignment
                                break;
                        case 3: // skip pixels - 0x60
                                X += data;
                                break;
                        case 4: // skip lines - 0x80
                                X = 0;
                                Y++;
                                break;
                        case 5: // end of sprite - 0xA0
                                break;
                        case 6: // pixels only - 0xC0
                                for (;data;data--)
                                        {
                                        SPRData->Read(&Color, 1);
                                        Sprites.Sprites[i].Sprite->Canvas->Pixels[X][Y] = PALT[Color];
                                        X++;
                                        }
                                SPRData->Seek((SPRData->Position)&1, soFromCurrent);
                                break;
                        default: // error: invalid token
                                break;
                        }
                        if (opcode == 5)
                                break;
                        }
                delete PaletteData;
                }
        //Destroy open streams
        delete SPRData;

        return Sprites;
}
//---------------------------------------------------------------------------

CSPR2Chunk ReadSPR2(AnsiString FileName, CIFFType SPR2Data)
{
//Initialization
CSPR2Chunk Sprites;
DWORD Version, SprCount, PaletteID, SprLoc;
TMemoryStream *SPRData = new TMemoryStream();
SPRData->Write(SPR2Data.Data, SPR2Data.DataSize);
SPRData->Seek(0, soFromBeginning);

        SPRData->Read(&Version, 4);
        SPRData->Read(&SprCount, 4);
        SPRData->Read(&PaletteID, 4);

        // Now check things
        if (Version != 1000)
                {
                Sprites.Version = -1;
                Sprites.SpriteCount = -1;
                Sprites.PaletteID = -1;
                delete SPRData;
                return Sprites; // whatever you want
                }
        if (SprCount == 0)
                {
                Sprites.Version = -1;
                Sprites.SpriteCount = -1;
                Sprites.PaletteID = -1;
                delete SPRData;
                return Sprites; // whatever you want
                }

        Sprites.Version = Version;
        Sprites.SpriteCount = SprCount;
        Sprites.Sprites.resize(SprCount);
        Sprites.PaletteID = PaletteID;

        for (int i = 0; i < SprCount; i++)
                {
                // Now go to the requested sprite
                SPRData->Seek((4*i) + 12, soFromBeginning);
                SPRData->Read(&SprLoc, 4);
                SPRData->Seek(SprLoc, soFromBeginning);

                WORD Width, Height, PaltID;
                unsigned long Flags;

                //At beginning of sprite: get size
                SPRData->Read(&Width, 2);
                SPRData->Read(&Height, 2);
                SPRData->Read(&Flags, 4);

                //Get Palette ID
                SPRData->Read(&PaltID, 2);

                SPRData->Seek(6, soFromCurrent); // These are indeed not very important

                //Set offset of Line data for later use
                //First load palette
                CIFFType Palette = GetSingleType(FileName, "PALT", PaltID);

                if (Palette.Type.UpperCase() != "PALT")
                        {
                        Palette = GetSingleType(FileName, "PALT", PaletteID);
                        }
                if (Palette.Type.UpperCase() != "PALT")
                        {
                        delete SPRData;
                        Sprites.Version = -1;
                        Sprites.SpriteCount = -1;
                        Sprites.PaletteID = -1;
                        return Sprites;
                        }
                        
                TMemoryStream *PaletteData = new TMemoryStream();
                PaletteData->SetSize(Palette.DataSize);
                PaletteData->Clear();
                PaletteData->Write(Palette.Data, Palette.DataSize);

                PaletteData->Seek(16, soFromBeginning); // You now ignore Version, Count, Unused and Unused (4 x 4 bytes)
                TColor PALT[256];
                char *Buffer;
                for (int j = 0; j < 256; j++)
                        {
                        Buffer = new char[3];
                        PaletteData->Read(Buffer, 3);
                        PALT[j] = RGB(Buffer[0], Buffer[1], Buffer[2]);
                        delete Buffer;
                        }

                int X, Y;
                BYTE Color, ZBuffer, AChannel;
                Y = 0;
                X = 0;
                Sprites.Sprites[i].Sprite = new Graphics::TBitmap;
                Sprites.Sprites[i].Alpha = new Graphics::TBitmap;
                Sprites.Sprites[i].ZBuffer = new Graphics::TBitmap;
                Sprites.Sprites[i].Sprite->Width = Width;
                Sprites.Sprites[i].Sprite->Height = Height;
                //Clear image
                Sprites.Sprites[i].Sprite->Canvas->Pen->Color = clFuchsia;
                Sprites.Sprites[i].Sprite->Canvas->Brush->Color = clFuchsia;
                Sprites.Sprites[i].Sprite->Canvas->Rectangle(0, 0, Width, Height);
                Sprites.Sprites[i].Sprite->TransparentColor = clFuchsia;
                //Alpha/Zbuffer are the same as Sprite when empty
                Sprites.Sprites[i].Alpha->Assign(Sprites.Sprites[i].Sprite);
                Sprites.Sprites[i].ZBuffer->Assign(Sprites.Sprites[i].Sprite);


                while (1)
                        {
                        WORD CurWord;
                        SPRData->Read(&CurWord, 2);
                        WORD opcode = CurWord >> 13;
                        WORD data = CurWord & 0x1fff;

                        switch (opcode)
                        {
                        case 0: // new line - 0x00
                                X = 0;
                                Y++;
                                break;
                        case 1: // that's Z-buffer, then Pixel - 0x20
                                for (;data;data--)
                                {
                                SPRData->Read(&ZBuffer, 1);
                                Sprites.Sprites[i].ZBuffer->Canvas->Pixels[X][Y] = RGB(ZBuffer, ZBuffer, ZBuffer);
                                SPRData->Read(&Color, 1);
                                Sprites.Sprites[i].Sprite->Canvas->Pixels[X][Y] = PALT[Color];
                                Sprites.Sprites[i].Alpha->Canvas->Pixels[X][Y] = RGB(255, 255, 255);
                                X++;
                                }
                                SPRData->Seek((SPRData->Position)&1, soFromCurrent); // This is alignment
                                break;
                        case 2: // that's Z-buffer, then Pixel, then Alpha Channel - 0x40
                                for (;data;data--)
                                        {
                                        SPRData->Read(&ZBuffer, 1);
                                        Sprites.Sprites[i].ZBuffer->Canvas->Pixels[X][Y] = RGB(ZBuffer, ZBuffer, ZBuffer);
                                        SPRData->Read(&Color, 1);
                                        Sprites.Sprites[i].Sprite->Canvas->Pixels[X][Y] = PALT[Color];
                                        SPRData->Read(&AChannel, 1);
                                        Sprites.Sprites[i].Alpha->Canvas->Pixels[X][Y] = RGB((AChannel*8)-1, (AChannel*8)-1, (AChannel*8)-1);
                                        X++;
                                        }
                                SPRData->Seek((SPRData->Position)&1, soFromCurrent); // This is alignment
                                break;
                        case 3: // skip pixels - 0x60
                                X += data;
                                break;
                        case 4: // skip lines - 0x80
                                X = 0;
                                Y++;
                                break;
                        case 5: // end of sprite - 0xA0
                                break;
                        case 6: // pixels only - 0xC0
                                for (;data;data--)
                                        {
                                        SPRData->Read(&Color, 1);
                                        Sprites.Sprites[i].Sprite->Canvas->Pixels[X][Y] = PALT[Color];
                                        Sprites.Sprites[i].Alpha->Canvas->Pixels[X][Y] = RGB(255, 255, 255);                                        
                                        X++;
                                        }
                                SPRData->Seek((SPRData->Position)&1, soFromCurrent);
                                break;
                        default: // error: invalid token
                                break;
                        }
                        if (opcode == 5)
                                break;
                        }
                delete PaletteData;
                }
        //Destroy open streams
        delete SPRData;

        return Sprites;
}
//---------------------------------------------------------------------------

CSprite GetSprite(AnsiString FileName, int ChunkID, int SpriteNo, bool Flipped)
{
//First find SPR2 type in File
//initialization
CIFFType SPR2Data;
CSprite TheSprite;
SPR2Data = GetSingleType(FileName, "SPR2", ChunkID);

if (SPR2Data.Type.UpperCase() != "SPR2")
        {
        return TheSprite;
        }

//Initialization
DWORD Version, SprCount, PaletteID, SprLoc;
TMemoryStream *SPRData = new TMemoryStream();
SPRData->Write(SPR2Data.Data, SPR2Data.DataSize);
SPRData->Seek(0, soFromBeginning);

        SPRData->Read(&Version, 4);
        SPRData->Read(&SprCount, 4);
        SPRData->Read(&PaletteID, 4);

        // Now check things
        if (Version != 1000 || SprCount == 0 || SpriteNo >= SprCount)
                {
                delete SPRData;
                return TheSprite; // whatever you want
                }

        // Now go to the requested sprite
        SPRData->Seek(4*SpriteNo, soFromCurrent);
        SPRData->Read(&SprLoc, 4);
        SPRData->Seek(SprLoc, soFromBeginning);

        WORD Width, Height, PaltID;
        unsigned long Flags;

        //At beginning of sprite: get size
        SPRData->Read(&Width, 2);
        SPRData->Read(&Height, 2);
        SPRData->Read(&Flags, 4);

        //Get Palette ID
        SPRData->Read(&PaltID, 2);

        SPRData->Seek(6, soFromCurrent); // These are indeed not very important

        //Set offset of Line data for later use
        //First load palette
        CIFFType Palette = GetSingleType(FileName, "PALT", PaltID);

        if (Palette.Type.UpperCase() != "PALT")
                {
                Palette = GetSingleType(FileName, "PALT", PaletteID);
                TheSprite.PaletteID = PaletteID;
                }
        else
                {
                TheSprite.PaletteID = PaltID;
                }
                
        if (Palette.Type.UpperCase() != "PALT")
                {
                TheSprite.PaletteID = -1;
                delete SPRData;
                return TheSprite;
                }

        TMemoryStream *PaletteData = new TMemoryStream();
        PaletteData->SetSize(Palette.DataSize);
        PaletteData->Clear();
        PaletteData->Write(Palette.Data, Palette.DataSize);

        PaletteData->Seek(16, soFromBeginning); // You now ignore Version, Count, Unused and Unused (4 x 4 bytes)
        TColor PALT[256];
        char *Buffer;
        for (int j = 0; j < 256; j++)
                {
                Buffer = new char[3];
                PaletteData->Read(Buffer, 3);
                PALT[j] = RGB(Buffer[0], Buffer[1], Buffer[2]);
                delete Buffer;
                }

        TheSprite.Sprite = new Graphics::TBitmap;
        TheSprite.Sprite->Width = Width;
        TheSprite.Sprite->Height = Height;                
        TheSprite.Sprite->Canvas->Brush->Color = clFuchsia;
        TheSprite.Sprite->Canvas->Pen->Color = clFuchsia;
        TheSprite.Sprite->TransparentColor = clFuchsia;
        TheSprite.Sprite->Canvas->Rectangle(0, 0, Width, Height);
        int X, Y;
        BYTE Color;
        Y = 0;
        if (Flipped)
                X = Width - 1;
        else
                X = 0;

        while (1)
                {
                WORD CurWord;
                SPRData->Read(&CurWord, 2);
                WORD opcode = CurWord >> 13;
                WORD data = CurWord & 0x1fff;

                switch (opcode)
                {
                case 0: // new line - 0x00
                        if (Flipped)
                                X = Width - 1;
                        else
                                X = 0;
                        Y++;
                        break;
                case 1: // that's Z-buffer, then Pixel - 0x20
                        for (;data;data--)
                                {
                                BYTE Zbuffer;
                                SPRData->Read(&Zbuffer, 1);
                                SPRData->Read(&Color, 1);
                                TheSprite.Sprite->Canvas->Pixels[X][Y] = PALT[Color];
                                if (Flipped)
                                        X--;
                                else
                                        X++;
                                }
                        SPRData->Seek((SPRData->Position)&1, soFromCurrent); // This is alignment
                        break;
                case 2: // that's Z-buffer, then Pixel, then Alpha Channel - 0x40
                        for (;data;data--)
                                {
                                BYTE Zbuffer, Achannel;
                                SPRData->Read(&Zbuffer, 1);
                                SPRData->Read(&Color, 1);
                                SPRData->Read(&Achannel, 1);
                                TheSprite.Sprite->Canvas->Pixels[X][Y] = PALT[Color];
                                if (Flipped)
                                        X--;
                                else
                                        X++;
                                }
                        SPRData->Seek((SPRData->Position)&1, soFromCurrent); // This is alignment
                        break;
                case 3: // skip pixels - 0x60
                        if (Flipped)
                                X -= data;
                        else
                                X += data;
                        break;
                case 4: // skip lines - 0x80
                        if (Flipped)
                                X = Width - 1;
                        else
                                X = 0;
                        Y += data;
                        break;
                case 5: // end of sprite - 0xA0
                        break;
                case 6: // pixels only - 0xC0
                        for (;data;data--)
                                {
                                SPRData->Read(&Color, 1);
                                TheSprite.Sprite->Canvas->Pixels[X][Y] = PALT[Color];
                                if (Flipped)
                                        X--;
                                else
                                        X++;
                                }
                        SPRData->Seek((SPRData->Position)&1, soFromCurrent);
                        break;
                default: // error: invalid token
                        break;
                }
                if (opcode == 5)
                        break;
                }

        //Destroy open streams
        delete SPRData;
        delete PaletteData;
        return TheSprite;
}
//---------------------------------------------------------------------------

//--------------DGRP Section--------------

CDGRPChunk ReadDGRP(AnsiString FileName, int ChunkID)
{
CDGRPChunk DrawGroups;
//First find DGRP type in File
//initialization
CIFFType DGRPType;
DGRPType = GetSingleType(FileName, "DGRP", ChunkID);

if (DGRPType.Type.UpperCase() != "DGRP")
        {
        DrawGroups.Version = 0;
        DrawGroups.DGRPCount = 0;
        return DrawGroups;
        }

//Further initialization
TMemoryStream *DGRPData = new TMemoryStream();
WORD Version; DWORD GroupCount;
DGRPData->Write(DGRPType.Data, DGRPType.DataSize);
DGRPData->Seek(0, soFromBeginning);

        DGRPData->Read(&Version, 2);
        DGRPData->Read(&GroupCount, 4);

        if ((Version != 20004 && Version != 20000) || GroupCount == 0)
                {
                DrawGroups.Version = 0;
                DrawGroups.DGRPCount = 0;
                return DrawGroups;
                }

        DrawGroups.Version = Version;
        DrawGroups.DGRPCount = GroupCount;
        DrawGroups.Groups.resize(GroupCount);

        for (int i = 0; i < GroupCount; i++)
                {
                //Read Group data
                DWORD Direction, Zoom, SpriteCount;
                DGRPData->Read(&Direction, 4);
                DGRPData->Read(&Zoom, 4);
                DGRPData->Read(&SpriteCount, 4);
                DrawGroups.Groups[i].Direction = Direction;
                DrawGroups.Groups[i].Zoom = Zoom;
                DrawGroups.Groups[i].ItemCount = SpriteCount;

                //Read sprite info
                if (SpriteCount > 0)
                        {
                        DrawGroups.Groups[i].SPRID.resize(SpriteCount);
                        DrawGroups.Groups[i].SPRNo.resize(SpriteCount);
                        DrawGroups.Groups[i].pixelx.resize(SpriteCount);
                        DrawGroups.Groups[i].pixely.resize(SpriteCount);
                        DrawGroups.Groups[i].zbufx.resize(SpriteCount);
                        DrawGroups.Groups[i].flipped.resize(SpriteCount);
                        DrawGroups.Groups[i].zbufz.resize(SpriteCount);
                        DrawGroups.Groups[i].flags.resize(SpriteCount);
                        DrawGroups.Groups[i].sprites.resize(SpriteCount);

                        int XMinimum, YMinimum, firstspr, Left, Top, Right, Bottom;
                        firstspr = 0;
                        Left = 1024;
                        Top = 1024;
                        Right = -1024;
                        Bottom = -1024;

                        //Load sprite details
                        for (int j = 0; j < SpriteCount; j++)
                                {
                                DWORD SPRID, SPRNo;
                                signed long PixelX, PixelY, ZBufX, Flipped, ZBufZ, Flags;
                                bool FlipSprite;

                                DGRPData->Read(&SPRID, 4);
                                DGRPData->Read(&SPRNo, 4);
                                DGRPData->Read(&PixelX, 4);
                                DGRPData->Read(&PixelY, 4);
                                DGRPData->Read(&ZBufX, 4);
                                DGRPData->Read(&Flipped, 4);
                                DGRPData->Read(&ZBufZ, 4);
                                DGRPData->Read(&Flags, 4);

                                DrawGroups.Groups[i].SPRID[j] = SPRID;
                                DrawGroups.Groups[i].SPRNo[j] = SPRNo;
                                DrawGroups.Groups[i].pixelx[j] = PixelX;
                                DrawGroups.Groups[i].pixely[j] = PixelY;
                                DrawGroups.Groups[i].zbufx[j] = ZBufX;
                                DrawGroups.Groups[i].flipped[j] = Flipped;
                                DrawGroups.Groups[i].zbufz[j] = ZBufZ;
                                DrawGroups.Groups[i].flags[j] = Flags;

                                if (Flipped & 1)
                                        FlipSprite = true;
                                else
                                        FlipSprite = false;

                                DrawGroups.Groups[i].sprites[j] = GetSprite(FileName, SPRID, SPRNo, FlipSprite);
                                DrawGroups.Groups[i].sprites[j].Sprite->TransparentColor = clFuchsia;
                                DrawGroups.Groups[i].sprites[j].Sprite->Transparent = true;

                                //Calculate complete bitmap size
                                if (PixelX < 1024 && PixelX > -1024 && PixelY < 1024 && PixelY > -1024)
                                        {
                                        //valid offset
                                        if (PixelX < Left)
                                                {
                                                Left = PixelX;
                                                }
                                        if (PixelY - DrawGroups.Groups[i].sprites[j].Sprite->Height < Top)
                                                {
                                                Top = PixelY - DrawGroups.Groups[i].sprites[j].Sprite->Height;
                                                }
                                        if (PixelX + DrawGroups.Groups[i].sprites[j].Sprite->Width > Right)
                                                {
                                                Right = PixelX + DrawGroups.Groups[i].sprites[j].Sprite->Width;
                                                }
                                        if (PixelY > Bottom)
                                                {
                                                Bottom = PixelY;
                                                }
                                        }
                                }

                        //Read and add sprites - initialization
                        DrawGroups.Groups[i].GrpImage = new Graphics::TBitmap;
                        DrawGroups.Groups[i].MinX = Left;
                        DrawGroups.Groups[i].MinY = Top;
                        int XOffset, YOffset;

                        //Set Bitmap size
                        DrawGroups.Groups[i].GrpImage->Width = Right - Left;
                        DrawGroups.Groups[i].GrpImage->Height = Bottom - Top;
                        DrawGroups.Groups[i].GrpImage->TransparentColor = clFuchsia;
                        DrawGroups.Groups[i].GrpImage->Transparent = true;
                        DrawGroups.Groups[i].GrpImage->Canvas->Brush->Color = clFuchsia;
                        DrawGroups.Groups[i].GrpImage->Canvas->Pen->Color = clFuchsia;
                        DrawGroups.Groups[i].GrpImage->Canvas->Rectangle(0, 0, Right - Left, Bottom - Top);

                        //Insert Bitmaps
                        if (DrawGroups.Groups[i].Direction & 1 || DrawGroups.Groups[i].Direction & 64)
                                {
                                //reverse order
                                for (int j = SpriteCount - 1; j >= 0; j--)
                                        {
                                        if (DrawGroups.Groups[i].pixelx[j] < 1024 &&
                                            DrawGroups.Groups[i].pixelx[j] > -1024 &&
                                            DrawGroups.Groups[i].pixely[j] < 1024 &&
                                            DrawGroups.Groups[i].pixely[j] > -1024)
                                                {
                                                DrawGroups.Groups[i].sprites[j].Sprite->TransparentColor = clFuchsia;
                                                DrawGroups.Groups[i].sprites[j].Sprite->Transparent = true;

                                                DrawGroups.Groups[i].GrpImage->Canvas->Draw(DrawGroups.Groups[i].pixelx[j] - Left,
                                                                (DrawGroups.Groups[i].pixely[j] - DrawGroups.Groups[i].sprites[j].Sprite->Height) - Top,
                                                                DrawGroups.Groups[i].sprites[j].Sprite);
                                                }
                                        }
                                }
                        else
                                {
                                //normal order
                                for (int j = 0; j < SpriteCount; j++)
                                        {
                                        if (DrawGroups.Groups[i].pixelx[j] < 1024 &&
                                            DrawGroups.Groups[i].pixelx[j] > -1024 &&
                                            DrawGroups.Groups[i].pixely[j] < 1024 &&
                                            DrawGroups.Groups[i].pixely[j] > -1024)
                                                {
                                                DrawGroups.Groups[i].sprites[j].Sprite->TransparentColor = clFuchsia;
                                                DrawGroups.Groups[i].sprites[j].Sprite->Transparent = true;

                                                DrawGroups.Groups[i].GrpImage->Canvas->Draw(DrawGroups.Groups[i].pixelx[j] - Left,
                                                                (DrawGroups.Groups[i].pixely[j] - DrawGroups.Groups[i].sprites[j].Sprite->Height) - Top,
                                                                DrawGroups.Groups[i].sprites[j].Sprite);
                                                }
                                        }
                                }
                        }
                }
        return DrawGroups;
}
//---------------------------------------------------------------------------

CDGRPChunk ReadDGRP(AnsiString FileName, CIFFType DrawGroup)
{
//Initialization
CDGRPChunk DrawGroups;
TMemoryStream *DGRPData = new TMemoryStream();
WORD Version; DWORD GroupCount;
DGRPData->Write(DrawGroup.Data, DrawGroup.DataSize);
DGRPData->Seek(0, soFromBeginning);

        DGRPData->Read(&Version, 2);
        DGRPData->Read(&GroupCount, 4);

        if ((Version != 20004 && Version != 20000) || GroupCount == 0)
                {
                DrawGroups.Version = 0;
                DrawGroups.DGRPCount = 0;
                return DrawGroups;
                }

        DrawGroups.Version = Version;
        DrawGroups.DGRPCount = GroupCount;
        DrawGroups.Groups.resize(GroupCount);

        for (int i = 0; i < GroupCount; i++)
                {
                //Read Group data
                DWORD Direction, Zoom, SpriteCount;
                DGRPData->Read(&Direction, 4);
                DGRPData->Read(&Zoom, 4);
                DGRPData->Read(&SpriteCount, 4);
                DrawGroups.Groups[i].Direction = Direction;
                DrawGroups.Groups[i].Zoom = Zoom;
                DrawGroups.Groups[i].ItemCount = SpriteCount;

                //Read sprite info
                if (SpriteCount > 0)
                        {
                        DrawGroups.Groups[i].SPRID.resize(SpriteCount);
                        DrawGroups.Groups[i].SPRNo.resize(SpriteCount);
                        DrawGroups.Groups[i].pixelx.resize(SpriteCount);
                        DrawGroups.Groups[i].pixely.resize(SpriteCount);
                        DrawGroups.Groups[i].zbufx.resize(SpriteCount);
                        DrawGroups.Groups[i].flipped.resize(SpriteCount);
                        DrawGroups.Groups[i].zbufz.resize(SpriteCount);
                        DrawGroups.Groups[i].flags.resize(SpriteCount);
                        DrawGroups.Groups[i].sprites.resize(SpriteCount);                        

                        int XMinimum, YMinimum, firstspr, Left, Top, Right, Bottom;
                        firstspr = 0;
                        Left = 1024;
                        Top = 1024;
                        Right = -1024;
                        Bottom = -1024;

                        //Load sprite details
                        for (int j = 0; j < SpriteCount; j++)
                                {
                                DWORD SPRID, SPRNo;
                                signed long PixelX, PixelY, ZBufX, Flipped, ZBufZ, Flags;
                                bool FlipSprite;

                                DGRPData->Read(&SPRID, 4);
                                DGRPData->Read(&SPRNo, 4);
                                DGRPData->Read(&PixelX, 4);
                                DGRPData->Read(&PixelY, 4);
                                DGRPData->Read(&ZBufX, 4);
                                DGRPData->Read(&Flipped, 4);
                                DGRPData->Read(&ZBufZ, 4);
                                DGRPData->Read(&Flags, 4);

                                DrawGroups.Groups[i].SPRID[j] = SPRID;
                                DrawGroups.Groups[i].SPRNo[j] = SPRNo;
                                DrawGroups.Groups[i].pixelx[j] = PixelX;
                                DrawGroups.Groups[i].pixely[j] = PixelY;
                                DrawGroups.Groups[i].zbufx[j] = ZBufX;
                                DrawGroups.Groups[i].flipped[j] = Flipped;
                                DrawGroups.Groups[i].zbufz[j] = ZBufZ;
                                DrawGroups.Groups[i].flags[j] = Flags;

                                if (Flipped & 1)
                                        FlipSprite = true;
                                else
                                        FlipSprite = false;

                                DrawGroups.Groups[i].sprites[j] = GetSprite(FileName, SPRID, SPRNo, FlipSprite);
                                DrawGroups.Groups[i].sprites[j].Sprite->TransparentColor = clFuchsia;
                                DrawGroups.Groups[i].sprites[j].Sprite->Transparent = true;

                                //Calculate complete bitmap size
                                if (PixelX < 1024 && PixelX > -1024 && PixelY < 1024 && PixelY > -1024)
                                        {
                                        //valid offset
                                        if (PixelX < Left)
                                                {
                                                Left = PixelX;
                                                }
                                        if (PixelY - DrawGroups.Groups[i].sprites[j].Sprite->Height < Top)
                                                {
                                                Top = PixelY - DrawGroups.Groups[i].sprites[j].Sprite->Height;
                                                }
                                        if (PixelX + DrawGroups.Groups[i].sprites[j].Sprite->Width > Right)
                                                {
                                                Right = PixelX + DrawGroups.Groups[i].sprites[j].Sprite->Width;
                                                }
                                        if (PixelY > Bottom)
                                                {
                                                Bottom = PixelY;
                                                }
                                        }
                                }

                        //Read and add sprites - initialization
                        DrawGroups.Groups[i].GrpImage = new Graphics::TBitmap;
                        DrawGroups.Groups[i].MinX = Left;
                        DrawGroups.Groups[i].MinY = Top;                        
                        int XOffset, YOffset;

                        //Set Bitmap size
                        DrawGroups.Groups[i].GrpImage->Width = Right - Left;
                        DrawGroups.Groups[i].GrpImage->Height = Bottom - Top;
                        DrawGroups.Groups[i].GrpImage->TransparentColor = clFuchsia;
                        DrawGroups.Groups[i].GrpImage->Transparent = true;
                        DrawGroups.Groups[i].GrpImage->Canvas->Brush->Color = clFuchsia;
                        DrawGroups.Groups[i].GrpImage->Canvas->Pen->Color = clFuchsia;
                        DrawGroups.Groups[i].GrpImage->Canvas->Rectangle(0, 0, Right - Left, Bottom - Top);

                        //Insert Bitmaps
                        if (DrawGroups.Groups[i].Direction & 1 || DrawGroups.Groups[i].Direction & 64)
                                {
                                //reverse order
                                for (int j = SpriteCount - 1; j >= 0; j--)
                                        {
                                        if (DrawGroups.Groups[i].pixelx[j] < 1024 &&
                                            DrawGroups.Groups[i].pixelx[j] > -1024 &&
                                            DrawGroups.Groups[i].pixely[j] < 1024 &&
                                            DrawGroups.Groups[i].pixely[j] > -1024)
                                                {
                                                DrawGroups.Groups[i].sprites[j].Sprite->TransparentColor = clFuchsia;
                                                DrawGroups.Groups[i].sprites[j].Sprite->Transparent = true;

                                                DrawGroups.Groups[i].GrpImage->Canvas->Draw(DrawGroups.Groups[i].pixelx[j] - Left,
                                                                (DrawGroups.Groups[i].pixely[j] - DrawGroups.Groups[i].sprites[j].Sprite->Height) - Top,
                                                                DrawGroups.Groups[i].sprites[j].Sprite);

                                                }
                                        }
                                }
                        else
                                {
                                //normal order
                                for (int j = 0; j < SpriteCount; j++)
                                        {
                                        if (DrawGroups.Groups[i].pixelx[j] < 1024 &&
                                            DrawGroups.Groups[i].pixelx[j] > -1024 &&
                                            DrawGroups.Groups[i].pixely[j] < 1024 &&
                                            DrawGroups.Groups[i].pixely[j] > -1024)
                                                {
                                                DrawGroups.Groups[i].sprites[j].Sprite->TransparentColor = clFuchsia;
                                                DrawGroups.Groups[i].sprites[j].Sprite->Transparent = true;

                                                DrawGroups.Groups[i].GrpImage->Canvas->Draw(DrawGroups.Groups[i].pixelx[j] - Left,
                                                                (DrawGroups.Groups[i].pixely[j] - DrawGroups.Groups[i].sprites[j].Sprite->Height) - Top,
                                                                DrawGroups.Groups[i].sprites[j].Sprite);
                                                }
                                        }
                                }
                        }
                }
        return DrawGroups;
}
//---------------------------------------------------------------------------

CDrawGroup SingleDrawGroup(AnsiString FileName, int ChunkID, int GroupID)
{
CDrawGroup DrawGroup;
//First find DGRP type in File
//initialization
CIFFType DGRPType;
DGRPType = GetSingleType(FileName, "DGRP", ChunkID);

if (DGRPType.Type.UpperCase() != "DGRP")
        {
        DrawGroup.ItemCount = -1;
        return DrawGroup;
        }

//Further initialization
TMemoryStream *DGRPData = new TMemoryStream();
WORD Version; DWORD GroupCount;
DGRPData->Write(DGRPType.Data, DGRPType.DataSize);
DGRPData->Seek(0, soFromBeginning);

        DGRPData->Read(&Version, 2);
        DGRPData->Read(&GroupCount, 4);

        if ((Version != 20004 && Version != 20000) || GroupCount == 0 || GroupID > GroupCount)
                {
                DrawGroup.ItemCount = -1;                
                return DrawGroup;
                }

        for (int i = 0; i < GroupCount; i++)
                {
                if (i == GroupID)
                        {
                        //Read Group data - requested group found
                        DWORD Direction, Zoom, SpriteCount;

                        DGRPData->Read(&Direction, 4);
                        DGRPData->Read(&Zoom, 4);
                        DGRPData->Read(&SpriteCount, 4);
                        DrawGroup.Direction = Direction;
                        DrawGroup.Zoom = Zoom;
                        DrawGroup.ItemCount = SpriteCount;

                        //Read sprite info
                        if (SpriteCount > 0)
                                {
                                DrawGroup.SPRID.resize(SpriteCount);
                                DrawGroup.SPRNo.resize(SpriteCount);
                                DrawGroup.pixelx.resize(SpriteCount);
                                DrawGroup.pixely.resize(SpriteCount);
                                DrawGroup.zbufx.resize(SpriteCount);
                                DrawGroup.flipped.resize(SpriteCount);
                                DrawGroup.zbufz.resize(SpriteCount);
                                DrawGroup.flags.resize(SpriteCount);
                                DrawGroup.sprites.resize(SpriteCount);

                                int XMinimum, YMinimum, firstspr, Left, Top, Right, Bottom;
                                firstspr = 0;
                                Left = 1024;
                                Top = 1024;
                                Right = -1024;
                                Bottom = -1024;

                                //Load sprite details
                                for (int j = 0; j < SpriteCount; j++)
                                        {
                                        DWORD SPRID, SPRNo;
                                        signed long PixelX, PixelY, ZBufX, Flipped, ZBufZ, Flags;
                                        bool FlipSprite;

                                        DGRPData->Read(&SPRID, 4);
                                        DGRPData->Read(&SPRNo, 4);
                                        DGRPData->Read(&PixelX, 4);
                                        DGRPData->Read(&PixelY, 4);
                                        DGRPData->Read(&ZBufX, 4);
                                        DGRPData->Read(&Flipped, 4);
                                        DGRPData->Read(&ZBufZ, 4);
                                        DGRPData->Read(&Flags, 4);

                                        DrawGroup.SPRID[j] = SPRID;
                                        DrawGroup.SPRNo[j] = SPRNo;
                                        DrawGroup.pixelx[j] = PixelX;
                                        DrawGroup.pixely[j] = PixelY;
                                        DrawGroup.zbufx[j] = ZBufX;
                                        DrawGroup.flipped[j] = Flipped;
                                        DrawGroup.zbufz[j] = ZBufZ;
                                        DrawGroup.flags[j] = Flags;

                                        if (Flipped & 1)
                                                FlipSprite = true;
                                        else
                                                FlipSprite = false;

                                        DrawGroup.sprites[j] = GetSprite(FileName, SPRID, SPRNo, FlipSprite);
                                        DrawGroup.sprites[j].Sprite->TransparentColor = clFuchsia;
                                        DrawGroup.sprites[j].Sprite->Transparent = true;

                                        //Calculate complete bitmap size
                                        if (PixelX < 1024 && PixelX > -1024 && PixelY < 1024 && PixelY > -1024)
                                                {
                                                //valid offset
                                                if (PixelX < Left)
                                                        {
                                                        Left = PixelX;
                                                        }
                                                if (PixelY - DrawGroup.sprites[j].Sprite->Height < Top)
                                                        {
                                                        Top = PixelY - DrawGroup.sprites[j].Sprite->Height;
                                                        }
                                                if (PixelX + DrawGroup.sprites[j].Sprite->Width > Right)
                                                        {
                                                        Right = PixelX + DrawGroup.sprites[j].Sprite->Width;
                                                        }
                                                if (PixelY > Bottom)
                                                        {
                                                        Bottom = PixelY;
                                                        }
                                                }
                                        }

                                //Read and add sprites - initialization
                                DrawGroup.GrpImage = new Graphics::TBitmap;
                                DrawGroup.MinX = Left;
                                DrawGroup.MinY = Top;
                                int XOffset, YOffset;

                                //Set Bitmap size
                                DrawGroup.GrpImage->Width = Right - Left;
                                DrawGroup.GrpImage->Height = Bottom - Top;
                                DrawGroup.GrpImage->TransparentColor = clFuchsia;
                                DrawGroup.GrpImage->Transparent = true;
                                DrawGroup.GrpImage->Canvas->Brush->Color = clFuchsia;
                                DrawGroup.GrpImage->Canvas->Pen->Color = clFuchsia;
                                DrawGroup.GrpImage->Canvas->Rectangle(0, 0, Right - Left, Bottom - Top);

                                //Insert Bitmaps
                                if (DrawGroup.Direction & 1 || DrawGroup.Direction & 64)
                                        {
                                        //reverse order
                                        for (int j = SpriteCount - 1; j >= 0; j--)
                                                {
                                                if (DrawGroup.pixelx[j] < 1024 &&
                                                    DrawGroup.pixelx[j] > -1024 &&
                                                    DrawGroup.pixely[j] < 1024 &&
                                                    DrawGroup.pixely[j] > -1024)
                                                        {
                                                        DrawGroup.sprites[j].Sprite->TransparentColor = clFuchsia;
                                                        DrawGroup.sprites[j].Sprite->Transparent = true;

                                                        DrawGroup.GrpImage->Canvas->Draw(DrawGroup.pixelx[j] - Left,
                                                                        (DrawGroup.pixely[j] - DrawGroup.sprites[j].Sprite->Height) - Top,
                                                                        DrawGroup.sprites[j].Sprite);
                                                        }
                                                }
                                        }
                                else
                                        {
                                        //normal order
                                        for (int j = 0; j < SpriteCount; j++)
                                                {
                                                if (DrawGroup.pixelx[j] < 1024 &&
                                                    DrawGroup.pixelx[j] > -1024 &&
                                                    DrawGroup.pixely[j] < 1024 &&
                                                    DrawGroup.pixely[j] > -1024)
                                                        {
                                                        DrawGroup.sprites[j].Sprite->TransparentColor = clFuchsia;
                                                        DrawGroup.sprites[j].Sprite->Transparent = true;

                                                        DrawGroup.GrpImage->Canvas->Draw(DrawGroup.pixelx[j] - Left,
                                                                        (DrawGroup.pixely[j] - DrawGroup.sprites[j].Sprite->Height) - Top,
                                                                        DrawGroup.sprites[j].Sprite);
                                                        }
                                                }
                                        }
                                }
                        }
                else
                        {
                        //not requested group - skip
                        DWORD SprCount;
                        DGRPData->Seek(8, soFromCurrent);
                        DGRPData->Read(&SprCount, 4);
                        for (int j = 0; j < SprCount; j++)
                                {
                                DGRPData->Seek(32, soFromCurrent);
                                }
                        }
                }
        return DrawGroup;
}
//---------------------------------------------------------------------------

//--------------OBJD Section--------------

COBJDChunk GetOBJD(AnsiString FileName, CIFFType OBJDChunk)
{
COBJDChunk OBJD;
if (OBJDChunk.Type.UpperCase() != "OBJD")
        {
        return OBJD;
        }

TMemoryStream *OBJDData = new TMemoryStream();
OBJDData->Write(OBJDChunk.Data, OBJDChunk.DataSize);
OBJDData->Seek(0, soFromBeginning);

OBJDData->Read(&OBJD.Version, 4);
if (OBJD.Version != 138)
        {
        delete OBJDData;
        return OBJD;
        }

OBJDData->Seek(2, soFromCurrent);
WORD BaseGraphic;
OBJDData->Read(&BaseGraphic, 2);

OBJDData->Seek(6, soFromCurrent);
//Tree table ID --> FFFF if Subsection
WORD TreeTable;
OBJDData->Read(&TreeTable, 2);
if (TreeTable == 0xFFFF || TreeTable == -1)
        {
        OBJD.IsSub = true;
        }
else
        {
        OBJD.IsSub = false;
        }

OBJDData->Seek(4, soFromCurrent);
OBJDData->Read(&OBJD.Master, 2);
OBJDData->Read(&OBJD.SubSect, 2);

OBJDData->Seek(4, soFromCurrent);
//GUID
OBJDData->Read(&OBJD.GUID, 4);
OBJDData->Seek(4, soFromCurrent);
OBJDData->Read(&OBJD.Price, 2);

//Get preview
OBJDData->Seek(150, soFromBeginning);
WORD DGRPID;
OBJDData->Read(&DGRPID, 2);
CDrawGroup DGRP = SingleDrawGroup(FileName, DGRPID, 9);

OBJD.Preview = new Graphics::TBitmap;
if (DGRP.ItemCount == -1)
        {
        DGRP = SingleDrawGroup(FileName, BaseGraphic, 9);
        }

if (DGRP.ItemCount != -1)
        {
        OBJD.Preview->Assign(DGRP.GrpImage);
        OBJD.PreviewOffsetX = DGRP.MinX;
        OBJD.PreviewOffsetY = DGRP.MinY;
        }

//Clean up and return value
delete OBJDData;
return OBJD;
}
//---------------------------------------------------------------------------

Graphics::TBitmap *MakeOBJDPreview(WORD Master, vector<COBJDChunk> OBJDChunks, Graphics::TBitmap *DefaultBMP)
{
//first make right order of chunks
vector<COBJDChunk> SubChunks;
vector<bool> Occupied;

SubChunks.clear();
SubChunks.resize(0);
int Left, Top, Right, Bottom;
bool SubExists = false;
Left = 1024; Top = 1024; Right = -1024; Bottom = -1024;

for (int i = 0; i < OBJDChunks.size(); i++)
        {
        if (OBJDChunks[i].Master == Master && OBJDChunks[i].SubSect != 256 && OBJDChunks[i].SubSect != 65535)
                {
                SubExists = true;
                if (SubChunks.size() < OBJDChunks[i].SubSect + 1)
                        {
                        SubChunks.resize(OBJDChunks[i].SubSect + 1);
                        Occupied.resize(OBJDChunks[i].SubSect + 1);
                        }
                SubChunks[OBJDChunks[i].SubSect + 1] = OBJDChunks[i];
                Occupied[OBJDChunks[i].SubSect + 1] = true;

                if (OBJDChunks[i].PreviewOffsetX < Left)
                        Left = OBJDChunks[i].PreviewOffsetX;
                if (OBJDChunks[i].PreviewOffsetY < Top)
                        Top = OBJDChunks[i].PreviewOffsetY;
                if (OBJDChunks[i].PreviewOffsetX + OBJDChunks[i].Preview->Width > Right)
                        Right = OBJDChunks[i].PreviewOffsetX + OBJDChunks[i].Preview->Width;
                if (OBJDChunks[i].PreviewOffsetY + OBJDChunks[i].Preview->Height > Bottom)
                        Bottom = OBJDChunks[i].PreviewOffsetY + OBJDChunks[i].Preview->Height;
                }
        }

Graphics::TBitmap *TotalImage = new Graphics::TBitmap;

if (SubExists)
        {
        for (int i = 0; i < SubChunks.size(); i++)
                {
                if (Occupied[i] == true)
                        {
                        SubChunks[i].Preview->SaveToFile("C:\\Test.bmp");
                        //process/combine images of subchunks
                        SubChunks[i].Preview->TransparentColor = clFuchsia;
                        SubChunks[i].Preview->Transparent = true;

                        TotalImage->Canvas->Draw(SubChunks[i].PreviewOffsetX - Left,
                                        SubChunks[i].PreviewOffsetY - Top,
                                        SubChunks[i].Preview);
                        }
                }
        return TotalImage;
        }
else
        {
        return DefaultBMP;
        }
}
//---------------------------------------------------------------------------

vector<CCharacter> GetCharacters(AnsiString FileName, AnsiString CharDir, int SimsLanguage)
{
vector<CCharacter> Chars;

        CIFFType NBRSChunk;
        NBRSChunk = GetSingleType(FileName, "NBRS", 1);
        TMemoryStream *NBRSData = new TMemoryStream();

        DWORD NBRSVersion;
        NBRSData->Write(NBRSChunk.Data, NBRSChunk.DataSize);
        NBRSData->Seek(4, soFromBeginning);
        NBRSData->Read(&NBRSVersion, 4);
        NBRSData->Seek(8, soFromCurrent);
        // Character count is sometimes inaccurate so useless - hence skip 8

        char LastChar = 0x00;
        char *Buffer;
        while (LastChar == 0x00)
                {
                Buffer = new char[2];
                NBRSData->Read(Buffer, 1);
                LastChar = Buffer[0];
                delete Buffer;
                }
        NBRSData->Seek(-1, soFromCurrent);

        // Character number is NOT always accurate!!
//         for (int i = 0; i < (int)CharCount; i++)

        int i = 0;
        // Read 1 bit back at the end (because of 0x00 fillers)
        while (NBRSData->Position + 1 < NBRSData->Size)
                {
                Chars.resize(i + 1);
                CCharacter CurCharacter;

                // Unknown
                NBRSData->Seek(8, soFromCurrent);

                // Filename/NPC Name
                char LastChar;
                LastChar = 0xFF;
                AnsiString CurName;
                int j = 1;

                while (LastChar != 0x00)
                        {
                        Buffer = new char[1];
                        NBRSData->Read(Buffer, 1);
                        LastChar = Buffer[0];
                        if (LastChar != 0x00)
                                {
                                CurName.SetLength(j);
                                CurName[j] = LastChar;
                                j++;
                                }
                        delete Buffer;
                        }
                CurCharacter.FileName = CurName + ".iff";

                // Alignment
                if (NBRSData->Position & 1)
                        NBRSData->Seek(1, soFromCurrent);

                // 4 Empty
                NBRSData->Seek(4, soFromCurrent);

                // Character data version/flags
                Buffer = new char[4];
                NBRSData->Read(Buffer, 4);
                char Version;
                Version = Buffer[0];
                delete Buffer;

                if (Version != 0x00)
                        {
                        // Unknown/Unused
                        NBRSData->Seek(4, soFromCurrent);

                        // Skills/Personality
                        NBRSData->Read(&CurCharacter.Nice, 2);
                        CurCharacter.PetLoyal = CurCharacter.Nice;
                        NBRSData->Read(&CurCharacter.Active, 2);
                        CurCharacter.PetPlayful = CurCharacter.Active;
                        NBRSData->Seek(2, soFromCurrent);
                        NBRSData->Read(&CurCharacter.Playful, 2);
                        CurCharacter.PetSmart = CurCharacter.Playful;
                        NBRSData->Read(&CurCharacter.Outgoing, 2);
                        CurCharacter.PetFriendly = CurCharacter.Outgoing;
                        NBRSData->Read(&CurCharacter.Neat, 2);
                        CurCharacter.PetQuiet = CurCharacter.Neat;
                        NBRSData->Seek(4, soFromCurrent);

                        // Skills
                        NBRSData->Read(&CurCharacter.Cooking, 2);
                        CurCharacter.HouseBreaking = CurCharacter.Cooking;
                        CurCharacter.Hunting = CurCharacter.Cooking;
                        NBRSData->Read(&CurCharacter.Charisma, 2);
                        CurCharacter.Obedience = CurCharacter.Charisma;
                        NBRSData->Read(&CurCharacter.Mechanical, 2);
                        CurCharacter.Tricks = CurCharacter.Mechanical;

                        // Interests, Adults only
                        NBRSData->Read(&CurCharacter.Exercise, 2);
                        NBRSData->Read(&CurCharacter.Food, 2);
                        NBRSData->Read(&CurCharacter.Creativity, 2); // Skill
                        NBRSData->Read(&CurCharacter.Parties, 2);
                        // Skills
                        NBRSData->Read(&CurCharacter.Body, 2);
                        CurCharacter.Furniture = CurCharacter.Body;
                        NBRSData->Read(&CurCharacter.Logic, 2);

                        NBRSData->Seek(2, soFromCurrent); // Unused
                        NBRSData->Read(&CurCharacter.Style, 2);
                        NBRSData->Seek(10, soFromCurrent);
                        NBRSData->Read(&CurCharacter.Hollywood, 2); // Interest, Adults only
                        NBRSData->Seek(38, soFromCurrent);

                        // Interests (Different names for adults/children)
                        NBRSData->Read(&CurCharacter.Travel, 2);
                        CurCharacter.Toys = CurCharacter.Travel;
                        NBRSData->Read(&CurCharacter.Money, 2);
                        CurCharacter.Aliens = CurCharacter.Money;
                        NBRSData->Read(&CurCharacter.Politics, 2);
                        CurCharacter.Pets = CurCharacter.Politics;
                        NBRSData->Read(&CurCharacter.Sixties, 2);
                        CurCharacter.School = CurCharacter.Sixties;
                        // Adults and children
                        NBRSData->Read(&CurCharacter.Weather, 2);
                        NBRSData->Read(&CurCharacter.Sports, 2);
                        NBRSData->Read(&CurCharacter.Music, 2);
                        NBRSData->Read(&CurCharacter.Outdoors, 2);
                        // Adults only
                        NBRSData->Read(&CurCharacter.Technology, 2);
                        NBRSData->Read(&CurCharacter.Romance, 2);

                        // Career Path
                        NBRSData->Read(&CurCharacter.Career, 2);
                        // Promotion Level
                        NBRSData->Read(&CurCharacter.Promotion, 2);

                        // Age + Unknown
                        Buffer = new char[4];
                        NBRSData->Read(Buffer, 4);
                        CurCharacter.Adult = (Buffer[0] == 0x1B);
                        delete Buffer;

                        // Race
                        Buffer = new char[4];
                        NBRSData->Read(Buffer, 4);
                        if (Buffer[0] == 0x01)
                                CurCharacter.Race = 0; // Light
                        if (Buffer[0] == 0x03)
                                CurCharacter.Race = 1; // Medium
                        if (Buffer[0] == 0x02)
                                CurCharacter.Race = 2; // Dark
                        delete Buffer;

                        // Ghost/NPC + Skin thing(?)
                        NBRSData->Seek(4, soFromCurrent);

                        // Skin thing 2 + Unknown
                        NBRSData->Seek(2, soFromCurrent);

                        // Gender + Unknown
                        DWORD Gender;
                        NBRSData->Read(&Gender, 4);
                        switch ((int)Gender)
                        {
                        case 0:
                        default:
                                CurCharacter.SimType = 0;
                                CurCharacter.Female = false;
                                break;
                        case 1:
                                CurCharacter.SimType = 0;
                                CurCharacter.Female = true;
                                break;
                        case 2:
                                CurCharacter.SimType = 2;
                                CurCharacter.Female = false;
                                break;
                        case 3:
                                CurCharacter.SimType = 2;
                                CurCharacter.Female = true;
                                break;
                        case 4:
                                CurCharacter.SimType = 3;
                                CurCharacter.Female = false;
                                break;
                        case 5:
                                CurCharacter.SimType = 3;
                                CurCharacter.Female = true;
                                break;
                        }

                        // Haunt Level (2) + Ghost (2) + Unknown (2)
                        NBRSData->Seek(6, soFromCurrent);

                        // Zodiac
                        NBRSData->Read(&CurCharacter.Zodiac, 2);
                        switch(CurCharacter.Zodiac)
                        {
                        case 1:
                                CurCharacter.ZodiacStr = "Aries";
                                break;
                        case 2:
                                CurCharacter.ZodiacStr = "Taurus";
                                break;
                        case 3:
                                CurCharacter.ZodiacStr = "Gemini";
                                break;
                        case 4:
                                CurCharacter.ZodiacStr = "Cancer";
                                break;
                        case 5:
                                CurCharacter.ZodiacStr = "Leo";
                                break;
                        case 6:
                                CurCharacter.ZodiacStr = "Virgo";
                                break;
                        case 7:
                                CurCharacter.ZodiacStr = "Libra";
                                break;
                        case 8:
                                CurCharacter.ZodiacStr = "Scorpio";
                                break;
                        case 9:
                                CurCharacter.ZodiacStr = "Sagittarius";
                                break;
                        case 10:
                                CurCharacter.ZodiacStr = "Capricorn";
                                break;
                        case 11:
                                CurCharacter.ZodiacStr = "Aquarius";
                                break;
                        case 12:
                                CurCharacter.ZodiacStr = "Pisces";
                                break;
                        default:
                                CurCharacter.ZodiacStr = "Unknown (N/A)";
                                break;
                        }

                        // Unknown
                        NBRSData->Seek(18, soFromCurrent);

                        // Superstar data
                        if ((int)NBRSVersion >= (int)72)
                                {
                                WORD Fame;
                                NBRSData->Read(&Fame, 2);
                                CurCharacter.FameScore = (int)Fame;
                                NBRSData->Read(&Fame, 2);
                                CurCharacter.FameStars = (int)Fame;

                                NBRSData->Seek(2, soFromCurrent);
                                NBRSData->Seek(346, soFromCurrent);
                                }
                        else
                                {
                                CurCharacter.FameScore = -1;
                                CurCharacter.FameStars = -1;
                                }
                        }

                // All versions again
                // Relationship ID
                
                NBRSData->Read(&CurCharacter.RelID, 2);

                NBRSData->Read(&CurCharacter.CharID, 4);

                // Unknown/Unused 0xFFFF FFFF
                NBRSData->Seek(4, soFromCurrent);

                // Amount of relationships
                DWORD RelCount;
                NBRSData->Read(&RelCount, 4);
                CurCharacter.Relations = (signed int)RelCount;

                // Relationship table
                for (j = 0; j < (int)RelCount; j++)
                        {
                        // Unknown/Unused + Character ID
                        NBRSData->Seek(8, soFromCurrent);

                        // Amount of flags
                        DWORD Size;
                        NBRSData->Read(&Size, 4);

                        if ((int)Size <= 4)
                                {
                                // Relationships etc
                                NBRSData->Seek((int)Size*4, soFromCurrent);
                                }
                        else
                                {
                                // Error in relationship table, Relation missing
                                // Seek 4 back and break
                                NBRSData->Seek(-4, soFromCurrent);
                                break;
                                }
                        }

                // Check fillers (0x00)
                LastChar = 0x00;
                while (LastChar == 0x00 && NBRSData->Position < NBRSData->Size)
                        {
                        Buffer = new char[1];
                        NBRSData->Read(Buffer, 1);
                        LastChar = Buffer[0];
                        delete Buffer;
                        }
                // 0x01 of next character read - go back to before that
                NBRSData->Seek(-1, soFromCurrent);

                // Now check out file for name, bio and bitmap
                if (CharDir != "")
                        {
                        if (CharDir[CharDir.Length()] != '\\' && CharDir[CharDir.Length()] != '/')
                                CharDir = CharDir + "\\";
                        if (FileExists(CharDir + CurCharacter.FileName))
                                {
                                CIFFType NameBio;
                                NameBio = GetSingleType(CharDir + CurCharacter.FileName, "CTSS", 2000);

                                //Get all names, add to list
                                //Check if there are indeed just 2 strings (name+bio)
                                Buffer = new char[2];
                                Buffer[0] = NameBio.Data[2];
                                Buffer[1] = NameBio.Data[3];
                                if (HexCharToInt(Buffer, 2) >= 2)
                                        {
                                        //Valid - continue
                                        AnsiString Name, Bio;
                                        Name.SetLength(0);
                                        int Pos = 4;
                                        while ((unsigned int)NameBio.Data[Pos] != SimsLanguage && Pos < NameBio.DataSize)
                                                {
                                                Pos++;
                                                // Name
                                                while (NameBio.Data[Pos] != 0x00)
                                                        Pos++;
                                                // Bio
                                                Pos++;
                                                while (NameBio.Data[Pos] != 0x00)
                                                        Pos++;
                                                Pos++;
                                                }
                                        if (Pos >= NameBio.DataSize) // No language things available - read first strings
                                                Pos = 4;
                                        Pos++;
                                        
                                        do
                                                {
                                                //Read name
                                                Name.SetLength(Name.Length() + 1);
                                                Name[Name.Length()] = NameBio.Data[Pos];
                                                Pos++;
                                                }
                                        while (NameBio.Data[Pos] != 0x00 && NameBio.Data[Pos] != 0x0A);

                                        //Skip to Bio
                                        Pos++;
                                        while (NameBio.Data[Pos] != 0x00)
                                                Pos++;
                                        Pos += 2; // 0x00 and Language bytes

                                        Bio.SetLength(0);
                                        do
                                                {
                                                //Read name
                                                Bio.SetLength(Bio.Length() + 1);
                                                if (NameBio.Data[Pos] == '&')
                                                        {
                                                        Bio[Bio.Length()] = NameBio.Data[Pos];
                                                        Bio.SetLength(Bio.Length() + 1);
                                                        }
                                                Bio[Bio.Length()] = NameBio.Data[Pos];
                                                Pos++;
                                                }
                                        while (NameBio.Data[Pos] != 0x00 && NameBio.Data[Pos] != 0x0A);

                                        if (Name.Length() >= 1)
                                                {
                                                if (Name[1] >= 20 | Name.Length() > 1)
                                                        CurCharacter.Name = Name;
                                                else
                                                        CurCharacter.Name = "";
                                                }
                                        else
                                                CurCharacter.Name = "";

                                        if (Bio.Length() >= 1)
                                                {
                                                if (Bio[1] >= 20 || Bio.Length() > 1)
                                                        CurCharacter.Bio = Bio;
                                                else
                                                        CurCharacter.Bio = "";
                                                }
                                        else
                                                CurCharacter.Bio = "";

                                        CIFFType Portrait;

                                        Portrait = GetSingleType(CharDir + CurCharacter.FileName,
                                                        "BMP_", 2007);
                                        if (Portrait.DataSize == -1)
                                                Portrait = GetSingleType(CharDir + CurCharacter.FileName,
                                                        "BMP_", 2002);

                                        if (Portrait.DataSize >= 0)
                                                {
                                                CurCharacter.Thumbnail = new Graphics::TBitmap;
                                                TMemoryStream *PortraitStream;
                                                PortraitStream = new TMemoryStream();
                                                PortraitStream->Clear();
                                                PortraitStream->SetSize(Portrait.DataSize);
                                                PortraitStream->Write(Portrait.Data, Portrait.DataSize);
                                                PortraitStream->Seek(0, soFromBeginning);
                                                CurCharacter.Thumbnail->LoadFromStream(PortraitStream);
                                                if (Portrait.ID == 2002)
                                                        {
                                                        CurCharacter.Thumbnail->Width = 36;//(int)(CurCharacter.Thumbnail->Width/(float)3);
                                                        CurCharacter.Thumbnail->Canvas->Brush->Color = clBtnFace;
                                                        CurCharacter.Thumbnail->Canvas->BrushCopy(Rect(0,0,CurCharacter.Thumbnail->Width, CurCharacter.Thumbnail->Height),
                                                                CurCharacter.Thumbnail, Rect(0,0,CurCharacter.Thumbnail->Width, CurCharacter.Thumbnail->Height), CurCharacter.Thumbnail->Canvas->Pixels[0][0]);
                                                        }

                                                // delete PortraitStream;
                                                }
                                        }
                                else
                                        {
                                        CurCharacter.Name = "";
                                        CurCharacter.Bio = "";
                                        CurCharacter.SimType = 1;
                                        }
                                }
                        else
                                {
                                CurCharacter.Name = "";
                                CurCharacter.Bio = "";
                                CurCharacter.SimType = 1;
                                }
                        }
                Chars[i] = CurCharacter;
                i++;
                }
delete NBRSData;

return Chars;
}
//---------------------------------------------------------------------------

vector<CFamily> GetFamilies(AnsiString FileName, AnsiString CharDir, int SimsLanguage)
{
vector<CFamily> Families;
vector<CCharacter> Characters;
        // First get all characters in neighborhood
        Characters = GetCharacters(FileName, CharDir, SimsLanguage);

        // Now all the families...
        vector<CIFFType> FAMss;
        FAMss = GetTypes(FileName, "FAMs");

        Families.resize(FAMss.size());

        for (int i = 0; i < FAMss.size(); i++)
                {
                Families[i].ID = FAMss[i].ID;
                AnsiString CurName;
                // Read family name strings
                char LastChar;
                LastChar = 0xFF;
                for (int j = 5; LastChar != 0x00; j++)
                        {
                        LastChar = FAMss[i].Data[j];
                        if (LastChar != 0x00)
                                {
                                CurName.SetLength(j - 4);
                                CurName[j-4] = LastChar;
                                }
                        }
                Families[i].Name = CurName;

                CIFFType CurFami;
                CurFami = GetSingleType(FileName, "FAMI", FAMss[i].ID);

                if (CurFami.DataSize > 0)
                        {
                        TMemoryStream *FAMIStream = new TMemoryStream();
                        FAMIStream->SetSize(CurFami.DataSize);
                        FAMIStream->Write(CurFami.Data, CurFami.DataSize);
                        FAMIStream->Seek(12, soFromBeginning);

                        DWORD House;
                        FAMIStream->Read(&House, 4);
                        Families[i].House = (int)House;
                        DWORD FamID;
                        FAMIStream->Read(&FamID, 4);
                        Families[i].FamID = (int)FamID;

                        DWORD Money;
                        FAMIStream->Read(&Money, 4);
                        Families[i].Money = (signed int)Money;
                        DWORD Value;
                        FAMIStream->Read(&Value, 4);
                        Families[i].Value = (signed int)Value;

                        DWORD Friends;
                        FAMIStream->Read(&Friends, 4);
                        Families[i].Friends = (int)Friends;

                        char *Buffer;
                        Buffer = new char[4];
                        FAMIStream->Read(Buffer, 4);
                        char HomeLessChr = Buffer[0];
                        Families[i].Homeless = (HomeLessChr == 0x18);
                        delete Buffer;

                        DWORD MemberCount;
                        FAMIStream->Read(&MemberCount, 4);
                        Families[i].MemberCount = (int)MemberCount;
                        Families[i].Members.resize((int)MemberCount);
                        for (int j = 0; j < (int)MemberCount; j++)
                                {
                                // First, read member ID
                                DWORD CharID;
                                FAMIStream->Read(&CharID, 4);
                                // Find ID of Member, copy details
                                for (int k = 0; k < Characters.size(); k++)
                                        {
                                        if (Characters[k].CharID == CharID)
                                                {
                                                Families[i].Members[j] = Characters[k];
                                                break;
                                                }
                                        }
                                }
                        }
                else
                        {
                        Families.erase((CFamily *)i);
                        }
                }

return Families;
}
//---------------------------------------------------------------------------

TList *ReadStrs(CIFFType StringSet)
{
TList *Strings = new TList();
if (StringSet.DataSize > 0)
        {
        bool NullTerminated, Notes, LangCode;
        int Pos = 0, StrCount;
        unsigned char Char1 = StringSet.Data[0];
        unsigned char Char2 = StringSet.Data[1];
        
        // Get type
        if (Char1 == 0xFF && Char2 == 0xFF)
                {
                NullTerminated = true;
                Notes = false;
                LangCode = false;
                Pos = 2;
                }
        else if (Char1 == 0xFE && Char2 == 0xFF)
                {
                NullTerminated = true;
                Notes = true;
                LangCode = false;
                Pos = 2;
                }
        else if (Char1 == 0xFD && Char2 == 0xFF)
                {
                NullTerminated = true;
                Notes = true;
                LangCode = true;
                Pos = 2;
                }
        else
                {
                NullTerminated = false;
                Notes = false;
                LangCode = false;
                Pos = 0;
                }

        char *Temp;
        Temp = new char[2];
        Temp[0] = StringSet.Data[Pos++];
        Temp[1] = StringSet.Data[Pos++];
        if (!NullTerminated)
                StrCount = HexToInt(Temp, 2);
        else
                StrCount = HexCharToInt(Temp, 2);
        delete Temp;

        for (int i = 0; i < StrCount && Pos < StringSet.DataSize; i++)
                {
                TSingleStr *CurStr = new TSingleStr();
                if (!NullTerminated)
                        {
                        int StrLen;
                        StrLen = (unsigned)StringSet.Data[Pos++];
                        CurStr->String.SetLength(StrLen);
                        for (int j = 1; j <= StrLen; j++)
                                CurStr->String[j] = StringSet.Data[Pos++];
                        }
                else
                        {
                        if (LangCode)
                                CurStr->Language = (unsigned)StringSet.Data[Pos++];
                        int StartPos = Pos;
                        while (StringSet.Data[Pos] != 0x00)
                                {
                                CurStr->String.SetLength((Pos - StartPos) + 1);
                                CurStr->String[(Pos - StartPos) + 1] = StringSet.Data[Pos++];
                                }
                        Pos++; // Move past 0x00 byte
                        if (Notes)
                                {
                                int StartPos = Pos;
                                while (StringSet.Data[Pos] != 0x00)
                                        {
                                        CurStr->Note.SetLength((Pos - StartPos) + 1);
                                        CurStr->Note[(Pos - StartPos) + 1] = StringSet.Data[Pos++];
                                        }
                                Pos++; // Move past 0x00 byte
                                }
                        }
                Strings->Add((void *)CurStr);
                }
        }
return Strings;
}
