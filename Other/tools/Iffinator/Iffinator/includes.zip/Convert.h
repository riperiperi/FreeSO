#include "math.h"

char *IntToHexChar(int Number, bool LittleEndian)
{
unsigned char *Result = new unsigned char[5];
AnsiString STR = "00000000";
AnsiString STRInv = IntToHex(Number,8);
        if (LittleEndian)
                {
                STRInv = STRInv.UpperCase();
                for (int i = 1; i <= 8; i=i+2)
                        {
                        STR[i] = STRInv[8-i];
                        STR[i+1] = STRInv[9-i];
                        }
                }
        else
                STR = STRInv;

        for (int j = 0; j < 4; j++)
                {
                Result[j] = 0;

                if (STR[(j*2)+1] == '0') {Result[j] = 0*16;}
                if (STR[(j*2)+1] == '1') {Result[j] = 1*16;}
                if (STR[(j*2)+1] == '2') {Result[j] = 2*16;}
                if (STR[(j*2)+1] == '3') {Result[j] = 3*16;}
                if (STR[(j*2)+1] == '4') {Result[j] = 4*16;}
                if (STR[(j*2)+1] == '5') {Result[j] = 5*16;}
                if (STR[(j*2)+1] == '6') {Result[j] = 6*16;}
                if (STR[(j*2)+1] == '7') {Result[j] = 7*16;}
                if (STR[(j*2)+1] == '8') {Result[j] = 8*16;}
                if (STR[(j*2)+1] == '9') {Result[j] = 9*16;}
                if (STR[(j*2)+1] == 'A') {Result[j] = 10*16;}
                if (STR[(j*2)+1] == 'B') {Result[j] = 11*16;}
                if (STR[(j*2)+1] == 'C') {Result[j] = 12*16;}
                if (STR[(j*2)+1] == 'D') {Result[j] = 13*16;}
                if (STR[(j*2)+1] == 'E') {Result[j] = 14*16;}
                if (STR[(j*2)+1] == 'F') {Result[j] = 15*16;}

                if (STR[(j*2)+2] == '0') {Result[j] = Result[j] + 0;}
                if (STR[(j*2)+2] == '1') {Result[j] = Result[j] + 1;}
                if (STR[(j*2)+2] == '2') {Result[j] = Result[j] + 2;}
                if (STR[(j*2)+2] == '3') {Result[j] = Result[j] + 3;}
                if (STR[(j*2)+2] == '4') {Result[j] = Result[j] + 4;}
                if (STR[(j*2)+2] == '5') {Result[j] = Result[j] + 5;}
                if (STR[(j*2)+2] == '6') {Result[j] = Result[j] + 6;}
                if (STR[(j*2)+2] == '7') {Result[j] = Result[j] + 7;}
                if (STR[(j*2)+2] == '8') {Result[j] = Result[j] + 8;}
                if (STR[(j*2)+2] == '9') {Result[j] = Result[j] + 9;}
                if (STR[(j*2)+2] == 'A') {Result[j] = Result[j] + 10;}
                if (STR[(j*2)+2] == 'B') {Result[j] = Result[j] + 11;}
                if (STR[(j*2)+2] == 'C') {Result[j] = Result[j] + 12;}
                if (STR[(j*2)+2] == 'D') {Result[j] = Result[j] + 13;}
                if (STR[(j*2)+2] == 'E') {Result[j] = Result[j] + 14;}
                if (STR[(j*2)+2] == 'F') {Result[j] = Result[j] + 15;}
                }
        return Result;
}
//---------------------------------------------------------------------------

__int64 HexCharToInt(char *Buffer, int Bytes)
{
//Little Endian (Right = Biggest)
//Reads from left to right (most LEFT # is x*256^0)
__int64 Result = 0;
unsigned char Character;
        if (Bytes > 8)
                {return -1;}
        for (int i = 0; i < Bytes; i++)
                {
                Character = Buffer[i];
                Result = Result + (Character*Power(256,i));
                }
        return Result;
}
//---------------------------------------------------------------------------

__int64 HexToInt(char *Buffer, int Bytes)
{
//Big Endian (Left = Biggest)
//Reads from right to left (most RIGHT # is x*256^0)
__int64 Result = 0;
unsigned char Character;
        if (Bytes > 8)
                {return -1;}
        for (int i = 0; i < Bytes; i++)
                {
                Character = Buffer[Bytes - 1 - i];
                Result = Result + (Character*Power(256,i));
                }
        return Result;
}
//---------------------------------------------------------------------------

unsigned int RGBToInt(AnsiString ColorStr)
{
unsigned int Result = 0;
int Value;
        if (ColorStr.Length() != 6)
                {
                MessageDlg("Invalid color.", mtError, TMsgDlgButtons() << mbOK, 0);
                return 0;
                }
        ColorStr = ColorStr.UpperCase();
        
        for (int i = 6; i > 0; i = i-2)
                {
                if (ColorStr[i] == '0') {Value = 0;}
                else if (ColorStr[i] == '1') {Value = 1;}
                else if (ColorStr[i] == '2') {Value = 2;}
                else if (ColorStr[i] == '3') {Value = 3;}
                else if (ColorStr[i] == '4') {Value = 4;}
                else if (ColorStr[i] == '5') {Value = 5;}
                else if (ColorStr[i] == '6') {Value = 6;}
                else if (ColorStr[i] == '7') {Value = 7;}
                else if (ColorStr[i] == '8') {Value = 8;}
                else if (ColorStr[i] == '9') {Value = 9;}
                else if (ColorStr[i] == 'A') {Value = 10;}
                else if (ColorStr[i] == 'B') {Value = 11;}
                else if (ColorStr[i] == 'C') {Value = 12;}
                else if (ColorStr[i] == 'D') {Value = 13;}
                else if (ColorStr[i] == 'E') {Value = 14;}
                else if (ColorStr[i] == 'F') {Value = 15;}
                else    {
                        MessageDlg("Invalid color.", mtError, TMsgDlgButtons() << mbOK, 0);
                        return 0;
                        }

                if (ColorStr[i-1] == '0') {Value = Value + (0*16);}
                else if (ColorStr[i-1] == '1') {Value = Value + (1*16);}
                else if (ColorStr[i-1] == '2') {Value = Value + (2*16);}
                else if (ColorStr[i-1] == '3') {Value = Value + (3*16);}
                else if (ColorStr[i-1] == '4') {Value = Value + (4*16);}
                else if (ColorStr[i-1] == '5') {Value = Value + (5*16);}
                else if (ColorStr[i-1] == '6') {Value = Value + (6*16);}
                else if (ColorStr[i-1] == '7') {Value = Value + (7*16);}
                else if (ColorStr[i-1] == '8') {Value = Value + (8*16);}
                else if (ColorStr[i-1] == '9') {Value = Value + (9*16);}
                else if (ColorStr[i-1] == 'A') {Value = Value + (10*16);}
                else if (ColorStr[i-1] == 'B') {Value = Value + (11*16);}
                else if (ColorStr[i-1] == 'C') {Value = Value + (12*16);}
                else if (ColorStr[i-1] == 'D') {Value = Value + (13*16);}
                else if (ColorStr[i-1] == 'E') {Value = Value + (14*16);}
                else if (ColorStr[i-1] == 'F') {Value = Value + (15*16);}
                else    {
                        MessageDlg("Invalid color.", mtError, TMsgDlgButtons() << mbOK, 0);
                        return 0;
                        }

                if (i == 6)
                        {Result = Result + (Value*Power(256,2));}
                if (i == 4)
                        {Result = Result + (Value*Power(256,1));}
                if (i == 2)
                        {Result = Result + (Value*Power(256,0));}
                }
        return Result;
}
//---------------------------------------------------------------------------

AnsiString ColorToRGBStr(TColor Color)
{
AnsiString ColorStr1, ColorStr2;

        ColorStr1 = IntToHex(ColorToRGB(Color), 6);
        ColorStr2 = ColorStr1;
        for (int i = 1; i <= 6; i = i + 2)
                {
                ColorStr2[i] = ColorStr1[6-i];
                ColorStr2[i+1] = ColorStr1[6-(i-1)];
                }
        return ColorStr2;
}
//---------------------------------------------------------------------------

AnsiString InvString(AnsiString String)
{
AnsiString TempStr;
TempStr.SetLength(String.Length());

try
        {
        for (int i = 1; i <= String.Length(); i++)
                {
                TempStr[(String.Length() - i) + 1] = String[i];
                }
        return TempStr;
        }
catch (...)
        {
        return String + " Invert error (" + TempStr + ")";
        }
}
