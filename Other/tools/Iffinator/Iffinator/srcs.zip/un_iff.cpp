#include "iff.h"
#include <stdio.h>
#include <iostream>
#include <string.h>

static inline bool is_dump(char **args, simIFF::Entry &e)
{
	if (args[1] == 0) {
		// no resource list, dump everything except rsmp, XXXX
		if (e.type("rsmp")) return false;
		if (e.type("XXXX")) return false;
		return true;
	}
	while (*++args != 0) if (e.type(*args)) return true;	// matched
	return false;	// no match
}

static inline int dump(char **args, simIFF::Entry &e, FILE *toc)
{
	if (!is_dump(args, e)) return 0;
	int namelen = strlen(*args);
	char name[namelen + 1 + 4 + 5 + 1 + 3 + 1 + 11];
	// probably the flags are not needed...
	sprintf(name, "%s/%.4s_%5.5d_%3.3x",
			*args, e.type(), e.id(), e.flags());
	FILE *out = fopen(name, "w");
	if (out == 0) {
		printf("Could not open <<<%s>>>\n", name);
		return 0;
	}
	if (toc != 0) {
		fprintf(toc, "%s\t%.4s %d %o %s\n",
			name + namelen + 1,
			e.type(), e.id(), e.flags(), e.name());
	}
	std::istream *in = e.stream();
	char buf[1024];
	int len;
	while ((len = in->read(buf, sizeof buf).gcount()) > 0) {
		fwrite(buf, len,1, out);
	}
	delete in;
	fclose(out);
	return 1;
}

int main(int argc, char **argv)
{
	if (argc < 3) {
		printf("Usage: %s filename directory [resource ...]\n", argv[0]);
		return 1;
	}
	simIFF in(argv[1]);
	if (in.err()) {
		printf("Could not open IFF file\n");
		return 1;
	}
	switch (in.validate()) {
	case simIFF::no_rsmp:
		printf("%s has no rsmp resource\n", argv[1]);
		break;
	case simIFF::invalid:
		printf("%s failed to validate\n", argv[1]);
		break;
	case simIFF::validated:
		break;
	}
	char name[strlen(argv[2]) + 1 + 4 + 1];
	sprintf(name, "%s/.toc", argv[2]);
	FILE *toc = fopen(name, "w");
	int copied = 0;
	for (int i = 0; i < in.entries(); ++i) {
		copied += dump(&argv[2], in[i], toc);
	}
	fclose(toc);
	if (copied == 0) remove(name);
	return 0;
}
