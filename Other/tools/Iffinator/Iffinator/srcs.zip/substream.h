#ifndef __SIMS_substream_h
#define __SIMS_substream_h

#include <iostream>

class substream : public std::streambuf, public std::istream,
	public virtual std::ios
{
	std::istream *m_source;	// basis istream
	unsigned int m_offset;	// offset within basis stream
	unsigned int m_length;	// length within basis stream
	unsigned int m_tell;	// current seek pointer
public:
	substream(std::istream *source, int base, int len)
	:	std::istream(this), std::ios(this),
		m_source(source), m_offset(base), m_length(len), m_tell(0)
	{ init(this); }
	~substream(void) { }

	// seek
	// virtual streampos seekpos(streampos pos, int which);
	virtual std::streampos seekoff(std::streamoff, std::ios::seekdir, int);

	// buffer area
	// virtual streambuf *setbuf(char *memory, int len);

	// sync
	virtual int sync(void);

protected:
	virtual int underflow();
	virtual int overflow(int = EOF);
	// virtual int pbackfail(int);
};

#endif // __SIMS_substream_h
