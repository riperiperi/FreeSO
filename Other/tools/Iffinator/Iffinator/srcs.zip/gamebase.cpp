#include "gamebase.h"
#include <fstream>

/*  The LRUstreambuf has an underlying ifstream that can be closed and
    re-opened without loss of synchronization.  The status is maintained
    in the LRUstreambuf and the ifstream is just used to read and write.
    The LRUstreambufs maintain themselves in a least-recently-used order
    and if there are too many ifstreams allocated, it will steal one
    that hasn't been used in a while and re-use it for the current access.
    in this way, all the data remains accessable, but the number of open
    files is limited.
*/

class LRUstreambuf : public streambuf, public virtual ios
{
	static LRUstreambuf *m_head, *m_tail;	// LRU queue
	static int m_avail;	// how many more streams we can allocate
	static LRUstreambuf *m_steal;	// where to steal next stream
	int ref(void); void unref(void);
	friend class LRUlist;
	LRUstreambuf *m_prev, *m_next; // LRU links
	char *m_filename;	// name of associated file
	std::ifstream *m_source; // basis istream
	unsigned int m_tell;	// current seek pointer
public:
	LRUstreambuf(char *file)
	:	m_prev(0), m_next(0), m_source(0), m_tell(0)
	{
		size_t len = strlen(file) + 1;
		memcpy(m_filename = new char[len], file, len);
		ref();	// open file initially, set status
	}
	~LRUstreambuf(void) { unref(); }

	// seek
	// virtual streampos seekpos(streampos pos, int which);
	virtual streampos seekoff(streamoff, ios::seek_dir, int);

	// buffer area
	// virtual streambuf *setbuf(char *memory, int len);

	// sync
	virtual int sync(void);

protected:
	virtual int underflow();
	virtual int overflow(int = EOF);
	// virtual int pbackfail(int);
};

class LRUstreambase : virtual public ios
{
	LRUstreambuf my_buf;
protected:
	LRUstreambase(char *file)
	:	my_buf(file)
	{ init(&my_buf); }
public:
	LRUstreambuf *rdbuf(void) { return &my_buf; }
};

class LRUstream : public LRUstreambase, public std::istream
{
public:
	LRUstream(char *file);
};


LRUstreambuf *LRUstreambuf::m_head;	// head of LRU queue
LRUstreambuf *LRUstreambuf::m_tail;	// tail of LRU queue
int LRUstreambuf::m_avail = 100;	// how many more streams we can allocate
LRUstreambuf *LRUstreambuf::m_steal;	// where to steal next stream

int LRUstreambuf::ref(void)
{
	// put the streambuf at the head of the list
	// and give it an underlying file stream
	if (m_head == this) {
		// already at head of list, nothing to do
	} else if (m_head == 0) {
		// first one
		m_head = this, m_tail = this;
	} else {
		// remove from list
		if (m_prev) m_prev->m_next = m_next;
		if (m_next) m_next->m_prev = m_prev;
		if (m_tail == this) m_tail = m_prev;
		if (m_steal == this) m_steal = m_prev;
		// add at head
		m_prev = 0, m_next = m_head;
		m_head = this;
	}
	if (m_source) return 1;	// already has a stream attached
	std::ifstream *fin;
	if (m_avail > 0) {
		--m_avail;
		fin = new std::ifstream();
	} else {
		// TODO: reuse when necessary
		if (m_steal == 0) m_steal = m_tail;
		fin = m_steal->m_source;
		m_steal->m_source = 0;
		m_steal = m_steal->m_prev;
		fin->close();
	}
	fin->open(m_filename, ios::in|ios::nocreate);
	if (fin->good()) { m_source = fin; return 1; }
	// oops, couldn't (re-)open file...
	setstate(ios::badbit|ios::failbit);
	delete fin; ++m_avail;
	return 0;
}

void LRUstreambuf::unref(void)
{
	// remove from list
	if (m_prev) m_prev->m_next = m_next;
	if (m_next) m_next->m_prev = m_prev;
	if (m_head == this) m_head = m_next;
	if (m_tail == this) m_tail = m_prev;
	if (m_steal == this) m_steal = m_prev;
	// release any stream back to the pool
	if (m_source != 0) {
		delete m_source;
		++m_avail;
	}
	delete[] m_filename;
}

int LRUstreambuf::overflow(int x)
{
	// put is exhausted; provide new output area
	// only support input (for now?)
	return EOF;
}

int LRUstreambuf::underflow(void)
{
	// get is exhausted; provide more input
	if (base() == 0) {	// no current allocation
		if (allocate() == EOF) return EOF;
	} else {
		if (in_avail()) return (unsigned char) *gptr();
	}
	if (!ref()) return EOF;
#if 0
	// can we hijack the underlying streambuf to fill
	// our buffer directly without any copying?
	streambuf *sb = m_source->rdbuf();
	// cout << "got underflow streambuf at " << (void*)sb << endl;
#else
	m_source->seekg(m_tell);
	int len = m_source->read(base(), blen()).gcount();
	if (len == 0) {
		setg(0, 0, 0);
		return EOF;
	}
#endif
	m_tell += len;
	setg(base(), base(), base() + len);
	return (unsigned char) *gptr();
}

streampos LRUstreambuf::seekoff(streamoff off, ios::seek_dir from, int which)
{
	streampos here = m_tell - in_avail();
	switch (from) {
	case ios::beg:
		here = off;
		break;
	case ios::cur:
		// fast-path for tellg
		if (off == 0) return here;
		here += off;
		break;
	case ios::end:
		if (!ref()) return EOF;
		here = m_source->rdbuf()->seekoff(off, from, which);
		break;
	}
	if (here < m_tell && here >= m_tell - (egptr() - eback())) {
		// new position is within buffer, adjust pointer
		setg(eback(), egptr() - (m_tell - here), egptr());
	} else {
		// new position is outside buffer, force underflow
		m_tell = here, setg(0, 0, 0);
	}
	return here;
}

int LRUstreambuf::sync(void)
{
	m_tell -= in_avail();
	setg(0, 0, 0);
	return 0;
}

LRUstream::LRUstream(char *file)
:	LRUstreambase(file)
{ }

std::istream *GameBase::fileStream(char *name)
{
	return new LRUstream(name);
}
