#ifndef __SIMS_auto_ptr_h
#define __SIMS_auto_ptr_h

/* The AUTO_PTR macro creates a class that contains a pointer to the
   type given.  The object attached to the pointer is automatically
   deleted when the pointer goes out of scope (or is in a class that
   is deleted, same thing).  Otherwise, it acts just like a pointer
   to the object; it may be dereferenced, passed to a function, or
   whatever.  It is intended that there be only _one_ AUTO_PTR for
   a dynamic object; if two AUTO_PTRs refer the same object, the
   program will probably crash when the second one goes out of scope
   and tries to delete the object again.  If you want to transfer
   ownership of an object to a different AUTO_PTR, assign NULL to
   the AUTO_PTR losing ownership.
*/

#define AUTO_PTR(NAME, TYPE) \
class NAME \
{ \
	typedef TYPE _type; \
	_type *ptr; \
	NAME &operator=(const NAME &obj);/* not permitted */ \
public: \
	inline NAME(void) : ptr(0) {} \
	inline NAME(_type *obj) : ptr(obj) {} \
	inline NAME(const NAME &obj) : ptr(obj.ptr) { } \
	inline ~NAME(void) { delete ptr; } \
	inline _type *operator=(_type *p) { return ptr = p; } \
	inline operator bool(void) const { return ptr != 0; } \
	inline _type &operator*(void) const { return *ptr; } \
	inline _type *operator->(void) const { return ptr; } \
	inline operator _type*(void) const { return ptr; } \
}

#endif // __SIMS_auto_ptr_h
