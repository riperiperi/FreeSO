#include "iff.h"
#include "iff_carr.h"
#include <stdio.h>

static void dumpCARR(simIFF::Entry &e)
{
	simIFF_CARR t(e.stream());
	printf("%s\n", t.name());
	for (int l = 1; l <= t.levels(); ++l) {
		printf("%d ", t[l-1].friends());
		printf("%d ", t[l-1].cooking()/100);
		printf("%d ", t[l-1].mechanical()/100);
		printf("%d ", t[l-1].charisma()/100);
		printf("%d ", t[l-1].body()/100);
		printf("%d ", t[l-1].logic()/100);
		printf("%d ", t[l-1].creativity()/100);
		printf("%d ", t[l-1].unknown1());
		printf("%d ", t[l-1].unknown2());
		printf("%d ", t[l-1].unknown3());
		printf("%d ", -(t[l-1].hunger()));
		printf("%d ", -(t[l-1].comfort()));
		printf("%d ", -(t[l-1].hygiene()));
		printf("%d ", -(t[l-1].bladder()));
		printf("%d ", -(t[l-1].energy()));
		printf("%d ", -(t[l-1].fun()));
		printf("%d ", -(t[l-1].social()));
		printf("%d ", t[l-1].salary());
		printf("%d ", t[l-1].start());
		printf("%d ", t[l-1].end());
		printf("%d ", t[l-1].car());
		printf("%s\n", t[l-1].name());
	}
}

int main(int argc, char **argv)
{
	if (argc != 2) {
		printf("Usage: %s filename\n", argv[0]);
		return 1;
	}
	simIFF in(argv[1]);
	if (in.err()) {
		printf("Could not open IFF file\n");
		return 1;
	}
	switch (in.validate()) {
	case simIFF::no_rsmp:
		fprintf(stderr, "%s has no rsmp resource\n", argv[1]);
		break;
	case simIFF::invalid:
		fprintf(stderr, "%s failed to validate\n", argv[1]);
		break;
	case simIFF::validated:
		break;
	}
	for (int i = 0; i < in.entries(); ++i) {
		if (in[i].type("CARR")) dumpCARR(in[i]);
	}
	return 0;
}
