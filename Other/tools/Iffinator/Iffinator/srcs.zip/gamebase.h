#ifndef __SIMS_gamebase_h
#define __SIMS_gamebase_h

#include <iosfwd>

// file cache
class GameBase {
public:
	static std::istream *fileStream(char *name);
};

#endif // __SIMS_gamebase_h
