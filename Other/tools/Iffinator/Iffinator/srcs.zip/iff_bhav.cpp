#include "iff_bhav.h"
#include <iostream>

class remember_to_delete_istream {
	std::istream *m_s;
public:
	remember_to_delete_istream(std::istream *s) : m_s(s) {}
	std::istream *operator->(void)		{ return m_s; }
	~remember_to_delete_istream(void)	{ delete m_s; }
};
simIFF_BHAV::simIFF_BHAV(std::istream *p_s, unsigned char *h)
:	m_instructions(0), m_count(0)
{
	remember_to_delete_istream s(p_s);
	unsigned char header[20];
	if (h == 0) h = header;
	if (s->read((char*)h, 12).gcount() != 12) return;
	m_hdr = 12;
	m_sig = (h[1]<<8) | h[0];
	int cnt;
	switch (m_sig) {
	default:
		return;
	case 0x8000: case 0x8001:
		cnt = (h[3]<<8) | h[2];
		m_locals = 0;	// no locals in code; added in 8002?
		m_params = 4;	// I can't find this in header; always 4?
		m_fld1 = 0, m_fld2 = 0;	// TODO find these
		break;
	case 0x8002:
		cnt = (h[3]<<8) | h[2];
		m_locals = (h[7]<<8) | h[6];
		m_params = h[5];
		m_fld1 = h[4];
		m_fld2 = (((((h[11]<<8) | h[10])<<8) | h[9])<<8) | h[8];
		break;
	case 0x8003:
		// h[2] == 0, 3 (once), 16 (twice)
		// h[3] == 0..4		params
		// h[4] == 0..10	locals
		// h[5..8] == 1..36, 39, 41, 42, 43, ... 0x69
		// h[9..12] == count
		h[12] = s->get(), m_hdr = 13;
		cnt = (((((h[12]<<8) | h[11])<<8) | h[10])<<8) | h[9];
		m_locals = h[4];
		m_params = h[3];
		m_fld1 = h[2];
		m_fld2 = (((((h[8]<<8) | h[7])<<8) | h[6])<<8) | h[5];
		break;
	}
	m_count = cnt;
	if (cnt <= 0 || cnt > 253) return;
	std::streampos size = cnt * 12;
	m_instructions = new unsigned char[size];
	if (s->read((char*)m_instructions, size).gcount() != size) {
		delete m_instructions;
		m_instructions = 0;
	}
}

simIFF_BHAV::~simIFF_BHAV(void)
{
	delete m_instructions;
}
