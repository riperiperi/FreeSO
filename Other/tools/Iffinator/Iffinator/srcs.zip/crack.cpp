#include "crack.h"
#include <iostream>
using std::cerr;
using std::endl;
#include <stdio.h>

crack::~crack(void)
{
	delete m_in;
}

unsigned int crack::GetLen(void)
{
	std::streampos here = m_in->tellg();
	if (here == std::streampos(-1)) return here;	// not seekable
	std::streampos len = m_in->seekg(0, std::ios::end).tellg();
	m_in->seekg(here);
	return len;
}

int crack::isEOF(void)
{
	int c = m_in->get();
	if (c == EOF) return 1;
	m_in->unget();
	return 0;
}

int crack::getBits(int howmany)
{
	int v = 0;
	if (m_bits >= howmany) {
		// take from current byte
		v <<= howmany;
		v |= m_byte>>(8 - howmany);
		m_byte <<= howmany;
		m_bits -= howmany;
		return v;
	}
	// need more than in current byte
	// take however many bits remaining
	v <<= m_bits;
	v |= m_byte>>(8 - m_bits);
	howmany -= m_bits;
	m_bits = 0;
	while (howmany >= 8) {
		// take bits in chunks of eight
		v <<= 8;
		v |= m_in->get();
		howmany -= 8;
	}
	if (howmany > 0) {
		// take part of the next byte
		v <<= howmany;
		m_bits = (8 - howmany);
		v |= (m_byte = m_in->get())>>m_bits;
		m_byte <<= howmany;
	}
	return v;
}

static char defaultWidths[4] = { 6, 11, 21, 32 };
static char *widths = defaultWidths;

void crack::setFieldWidths(char *w)
{
	widths = w;
}

static inline void fldDumper(int c, int bits, std::istream *in)
{
	std::streampos here = in->tellg();
	printf("LOOK:");
	if (bits > 0) {
		putchar(' ');
		for (int i = 0; i < bits; ++i) {
			putchar((c&0x80) != 0 ? '1' : '0');
			c <<= 1;
		}
	}
	for (int i = 0; i < 5; ++i) {
		putchar(' ');
		c = in->get();
		for (int j = 0; j < 8; ++j) {
			putchar((c&0x80) != 0 ? '1' : '0');
			c <<= 1;
		}
	}
	putchar('\n');
	in->seekg(here);
}

int crack::getField(void)
{
	if (getBits(1) == 0) return 0;
	int width = getBits(2);
	width = widths[width];
	if (width == 0) {
		printf("UNKNOWN FIELD WIDTH ENCOUNTERED\n");
		exit(-1);
	}
	int t = getBits(width);
	return t | (0 - (t&(1<<(width-1))));
}

// skip a token
void crack::skipToken(const char *token)
{
	// does nothing in binary mode
}

float crack::getFloat(void)
{
	if (getBits(1) == 0) return 0;
	int width = getBits(2);
	width = widths[width];
	if (width == 0) {
		printf("UNKNOWN FIELD WIDTH ENCOUNTERED\n");
		exit(-1);
	}
	int t = getBits(width);
	if (width == 32) return *(float*)&t;
	// cout << "LOOK: " << width << "-bit value of " << hex << t << dec;
	// cout << " as float";
	// cout << endl;
	t <<= 32 - width;
	return *(float*)&t;
}

// a four-byte integer
int crack::readBit(void)
{
	return getBits(1);
}

int crack::readByte(void)
{
	return m_in->get();
}

// print a two-byte integer
short crack::printShort(char *fmt)
{
	int v = readShort();
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	if (fmt == 0) fmt = "short %d\n";
	printf(fmt, v);
	return v;
}

// print a four-byte integer
int crack::printInt(char *fmt)
{
	int v = readInt();
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	if (fmt == 0) fmt = "int %d\n";
	printf(fmt, v);
	return v;
}

// print an IEEE short floating point value
float crack::printFloat(char *fmt)
{
	float v = readFloat();
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	if (fmt == 0) fmt = "float %g\n";
	printf(fmt, v);
	return v;
}

// print a string and delete it
static void printStr(char *str, char *fmt)
{
	if (fmt == 0) fmt = "<<<%s>>>\n";
	printf(fmt, str);
	delete[] str;
}

// print a string and delete it
void crack::printString(int len, char *fmt)
{
	char *v = readString(len);
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	printStr(v, fmt);
}

// print a Pascal-stype counted string
void crack::printCountString(char *fmt)
{
	char *v = readCountString();
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	printStr(v, fmt);
}

// print a counted string using a two-byte length
void crack::printShortString(char *fmt)
{
	char *v = readShortString();
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	printStr(v, fmt);
}

// print a string terminated by a null
void crack::printNullString(char *fmt)
{
	char *v = readNullString();
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	printStr(v, fmt);
}

// print an even-length string
void crack::printEvenString(char *fmt)
{
	char *v = readEvenString();
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	printStr(v, fmt);
}

// print a hex string
void crack::printHex(int count, const char *prefix)
{
	if (prefix == 0) prefix = "hex";
	printf("%s", prefix);
	while (--count >= 0) printf(" %2.2X", m_in->get());
	putchar('\n');
}

#if 0
void crack::printBits(char *fmt = 0, int cnt = 10)
{
	int value = readInt(in);
	if (in->fail()) { printf("FILE BAD\n"); exit(0); }
	if (fmt == 0) fmt = "bits";
	printf(fmt);
	for (; cnt >= 0; --cnt) putchar(' '), putchar(((value>>cnt)&1) + '0');
	printf(" %d\n", value);
}
#endif

// an IEEE short floating point value
float crack::readFloat(void)
{
	int t = readInt();
	return *(float*)&t;
}

// extract a string of known length
char *crack::readString(int len)
{
	char *p = new char[len + 1];
	for (int i = 0; i < len; ++i) p[i] = m_in->get();
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	p[len] = '\0';
	return p;
}

// a Pascal-stype counted string
char *crack::readCountString(void)
{
	// extract Pascal-like counted string
	return readString(m_in->get());
}

// a counted string using a two-byte length
char *crack::readShortString(void)
{
	// extract string with two-byte count
	return readString(readShort());
}

// a string terminated by a null
char *crack::readNullString(void)
{
	std::streampos here = m_in->tellg();
	int len = 0, c;
	while ((c = m_in->get()) != 0 && c != EOF) ++len;
	//if (len == 0) return 0;
	m_in->seekg(here);
	char *v = readString(len);
	m_in->get();	// remove null
	return v;
}

char *crack::readEvenString(void)
{
	char *v = readNullString();
	// move the stream to a multiple of two
	if (m_in->tellg() & 1) m_in->get();
	return v;
}

// crack a file containing little-endian numbers
// a two-byte integer
short crackLittle::readShort(void)
{
	unsigned char a, b;
	a = m_in->get(), b = m_in->get();
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	return (b<<8) | a;
}

// a four-byte integer
int crackLittle::readInt(void)
{
	unsigned char a, b, c, d;
	a = m_in->get(), b = m_in->get(), c = m_in->get(), d = m_in->get();
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	return (((((d<<8) | c)<<8) | b)<<8) | a;
}

// crack a file containing little-endian numbers
// a two-byte integer
short crackBig::readShort(void)
{
	unsigned char a, b;
	a = m_in->get(), b = m_in->get();
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	return (a<<8) | b;
}

// a four-byte integer
int crackBig::readInt(void)
{
	unsigned char a, b, c, d;
	a = m_in->get(), b = m_in->get(), c = m_in->get(), d = m_in->get();
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	return (((((a<<8) | b)<<8) | c)<<8) | d;
}

// crack a file containing ASCII numbers
int crackASCII::isEOF(void)
{
	int c = m_in->get();
	if (c == '\r') c = m_in->get();
	if (c == '\n') c = m_in->get();
	if (c == EOF) return 1;
	m_in->unget();
	return 0;
}

// skip a token
void crackASCII::skipToken(const char *token)
{
	int c = m_in->get();
	if (c == '\r') c = m_in->get();
	if (c == '\n') c = m_in->get();
	while (c == ' ') c = m_in->get();
	while (*token != '\0') {
		if (c != *token) {
			m_in->unget();
			return;
		}
		c = m_in->get();
		++token;
	}
}

// a one-byte integer
int crackASCII::readByte(void)
{
	short v;
	*m_in >> v;
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	return v;
}

// a two-byte integer
short crackASCII::readShort(void)
{
	short v;
	*m_in >> v;
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	return v;
}

// a four-byte integer
int crackASCII::readInt(void)
{
	int v;
	*m_in >> v;
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	return v;
}

// a four-byte integer
float crackASCII::readFloat(void)
{
	float v;
	*m_in >> v;
	if (m_in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	return v;
}

// string types
static inline char *read_string(std::istream *in)
{
	int len = 0, c;
	if ((c = in->get()) == '\r') c = in->get();
	if (c != '\n') in->unget();
	std::streampos here = in->tellg();
	while ((c = in->get()) != '\r' && c != '\n' && c != EOF) ++len;
	in->seekg(here);
	char *p = new char[len + 1];
	for (int i = 0; i < len; ++i) p[i] = in->get();
	if (in->fail()) { cerr << "CRACKED PAST EOF" << endl; exit(-1); }
	p[len] = '\0';
	return p;
}
char *crackASCII::readString(int)	{ return read_string(m_in); }
char *crackASCII::readCountString(void)	{ return read_string(m_in); }
char *crackASCII::readShortString(void)	{ return read_string(m_in); }
char *crackASCII::readNullString(void)	{ return read_string(m_in); }
char *crackASCII::readEvenString(void)	{ return read_string(m_in); }

#include <ctype.h>
static char *asc(unsigned char c)
{
	static char hex[] = "0123456789abcdef";
	static char buf[4];
	if (isprint(c)) {
		buf[0] = c, buf[1] = '\0';
		return buf;
	}
	buf[0] = '\\';
	switch (c) {
	case '\0':	buf[1] = '0', buf[2] = '\0'; return buf;
	case '\r':	buf[1] = 'r', buf[2] = '\0'; return buf;
	case '\n':	buf[1] = 'n', buf[2] = '\0'; return buf;
	case '\v':	buf[1] = 'v', buf[2] = '\0'; return buf;
	case '\t':	buf[1] = 't', buf[2] = '\0'; return buf;
	case '\f':	buf[1] = 'f', buf[2] = '\0'; return buf;
	}
	buf[1] = hex[c>>4], buf[2] = hex[c&15], buf[3] = '\0';
	return buf;
}

static void inline _dumpASCII(unsigned char *buf, int lim)
{
	printf("\n      ");
	for (int j = 0; j < lim; ++j) {
		if ((j&3) == 0) putchar(' ');
		printf(" %3s", asc(buf[j]));
	}
}
static void inline _dumpSByte(unsigned char *buf, int lim)
{
	printf("\n      ");
	for (int j = 0; j < lim; ++j) {
		if ((j&3) == 0) putchar(' ');
		printf("%4d", ((signed char *)buf)[j]);
	}
}
static void inline _dumpUByte(unsigned char *buf, int lim)
{
	printf("\n      ");
	for (int j = 0; j < lim; ++j) {
		if ((j&3) == 0) putchar(' ');
		printf("%4d", ((unsigned char *)buf)[j]);
	}
}
static void inline _dumpLittle(unsigned char *buf, int lim)
{
	printf("\n      ");
	while ((unsigned)lim >= sizeof(int)) {
		int t = (((((buf[3]<<8)|buf[2])<<8)|buf[1])<<8)|buf[0];
		printf(" %16d", t);
		buf += sizeof(int), lim -= sizeof(int);
	}
}
static void inline _dumpBig(unsigned char *buf, int lim)
{
	printf("\n      ");
	while ((unsigned)lim >= sizeof(int)) {
		int t = (((((buf[0]<<8)|buf[1])<<8)|buf[2])<<8)|buf[3];
		printf(" %16d", t);
		buf += sizeof(int), lim -= sizeof(int);
	}
}
static void inline _dumpFloat(unsigned char *buf, int lim)
{
	printf("\n      ");
	while ((unsigned)lim >= sizeof(int)) {
		int t = (((((buf[3]<<8)|buf[2])<<8)|buf[1])<<8)|buf[0];
		printf(" %16f", *(float*)&t);
		buf += sizeof(int), lim -= sizeof(int);
	}
}
static void inline _dumpShortLittle(unsigned char *buf, int lim)
{
	printf("\n      ");
	int i = 0;
	while ((unsigned)lim >= sizeof(short)) {
		short t = (buf[1]<<8)|buf[0];
		if (++i&1) putchar(' ');
		printf(" %7d", t);
		buf += sizeof(short), lim -= sizeof(short);
	}
}
static void inline _dumpShortBig(unsigned char *buf, int lim)
{
	printf("\n      ");
	int i = 0;
	while ((unsigned)lim >= sizeof(short)) {
		short t = (buf[0]<<8)|buf[1];
		if (++i&1) putchar(' ');
		printf(" %7d", t);
		buf += sizeof(short), lim -= sizeof(short);
	}
}
static void inline _dumpBinary(int c, int bits, unsigned char *buf, int lim)
{
	printf("Bits");
	if (bits > 0) {
		putchar(' ');
		for (int i = 0; i < bits; ++i) {
			putchar((c&0x80) != 0 ? '1' : '0');
			c <<= 1;
		}
	}
	for (int i = 0; i < lim; ++i) {
		putchar(' ');
		c = buf[i];
		for (int j = 0; j < 8; ++j) {
			putchar((c&0x80) != 0 ? '1' : '0');
			c <<= 1;
		}
	}
	putchar('\n');
}
void crack::dump(int len, int flags)
{
	unsigned char buf[len];
	int max = m_in->read((char*)buf, sizeof buf).gcount();
	if (max <= 0) return;
	printf("DUMP FOLLOWS:\n");
	if ((flags&dumpBinary) != 0) {
		int lim = ((flags&dumpLots) != 0) ? 20 : 7;
		if (max < lim) lim = max;
		_dumpBinary(m_byte, m_bits, buf, lim);
	}
	for (int i = 0; i < max; i += 16) {
		int lim = (i + 16 < max) ? 16 : max - i;
		printf("%6o", i);
		for (int j = 0; j < lim; ++j) {
			if ((j&3) == 0) putchar(' ');
			printf(" %3.3o", buf[i+j]);
		}
		if ((flags&dumpASCII) != 0) _dumpASCII(buf + i, lim);
		if ((flags&dumpSByte) != 0) _dumpSByte(buf + i, lim);
		if ((flags&dumpUByte) != 0) _dumpUByte(buf + i, lim);
		if ((flags&dumpLittle) != 0) _dumpLittle(buf + i, lim);
		if ((flags&dumpBig) != 0) _dumpBig(buf + i, lim);
		if ((flags&dumpShort) != 0) {
			if ((flags&dumpBig) != 0) _dumpShortBig(buf + i, lim);
			if ((flags&dumpLittle) != 0) _dumpShortLittle(buf + i, lim);
			if ((flags&(dumpBig|dumpLittle)) == 0) _dumpShortLittle(buf + i, lim);
		}
		if ((flags&dumpFloat) != 0) _dumpFloat(buf + i, lim);
		printf("\n");
	}
}
