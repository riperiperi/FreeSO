#ifndef __SIMS_crack_H
#define __SIMS_crack_h

#include <iosfwd>

// base class for cracking files
class crack
{
	unsigned char m_byte, m_bits;
	int getBits(int howmany);
protected:
	std::istream *m_in;		// input stream being cracked
public:
	crack(std::istream *in) : m_bits(0), m_in(in) { }
	virtual ~crack(void);
	// total length of stream
	unsigned int GetLen(void);
	// returns TRUE if at/after EOF
	virtual int isEOF(void);
	// compressed bitfield input
	void setFieldWidths(char *widths);
	int getField(void);
	float getFloat(void);
	int readBit(void);
	void flushField(void) { m_bits = 0; }
	// read from our stream
	inline std::istream *s(void) { return m_in; }
	// skip a token
	virtual void skipToken(const char *token);
	// read one byte
	virtual int readByte(void);
	// read a two-byte integer
	virtual short readShort(void) = 0;
	// read a four-byte integer
	virtual int readInt(void) = 0;
	// read an IEEE short floating point value
	virtual float readFloat(void);
	// read a string of a known length
	virtual char *readString(int len);
	// read a Pascal-stype counted string
	virtual char *readCountString(void);
	// read a counted string using a two-byte length
	virtual char *readShortString(void);
	// read a string terminated by a null
	virtual char *readNullString(void);
	// read null-terminated string rounded to even
	char *readEvenString(void);

	// print a two-byte integer
	short printShort(char *fmt = 0);
	// print a four-byte integer
	int printInt(char *fmt = 0);
	// print an IEEE short floating point value
	float printFloat(char *fmt = 0);
	// print a string with a known length
	void printString(int len, char *fmt = 0);
	// print a Pascal-stype counted string
	void printCountString(char *fmt = 0);
	// print a counted string using a two-byte length
	void printShortString(char *fmt = 0);
	// print a string terminated by a null
	void printNullString(char *fmt = 0);
	// print null-terminated string rounded to even
	void printEvenString(char *fmt = 0);
	// print hex data
	void printHex(int count = 4, const char *prefix = 0);
	// dump out the next portion of the file
	enum {
		dumpASCII  = 0x01,	// ASCII or hex
		dumpSByte  = 0x02,	// signed bytes
		dumpUByte  = 0x04,	// unsigned bytes
		dumpLittle = 0x08,	// little-endian 4-byte integers
		dumpBig    = 0x10,	// big-endian 4-byte integers
		dumpFloat  = 0x20,	// little-endian 4-byte floats
		dumpShort  = 0x40,	// little-endian 2-byte shorts
		dumpBinary = 0x80,	// prefix in binary
		dumpLots   = 0x100,	// make dumpBinary longer
	};
	void dump(int len = 128, int flags = dumpASCII);
};

// crack a file containing little-endian numbers
class crackLittle : public crack
{
public:
	crackLittle(std::istream *in) : crack(in) { }
	~crackLittle(void) { }
	// a two-byte integer
	short readShort(void);
	// a four-byte integer
	int readInt(void);
};

// crack a file containing big-endian numbers
class crackBig : public crack
{
public:
	crackBig(std::istream *in) : crack(in) { }
	~crackBig(void) { }
	// a two-byte integer
	short readShort(void);
	// a four-byte integer
	int readInt(void);
};

// crack an ASCII file
class crackASCII : public crack
{
public:
	crackASCII(std::istream *in) : crack(in) { }
	~crackASCII(void) { }
	// returns TRUE if at/after EOF
	virtual int isEOF(void);
	// skip a token
	virtual void skipToken(const char *token);
	// read one byte
	int readByte(void);
	// a two-byte integer
	short readShort(void);
	// a four-byte integer
	int readInt(void);
	// an IEEE short floating point value
	float readFloat(void);
	// read a string of a known length
	virtual char *readString(int len);
	// a Pascal-stype counted string
	char *readCountString(void);
	// a counted string using a two-byte length
	char *readShortString(void);
	// a string terminated by a null
	char *readNullString(void);
	// read null-terminated string rounded to even
	char *readEvenString(void);
};

#endif // __SIMS_crack_h
