#ifndef __SIMS_wxistream_h
#define __SIMS_wxistream_h

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma interface "wxistream.h"
#endif

#include "wx/defs.h"

#if ! wxUSE_STREAMS || ! wxUSE_FILE
#error "Library not compiled with support for STREAMS and FILE, which are needed for this function"
#endif // wxUSE_STREAMS && wxUSE_FILE

#include <iosfwd>
#include "wx/stream.h"

class wxIStream : public wxInputStream
{
	std::istream *m_stream;
	size_t OnSysRead(void *buffer, size_t size);
	off_t OnSysSeek(off_t pos, wxSeekMode mode);
	off_t OnSysTell() const;
	wxIStream();
	DECLARE_NO_COPY_CLASS(wxIStream)
public:
	wxIStream(std::istream *stream);
	~wxIStream();
	bool err() const { return m_stream == 0; }
	//size_t GetSize() const;
};

#endif // __SIMS_wxistream_h
