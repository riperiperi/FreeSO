#include "iff_glob.h"
#include "crack.h"
#include <iostream>

simIFF_GLOB::simIFF_GLOB(std::istream *s)
{
	int c;
	if ((c = s->get()) < (int)sizeof m_glob - 1) {
		for (int i = 0; i < c; ++i) m_glob[i] = s->get();
	} else {
		for (size_t i = 0; i < sizeof m_glob - 1; ++i) {
			m_glob[i] = c;
			if ((c = s->get()) == '\0' || c == EOF) {
				c = i + 1;
				break;
			}
		}
	}
	m_glob[c] = '\0';
	delete s;
}
