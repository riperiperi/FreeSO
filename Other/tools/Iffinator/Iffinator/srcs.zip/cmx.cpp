#include "cmx.h"
#include "crack.h"
#include <iostream>
using std::cout;
using std::cerr;
using std::endl;
#include <fstream>

// fast string comparison
// take advantage of the fact that most string tests
// that are going to fail do so on the first character,
// so do that much in-line and only call a slower
// routine if the first character matches.
static int slow_streq(const char *p, const char *q)
{
	while (*p != '\0') if (*++p != *++q) return 0;
	return 1;
}
static inline int streq(const char *p, const char *q)
{
	if (*p == *q) return slow_streq(p, q);
	return 0;
}

inline simProps::simProps(void) : m_name(0) { }

inline void simProps::subinit(crack &in)
{
	m_attrs = in.readInt();
	m_name = new char *[m_attrs + m_attrs];
	for (int i = 0; i < m_attrs; ++i) {
		m_name[i] = in.readCountString();
		m_name[i + m_attrs] = in.readCountString();
	}
}

inline void simProps::init(crack &in)
{
	int t = in.readInt();
	if (t == 0) {
		m_attrs = 0;
	} else if (t != 1) {
		// Houston, we have a problem...
		cerr << "BAD ATTRIBUTE; processing aborted" << endl;
		exit(0);
	} else {
		subinit(in);
	}
}

simProps::~simProps(void)
{ 
	for (int i = 0; i < m_attrs; ++i) {
		delete[] m_name[i];
	}
	delete[] m_name;
}

const char *simProps::value(const char *s) const
{
	for (int i = 0; i < m_attrs; ++i) {
		if (streq(m_name[i], s)) return m_name[i + m_attrs];
	}
	return 0;
}

simSkeleton::Bone::Bone(void) : name(0), parent(0) { }

inline void simSkeleton::Bone::init(crack &in, int ascii)
{
	name = in.readCountString();
	parent = in.readCountString();
	simProps::init(in);
	// offset from parent
	in.skipToken("|");
	offset.x = in.readFloat();
	offset.y = in.readFloat();
	offset.z = in.readFloat();
	in.skipToken("|");
	// rotation quaternion
	in.skipToken("|");
	rotation.x = in.readFloat();
	rotation.y = in.readFloat();
	rotation.z = in.readFloat();
	rotation.w = in.readFloat();
	in.skipToken("|");
	// flag values
	translate = in.readInt();
	rotate = in.readInt();
	blend = in.readInt();
	wiggle.flag = in.readInt();
	wiggle.power = in.readFloat();
}
inline simSkeleton::Bone::~Bone(void)
{
	delete[] name;
	delete[] parent;
}

inline simSkeleton::simSkeleton(void)
: m_name(0), m_bone(0)
{ }
inline void simSkeleton::init(crack &in, int ascii)
{
	m_name = in.readCountString();
	m_bones = in.readInt();
	m_bone = new Bone[m_bones];
	for (int i = 0; i < m_bones; ++i) m_bone[i].init(in, ascii);
}

simSkeleton::~simSkeleton(void)
{
	delete[] m_name;
	delete[] m_bone;
}

inline simSuit::Skin::Skin(void)
: bone(0), skin(0) { }
inline void simSuit::Skin::init(crack &in)
{
	bone = in.readCountString();
	skin = in.readCountString();
	censor = in.readInt();
	//flag2 = in.readInt();
	flag2 = 0;	// remove later
	simProps::init(in);
}
inline simSuit::Skin::~Skin(void)
{
	delete[] bone;
	delete[] skin;
}

inline simSuit::simSuit(void)
: m_name(0), m_skin(0) { }
inline void simSuit::init(crack &in)
{
	m_name = in.readCountString();	// our name
	m_type = in.readInt();
	//m_flag2 = in.readInt();
	m_flag2 = 0;	// remove later
	simProps::init(in);
	m_skins = in.readInt();
	m_skin = new Skin[m_skins];
	for (int i = 0; i < m_skins; ++i) m_skin[i].init(in);
}
inline simSuit::~simSuit(void)
{
	delete[] m_name;
	delete[] m_skin;
}

inline simSkill::Event::Event(void) { }

inline void simSkill::Event::init(crack &in)
{
	when = in.readInt();
	simProps::subinit(in);
}

inline simSkill::Event::~Event(void) { }

inline simSkill::Motion::Motion(void) : seg(0), m_event(0) { }

inline void simSkill::Motion::init(crack &in)
{
	seg = in.readCountString();	// seg name
	frames = in.readInt();
	same = in.readFloat();
//if (unknown1 != same) cerr << "LOOK: skill " << name << " seg " << seg << " don't have same speed" << endl;
	translations = in.readInt();
	rotations = in.readInt();
	toffset = in.readInt();
	roffset = in.readInt();
	simProps::init(in);
	int t = in.readInt();
	if (t == 0) {
		events = 0;
	} else if (t != 1) {
		// Houston, we have a problem...
		cerr << "BAD SKELETON; processing aborted" << endl;
		exit(0);
	} else {
		if ((events = in.readInt()) > 0) {
			m_event = new Event[events];
			for (int i = 0; i < events; ++i) m_event[i].init(in);
		}
	}
}

inline simSkill::Motion::~Motion(void)
{
	delete[] seg;
	if (events > 0) delete[] m_event;
}

inline simSkill::simSkill(void)
{
	m_name = 0;
	m_anim = 0;
	m_motion = 0;
}
inline void simSkill::init(crack &in)
{
	m_name = in.readCountString();	// our name
	m_anim = in.readCountString();	// anim name
	m_unknown1 = in.readFloat();	// speed??
	m_unknown2 = in.readFloat();	// turning??
	m_flag = in.readInt();	// if unknown2 is non-zero, then one, else zero
	m_count1 = in.readInt();
	m_count2 = in.readInt();
	m_motions = in.readInt();
	m_motion = (m_motions == 0) ? 0 : new Motion[m_motions];
	int m_count2 = 0;
	for (int i = 0; i < m_motions; ++i) {
		m_motion[i].init(in);
		m_count2 += m_motion[i].frames;
	}
	if (m_count2 != m_count2) {
		cerr	<< "Skill " << m_name << " claims " << m_count2
			<< " frames; segments have " << m_count2 << endl;
	}
}

inline simSkill::~simSkill(void)
{
	delete[] m_name;
	delete[] m_anim;
	delete[] m_motion;
}

void simCMX::init(std::istream *s, int ascii)
{
	m_skeleton = 0, m_suit = 0, m_skill = 0;
	if (s->fail()) return;
	crack *in;
	if (ascii) {
		in = new crackASCII(s);
		delete[] in->readCountString();
		delete[] in->readCountString();
	} else {
		in = new crackLittle(s);
	}
	if ((m_skeletons = in->readInt()) > 0) {
		m_skeleton = new simSkeleton[m_skeletons];
		for (int i = 0; i < m_skeletons; ++i) {
			m_skeleton[i].init(*in, ascii);
		}
	}
	if ((m_suits = in->readInt()) > 0) {
		m_suit = new simSuit[m_suits];
		for (int i = 0; i < m_suits; ++i) m_suit[i].init(*in);
	}
	// some hand-made files (notably modified censor files) improperly
	// truncate the file too soon, so we must check for it here
	if (in->isEOF()) {
		//cerr << "LOOK: truncated before skills section" << endl;
		m_skills = 0;
	} else if ((m_skills = in->readInt()) > 0) {
		m_skill = new simSkill[m_skills];
		for (int i = 0; i < m_skills; ++i) {
			if (in->isEOF()) {
cerr << "LOOK: claimed " << m_skills << " skills, found " << i << endl;
				m_skills = i;
				break;
			}
			m_skill[i].init(*in);
		}
	}
	//in->dump();
	delete in;
}

simCMX::simCMX(char *file, int ascii)
{
	init(new std::ifstream(file), ascii);
}

simCMX::~simCMX(void)
{
	delete[] m_skeleton;
	delete[] m_suit;
	delete[] m_skill;
}
