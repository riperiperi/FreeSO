#include "iff_dgrp.h"
#include "crack.h"
#include <iostream>
using std::cout;
using std::endl;

class ScanDGRP
{
protected:
	crack &m_in;
public:
	ScanDGRP(crack &in) : m_in(in) {}
	virtual int val(void)	{ return m_in.readShort(); }
	virtual void hdr(short &s, unsigned char &u1, unsigned char &u2) {
		s = m_in.readShort();
		u1 = m_in.readByte();
		u2 = m_in.readByte();
	}
	virtual int what(void)	{ return m_in.readShort(); }
	virtual int flag1(void)	{ return m_in.readShort(); }
	virtual float zoff(void) { return 0.0; }
	virtual int flag2(void)	{ return 0; }
	virtual float xyoff(void) { return 0.0; }
	void dump(void) {
		m_in.dump(512, crack::dumpASCII | crack::dumpShort
				| crack::dumpLittle);
	}
};

class ScanDGRP2v0 : public ScanDGRP
{
public:
	ScanDGRP2v0(crack &in) : ScanDGRP(in) {}
};
class ScanDGRP2v1 : public ScanDGRP2v0
{
public:
	ScanDGRP2v1(crack &in) : ScanDGRP2v0(in) {}
	// adds xoffset field
	float zoff(void)	{ return m_in.readFloat(); }
};
// no samples of 2v2, so we don't know which of the
// changes in 2v3 really took place in 2v2
class ScanDGRP2v3 : public ScanDGRP2v1
{
public:
	ScanDGRP2v3(crack &in) : ScanDGRP2v1(in) {}
	// all values are now four bytes each and the order
	// of the sprite header changed (bad plan)
	int val(void)		{ return m_in.readInt(); }
	void hdr(short &s, unsigned char &u1, unsigned char &u2) {
		u1 = m_in.readInt();
		u2 = m_in.readInt();
		s = m_in.readInt();
	}
	// item tag has been removed
	int what(void)		{ return 0; }
	// flag field moved from first to last (bad plan)
	virtual int flag1(void)	{ return 0; }
	virtual int flag2(void)	{ return m_in.readInt(); }
};
class ScanDGRP2v4 : public ScanDGRP2v3
{
public:
	ScanDGRP2v4(crack &in) : ScanDGRP2v3(in) {}
	// yoffset and zoffset fields added
	float xyoff(void)	{ return m_in.readFloat(); }
};

simIFF_DGRP::simIFF_DGRP(std::istream *s)
:	m_count(0)
{
	crackLittle crak(s);
	m_version = crak.readShort();
#if DebugPrint
	cout << "version " << m_version << endl;
#endif
	ScanDGRP *in;
	if (m_version == 20004) in = new ScanDGRP2v4(crak); else
	if (m_version == 20003) in = new ScanDGRP2v3(crak); else
	if (m_version == 20001) in = new ScanDGRP2v1(crak); else
	if (m_version == 20000) in = new ScanDGRP2v0(crak); else
	{
		cout << "UNKNOWN DGRP VERSION " << m_version << endl;
		return;
	}
	m_count = in->val();		// always 12
	m_array = m_image;
	for (int i = 0; i < m_count; ++i) {
		Image &img = m_array[i];
		in->hdr(img.m_count, img.m_orient, img.m_zoom);
		img.m_array = (img.m_count > 3)
				? new Sprite[img.m_count]
				: img.m_sprite;
		for (int j = 0; j < img.m_count; ++j) {
			Sprite &s = img.m_array[j];
			s.m_what = in->what();
			s.m_id = in->val();
			s.m_index = in->val();		// 0..11
			s.m_flags = in->flag1();	// 0,1
			s.m_pixelx = in->val();		// -935..867
			s.m_pixely = in->val();		// -10332..43
			s.m_zoffset = in->zoff();	// 0..32.7415
			s.m_flags |= in->flag2();	// 0,1,4,5
			s.m_xoffset = in->xyoff();	// always 0
			s.m_yoffset = in->xyoff();	// 99% 0
		}
	}
	in->dump();
}
