#ifndef __SIMS_lrustream_h
#define __SIMS_lrustream_h

#include <iostream>
#include <fstream>

/*  The LRU class has an ifstream that can be closed and re-opened without
    loss of synchronization.  The status is maintained in the _indir class
    and the ifstream is just used to read and write.  The pool of ifstreams
    is maintained in a least-recently-used order and if there are too many
    ifstreams allocated, it will steal one that hasn't been used in a while
    and re-use it for the current access.  in this way, all the data remains
    accessable, but the number of open files is limited.
*/

class LRU
{
	class _entry;		// forward reference
	// indirect stream class, assigned to one of
	// the cache streams dynamically
	class _indir : public std::streambuf, public std::istream,
		public virtual std::ios
	{
		friend class LRU;
		LRU &m_base;		// LRU base class
		const char *m_name;	// name of file
		LRU::_entry *m_real;	// underlying stream
		std::streampos m_tell;	// current seek pointer
	public:
		_indir(LRU &base, const char *name);
		~_indir(void);
		virtual std::streampos
		seekoff(std::streamoff, std::ios::seekdir, std::ios::openmode);
		// virtual streambuf *setbuf(char *memory, int len);
		virtual int sync(void);
	protected:
		virtual int underflow();
		// virtual int overflow(int = EOF);
		// virtual int pbackfail(int);
	};
	friend class _indir;
	// a pool entry, dynamically assigned to an indirect stream
	class _entry : public std::ifstream
	{
		friend class LRU;
		friend class _indir;
		_entry *m_prev, *m_next;
		_indir *m_indir;
	public:
		_entry(void);
	};
	enum { cache_size = 50 };
	_entry m_cache[cache_size];
	_entry *m_head, *m_tail;
	void assign_entry(_indir &here);
public:
	LRU(void);
	~LRU(void);
	std::istream *stream(const char *name) {
		return new _indir(*this, name);
	}
};

#endif // __SIMS_lrustream_h
