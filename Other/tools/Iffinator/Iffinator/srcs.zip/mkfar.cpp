#include <fstream>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include "mkfar.h"
#include "far.h"

static inline void writeInt(std::ostream *out, int i)
{
	// write integer in little-endian
	out->put((char)i), i >>= 8;
	out->put((char)i), i >>= 8;
	out->put((char)i), i >>= 8;
	out->put((char)i);
}

static unsigned int initFile(std::ostream *out)
{
	unsigned int tell = out->tellp();
	// signature
	out->write("FAR!byAZ", 8);
	// version
	writeInt(out, 1);
	// space for manifest offset
	out->seekp(4, std::ios::cur);
	return tell;
}

simMkFAR::simMkFAR(std::ostream *out)
{
	m_count = 0, m_manifest = 0;
	if ((m_stream = out) != 0) m_tell = initFile(out);
}

simMkFAR::simMkFAR(const char *file)
{
	m_count = 0, m_manifest = 0;
	if ((m_stream = new std::ofstream(file))->good()) {
		m_tell = initFile(m_stream);
	} else {
		// open failed
		delete m_stream;
		m_stream = 0;
	}
}

simMkFAR::~simMkFAR(void)
{
	if (err()) return;
	// remember our location
	unsigned int here = m_stream->tellp();
	// the number of entries
	writeInt(m_stream, m_count);
	// manifest entries were pushed onto the list,
	// so first we have to reverse the list
	entry *p = 0;
	for (entry *q = m_manifest; q != 0; ) {
		entry *r = q->m_next;
		q->m_next = p;
		p = q, q = r;
	}
	// go down the list, write each manifest, and delete it
	while (p != 0) {
		entry *q = p;
		p = q->m_next;
		writeInt(m_stream, q->m_len);
		writeInt(m_stream, q->m_len);
		writeInt(m_stream, q->m_loc);
		int i = strlen(q->m_name);
		writeInt(m_stream, i);
		m_stream->write(q->m_name, i);
		delete[] q->m_name;
		delete q;
	}
	m_stream->seekp(m_tell + 12);
	writeInt(m_stream, here - m_tell);
	delete m_stream;
}

void simMkFAR::add(std::istream &in, const char *name)
{
	entry *p = new entry;
	p->m_next = m_manifest, m_manifest = p;
	p->m_name = new char[strlen(name) + 1];
	strcpy(p->m_name, name);
	p->m_loc = m_stream->tellp() - std::streampos(m_tell);
	char buf[4096];
	std::streamsize i;
	while ((i = in.read(buf, sizeof buf).gcount()) > 0) {
		m_stream->write(buf, i);
	}
	p->m_len = m_stream->tellp() - std::streampos(p->m_loc);
	++m_count;
}

void simMkFAR::add(simFAR &in)
{
	if (in.err()) return;
	for (int i = 0; i < in.entries(); ++i) {
		simFAR::Entry &e = in[i];
		add(*e.stream(), e.name());
	}
}

void simMkFAR::add(const char *name)
{
	std::ifstream *in = new std::ifstream(name);
	if (!in->good()) {
		delete in;
		return;
	}
	simFAR far(in);		// deletes in when destroyed
	if (far.err()) {
		// regular file
		add(*in, name);
	} else {
		// .far file
		add(far);
	}
}

void simMkFAR::addDir(const char *name)
{
	struct stat sb;
	if (stat(name, &sb) < 0) return;
	if ((sb.st_mode&S_IFMT) == S_IFREG) { add(name); return; }
	if ((sb.st_mode&S_IFMT) != S_IFDIR) return;
	// scan a directory for names
	DIR *Dp = opendir(name);
	if (Dp == 0) return;
	struct dirent *dp;
	int dlen = strlen(name) + 2;
	while ((dp = readdir(Dp)) != 0) {
		if (dp->d_name[0] == '.') continue;
		char p[dlen + strlen(dp->d_name)];
		strcpy(p, name);
		p[dlen - 2] = '/';
		strcpy(p + dlen - 1, dp->d_name);
		if (stat(p, &sb) < 0) continue;
		if ((sb.st_mode&S_IFMT) == S_IFREG) {
			std::ifstream in(p);
			if (in.good()) add(in, dp->d_name);
		} else if ((sb.st_mode&S_IFMT) == S_IFDIR) {
			// TODO: somehow include path prefix
			addDir(p);
		}
	}
	closedir(Dp);
}
