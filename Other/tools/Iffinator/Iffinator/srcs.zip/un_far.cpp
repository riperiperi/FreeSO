#include "far.h"
#include "auto_ptr.h"
#include <string.h>
#include <iostream>
#include <fstream>

static inline bool suffix_match(const char *name, char **suffs)
{
	if (*suffs == 0) return true;	// none specified, take everything
	const char *suf = 0;
	do {
		if (*name == '.') suf = name + 1;
	} while (*++name != 0);
	if (suf == 0) return false;	// no suffix on name
	do {
		if (::strcmp(suf, *suffs) == 0) return true;
	} while (*++suffs != 0);
	return false;
}

AUTO_PTR(istr_ptr, std::istream);
AUTO_PTR(ostr_ptr, std::ostream);

int main(int argc, char **argv)
{
	if (argc < 3) {
		std::cout << "Usage: " << argv[0]
			<< " file.far directory [suffix ...]\n"
			<< std::endl;
		return 1;
	}
	simFAR in(argv[1]);
	if (in.err()) {
		std::cout << "Could not open FAR file " << argv[1]
			<< std::endl;
		return 1;
	}
	int dirlen = strlen(argv[2]) + 2;
	for (int i = 0; i < in.entries(); ++i) {
		if (!suffix_match(in[i].name(), argv + 3)) continue;
		char filename[dirlen + strlen(in[i].name())];
		strcpy(filename, argv[2]);
		filename[dirlen - 2] = '/';
		strcpy(filename + dirlen - 1, in[i].name());
		std::ofstream out(filename);
		//std::ofstream out(in[i].name());
		char buf[512];
		istr_ptr e = in[i].stream();
		for (int l;  (l = e->read(buf, sizeof buf).gcount()) > 0; ) {
			out.write(buf, l);
		}
	}
	return 0;
}
