#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma implementation "wxistream.h"
#endif

#include "wxistream.h"
#include <iostream>

// ----------------------------------------------------------------------------
// wxIStream
// ----------------------------------------------------------------------------

wxIStream::wxIStream()
:	wxInputStream()
{
	m_stream = NULL;
}

wxIStream::wxIStream(std::istream *stream)
:	wxInputStream()
{
	m_stream = stream;
	if (m_stream != 0 && m_stream->bad()) {
		delete m_stream;
		m_stream = 0;
	}
}

wxIStream::~wxIStream()
{
	delete m_stream;
}

#if 0
size_t wxIStream::GetSize() const
{
	size_t here = m_stream->tellg();
	if (here == size_t(-1)) return size_t(-1);	// not seekable
	size_t len = m_stream->seekg(0, std::ios::end).tellg();
	m_stream->seekg(here);
	return len;
}
#endif

size_t wxIStream::OnSysRead(void *buffer, size_t size)
{
	off_t ret = m_stream->read((char*)buffer, size).gcount();
	if (m_stream->eof()) m_lasterror = wxSTREAM_EOF;
	if (ret == wxInvalidOffset) {
		m_lasterror = wxSTREAM_READ_ERROR;
		ret = 0;
	}
	return ret;
}

off_t wxIStream::OnSysSeek(off_t pos, wxSeekMode mode)
{
	return m_stream->seekg(std::streamoff(pos), (std::ios::seekdir)mode)
			.good() ? pos : wxInvalidOffset;
}

off_t wxIStream::OnSysTell() const
{
	return m_stream->tellg();
}
