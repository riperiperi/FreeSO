// converted by macroizer.sh into hash.h and hash.cpp

// BEGIN HEADER
#ifndef __SIMS_hash_h
#define __SIMS_hash_h

//XXX #if 0
// EXAMPLE
// To use this hash class, you must write a simple wrapper class.
// This wrapper class brings together the lookup key and the
// corresponding value and tells the hash class how to do certain
// things.  As long as the class defines the right things, it can
// do almost anything.

// In this example, we have a class that already defines its own
// key value.  This is a fragment of the value class:
struct MyData
{
	KeyType id;
};

// The wrapper class must provide access to the key and value; it
// is sometimes called a "pair class."  It is constructed from
// the key and (a reference to) the data.  It must define member
// functions named "key" and "data" to access the key and data,
// respectively.  It must also define two static functions, one
// named "hash" that converts a key into a "signature" and one
// named "compare" that compares two keys for equality.
struct MyWrapper
{
	// Whatever data elements are needed to remember the key and data
	// values.  In this case, the key is contained within the data.
	DataType *m_data;
	// The constructor must take two parameters: a key value and a
	// reference to a data value
	MyWrapper(KeyType k, DataType &v) : m_data(&v) { }
	// The class must define a function that returns the key value
	KeyType key(void)	{ return m_data->id; }
	// The class must define a function that returns a data reference
	DataType &data(void)	{ return *m_data; }
	// The class must define a static function that returns a key hash
	static unsigned int hash(KeyType p);
	// The class must define a static function that compares two key values
	static bool compare(KeyType p, KeyType q);
};

// To create a hash class named MyHash, just write
//XXX 	simHash(KeyType, DataType, MyWrapper, MyHash)
// Note that there is no trailing semi-colon required.
//XXX #endif

class simHashBasis
{
	static bool slow_streq(const char *a, const char *b);
public:
	typedef unsigned int sig_t;
protected:
	unsigned int *m_size;	// size of the table
	unsigned int m_entries;	// count of entries
	struct ElementBasis {
		ElementBasis *m_next;
		sig_t m_sig;
		ElementBasis(void) : m_next(0) { }
	} **m_list;
	simHashBasis(int estimate);
	simHashBasis(unsigned int *growth_table);
	// ~simHashBasis(void);
	ElementBasis **sig2list(sig_t sig) const {
		return m_list + sig%*m_size;
	}
	void rehash(void);		// consider rehashing

public:
	// A function to create a signature for a string.  It's
	// not cryptographically strong, but it's fast and produces
	// a reasonable distribution.
	static sig_t hash(const char *s);

	// Since virtually all string comparisons that are going
	// to fail do so on the first character, this in-lines
	// the first test and only calls an out-of-line function
	// if that compares equal
	static inline bool streq(const char *a, const char *b) {
		return (*a == *b) ? slow_streq(a, b) : 0;
	}
};

/*MACRO*/ #define simHash(KeyType, DataType, PairType, ClassName)
class ClassName : public simHashBasis
{
	typedef KeyType key_type;
	typedef DataType data_type;
	typedef PairType pair_type;
	typedef data_type *pointer;
	typedef data_type &reference;
	struct Element : public simHashBasis::ElementBasis {
		pair_type m_type;
		Element(KeyType k, DataType &v) : m_type(k, v) { }
		~Element(void) { delete (Element*)m_next; }
	};
	struct _spot { Element **q; sig_t sig; };
	_spot _locate(key_type k) const {
		_spot here;
		here.sig = pair_type::hash(k);
		Element **q = (Element **)sig2list(here.sig);
		for (Element *p; (p = *q) != 0; q = &(Element*)p->m_next) {
			if (p->m_sig == here.sig) {
				if (pair_type::compare(k, p->m_type.key())) {
					break;
				}
			}
		}
		here.q = q;
		return here;
	}
public:
	ClassName(int estimate = 5) : simHashBasis(estimate) { }
	~ClassName(void) {
		for (unsigned int i = 0; i < *m_size; ++i) {
			delete (Element *)m_list[i];
		}
		delete[] m_list;
	}
	bool add(key_type k, reference v) {
		_spot here = _locate(k);
		Element **q = here.q, *p = *q;
		if (p != 0) return 1;
		*q = new Element(k, v);
		(*q)->m_sig = here.sig;
		if (++m_entries > *m_size) rehash();
		return 0;
	}
	void del(key_type k) {
		Element **q = _locate(k).q, *p = *q;
		if (p == 0) return;
		*q = (Element*)p->m_next;
		delete p;
		--m_entries;
	}
	pointer find(key_type k) const {
		Element *p = *_locate(k).q;
		if (p == 0) return 0;
		return &p->m_type.data();
	}
	class iterator;
	friend class iterator;
	class iterator
	{
		Element **m_start, **m_end, *m_curr;
	public:
		iterator(const ClassName &base) {
			m_start = (Element**)base.m_list;
			m_end = m_start + *base.m_size;
			while (m_start < m_end) {
				// find first entry
				if ((m_curr = *m_start++) != 0) return;
			}
			m_curr = 0;
		}
		operator bool(void) { return m_curr != 0; }
		DataType *operator->(void) { return &m_curr->m_type.data(); }
		void operator++(void) {
			Element *t = m_curr;
			if (t != 0) t = (Element*)t->m_next;
			while (t == 0) {
				if (m_start >= m_end) { m_curr = 0; return; }
				t = *m_start++;
			}
			m_curr = t;
		}
	};
};

#endif // __SIMS_hash_h
// END HEADER

// BEGIN CODE
//XXX #include "hash.h"

// A list of primes, with the property that each successive one is
// at least twice as big (three times up until 1000; above 10000000,
// it increases by at least 50%).  Hash sizes are rounded up to one
// of these, and when the table is expanded, the next larger is
// used.  Thus, the table expands more rapidly at small sizes and
// more slowly if the table becomes huge.  If it ever reaches the
// maximum value, it gets no larger.
static unsigned int hash_primes[] = {
	11, 37, 113, 347, 1049, 2111, 4229, 8461, 16927, 33857, 67723,
	135449, 203183, 304781, 457183, 685781, 1028681, 1543033, 2314583,
	3471883, 5207827, 7811747, 11717633, 17576459, 26364721, 39547111,
	59320669, 88981007, 133471531, 200207299, 300310957, 450466463,
	675699701, 1013549569, 0
};

static inline void **newElements(unsigned int size)
{
	void **t = new void *[size];
	for (unsigned int i = 0; i < size; ++i) t[i] = 0;
	return t;
}

simHashBasis::simHashBasis(int size)
:	m_entries(0)
{
	// chose initial size
	for (unsigned int *p = hash_primes; p[1] != 0; ++p) {
		if (*p >= (unsigned int)size) {
			m_size = p;
			break;
		}
	}
	m_list = (ElementBasis **)newElements(*m_size);
}
simHashBasis::simHashBasis(unsigned int *growth_table)
:	m_entries(0)
{
	m_list = (ElementBasis **)newElements(*(m_size = growth_table));
}

// called when a new entry has just been added to the map
// and the map is already dense.
void simHashBasis::rehash(void)
{
	// This simple policy is not optimal
	// Eventually, a histogram should be used to
	// track when the chain lengths are getting bad
	// and only rehash when the average list length
	// gets too large
	if (m_size[1] == 0) return;	// already at largest size

	// rehash
	ElementBasis **old = m_list;
	m_list = (ElementBasis **)newElements(*++m_size);
	for (unsigned int i = 0; i < m_size[-1]; ++i) {
		for (ElementBasis *p = old[i], *q; p != 0; p = q) {
			q = p->m_next;
			ElementBasis **t = sig2list(p->m_sig);
			p->m_next = *t;
			*t = p;
		}
	}
	delete old;
}

simHashBasis::sig_t simHashBasis::hash(const char *s)
{
	sig_t t = 0;
	while (*s != '\0') {
		t = t*17 + *(unsigned const char*)s;
		++s;
	}
	return t;
}

bool simHashBasis::slow_streq(const char *a, const char *b)
{
	while (*a != '\0') {
		if (*++a != *++b) return 0;
	}
	return 1;	// strings are equal
}
// END CODE
