// machine-generated then heavily tweaked by hand

static const char unused[] = "~unused";
static const char null[]   = "";

const char *BhavStr128[] = {	// behavior strings
	/*  0 */ "private: ",
	/*  1 */ "global: ",
	/*  2 */ "semi-global: ",
	/*  3 */ "4 temps",
	/*  4 */ "stack",
	/*  5 */ unused,
	/*  6 */ unused,
	/*  7 */ unused,
	/*  8 */ unused,
	/*  9 */ unused,
	/* 10 */ unused,
	/* 11 */ unused,
	/* 12 */ unused,
	/* 13 */ unused,
	/* 14 */ unused,
	/* 15 */ unused,
	/* 16 */ unused,
	/* 17 */ unused,
	/* 18 */ unused,
	/* 19 */ unused,
	/* 20 */ unused,
	/* 21 */ unused,
	/* 22 */ unused,
	/* 23 */ unused,
	/* 24 */ unused,
	/* 25 */ unused,
	/* 26 */ unused,
	/* 27 */ unused,
	/* 28 */ unused,
	/* 29 */ unused,
	/* 30 */ unused,
	/* 31 */ unused,
	/* 32 */ unused,
	/* 33 */ unused,
	/* 34 */ unused,
	/* 35 */ unused,
	/* 36 */ unused,
	/* 37 */ unused,
	/* 38 */ unused,
	/* 39 */ unused,
	/* 40 */ unused,
	/* 41 */ unused,
	/* 42 */ unused,
	/* 43 */ unused,
	/* 44 */ unused,
	/* 45 */ unused,
	/* 46 */ unused,
	/* 47 */ unused,
	/* 48 */ unused,
	/* 49 */ unused,
	/* 50 */ unused,
	/* 51 */ unused,
	/* 52 */ unused,
	/* 53 */ unused,
	/* 54 */ unused,
	/* 55 */ unused,
	/* 56 */ unused,
	/* 57 */ unused,
	/* 58 */ unused,
	/* 59 */ unused,
	/* 60 */ unused,
	/* 61 */ unused,
	/* 62 */ unused,
	/* 63 */ unused,
	/* 64 */ "gosub",
	/* 65 */ "(",
	/* 66 */ "for",
	/* 67 */ "to radius",
	/* 68 */ "from 0 to",
	/* 69 */ "into",
	/* 70 */ "distance",
	/* 71 */ "stack",
	/* 72 */ "4 temps",
	/* 73 */ ")",
	/* 74 */ "tree",
	/* 75 */ "file",
	/* 76 */ "this obj",
	/* 77 */ "type",
	/* 78 */ "check",
	/* 79 */ "act",
	/* 80 */ "for need in",
	/* 81 */ "=",
	/* 82 */ "tree",
	/* 83 */ "with rate",
	/* 84 */ "to",
	/* 85 */ "for need",
	/* 86 */ "sel",
	/* 87 */ "pair act",
	/* 88 */ "to check",
	/* 89 */ "set",
	/* 90 */ "to need",
	/* 91 */ "update need",
	/* 92 */ "to index",
	/* 93 */ "check",
	/* 94 */ "act",
	/* 95 */ "until",
	/* 96 */ "not",
	/* 97 */ "clear",
	/* 98 */ "for",
	/* 99 */ "by",
	/* 100 */ null,
	/* 101 */ null,
	/* 102 */ null,
	/* 103 */ null,
	/* 104 */ null,
	/* 105 */ null,
	/* 106 */ null,
	/* 107 */ null,
	/* 108 */ null,
	/* 109 */ null,
	/* 110 */ null,
	/* 111 */ null,
	/* 112 */ null,
	/* 113 */ null,
	/* 114 */ null,
	/* 115 */ null,
	/* 116 */ "gt",
	/* 117 */ "lt",
	/* 118 */ "==",
	/* 119 */ " +=",
	/* 120 */ " -=",
	/* 121 */ "=",
	/* 122 */ "*=",
	/* 123 */ "div=",
	/* 124 */ "FlagSet?",
	/* 125 */ "SetFlag",
	/* 126 */ "ClrFlag",
	/* 127 */ null,
	/* 128 */ null,
	/* 129 */ null,
	/* 130 */ null,
	/* 131 */ null,
	/* 132 */ null,
	/* 133 */ null,
	/* 134 */ null,
	/* 135 */ null,
	/* 136 */ null,
	/* 137 */ null,
	/* 138 */ null,
	/* 139 */ null,
	/* 140 */ null,
	/* 141 */ null,
	/* 142 */ "unknown",
	/* 143 */ "food",
	/* 144 */ "person",
	/* 145 */ "container",
	/* 146 */ "furniture",
	/* 147 */ "structure",
	/* 148 */ "animal",
	/* 149 */ null,
	/* 150 */ null,
	/* 151 */ null,
	/* 152 */ null,
	/* 153 */ null,
	/* 154 */ null,
	/* 155 */ null,
	/* 156 */ null,
	/* 157 */ null,
	/* 158 */ null,
	/* 159 */ null,
	/* 160 */ null,
	/* 161 */ null,
	/* 162 */ null,
	/* 163 */ "base",
	/* 164 */ "relieve hunger",
	/* 165 */ "relieve loneliness",
	/* 166 */ "relieve boredom",
	/* 167 */ "decrease sleepiness",
	/* 168 */ "get money",
	/* 169 */ "open door",
	/* 170 */ "put out fire",
	/* 171 */ null,
	/* 172 */ null,
	/* 173 */ null,
	/* 174 */ null,
	/* 175 */ null,
	/* 176 */ null,
	/* 177 */ null,
	/* 178 */ null,
	/* 179 */ null,
	/* 180 */ null,
	/* 181 */ null,
	/* 182 */ null,
	/* 183 */ null,
	/* 184 */ null,
	/* 185 */ "x",
	/* 186 */ "x",
	/* 187 */ null,
	0};
int BhavStr128Len = (sizeof BhavStr128/sizeof BhavStr128[0]) - 1;

const char *BhavStr129[] = {	// global labels
	/*  0 */ "hour",
	/*  1 */ "day of month",
	/*  2 */ "zoom level(S/M/L)",
	/*  3 */ "selected person ID",
	/*  4 */ "time of day",
	/*  5 */ "minute",
	/*  6 */ "second",
	/*  7 */ "month",
	/*  8 */ "year",
	/*  9 */ "current family",
	/* 10 */ "current house",
	/* 11 */ unused,
	/* 12 */ "last GZ button ID",
	/* 13 */ "budget mod 10000",
	/* 14 */ "budget div 10000",
	/* 15 */ "current language",
	/* 16 */ "speed",
	/* 17 */ "paused",
	/* 18 */ "held sim speed",
	/* 19 */ "mode",
	/* 20 */ "game edition",
	/* 21 */ "inhibit move in",
	/* 22 */ "lot has house",
	/* 23 */ "lot size",
	/* 24 */ "demo/is-online/UNUSED",
	/* 25 */ "debug flags",
	/* 26 */ "is tutorial house",
	/* 27 */ "indoor tiles",
	/* 28 */ "days running",
	/* 29 */ "maximum day number",
	/* 30 */ "free will",
	/* 31 */ "house radio station",
	// added in HotDate
	/* 32 */ "simless build mode[HD]",
	/* 33 */ "machine level[HD]",
	// added in Vacation
	/* 34 */ "animation rate[V]",
	/* 35 */ "lot type[V]",
	/* 36 */ "enable grass simulation[V]",
	// added in Unleashed
	/* 37 */ "filter flags for transit screen[U]",
	0};
int BhavStr129Len = (sizeof BhavStr129/sizeof BhavStr129[0]) - 1;

const char *BhavStr130[] = {	// relative locations
	/*  0 */ "on top of",
	/*  1 */ "anywhere near",
	/*  2 */ "in front of",
	/*  3 */ "front and to the right of",
	/*  4 */ "to the right of",
	/*  5 */ "behind and to the right of",
	/*  6 */ "behind",
	/*  7 */ "behind and to the left of",
	/*  8 */ "to the left of",
	/*  9 */ "in front and to the left of",
	0};
int BhavStr130Len = (sizeof BhavStr130/sizeof BhavStr130[0]) - 1;

const char *BhavStr131[] = {	// relative directions
	/*  0 */ "facing",
	/*  1 */ "any direction",
	/*  2 */ "same direction",
	/*  3 */ "45o right of same direction",
	/*  4 */ "90o right of the same direction",
	/*  5 */ "45o left of opposing direction",
	/*  6 */ "opposing direction",
	/*  7 */ "45o right of opposing direction",
	/*  8 */ "90o right of opposing direction",
	/*  9 */ "45o left of same direction",
	0};
int BhavStr131Len = (sizeof BhavStr131/sizeof BhavStr131[0]) - 1;

const char *BhavStr132[] = {	// data owners
	/*  0 */ "my attribute",
	/*  1 */ "stack obj's attribute",
	/*  2 */ "targ obj attr(OBSOLETE)",
	/*  3 */ "my",
	/*  4 */ "stack obj's",
	/*  5 */ "targ obj's(OBSOLETE)",
	/*  6 */ "global (from simulation)",
	/*  7 */ "literal value",
	/*  8 */ "temp",
	/*  9 */ "params",
	/* 10 */ "stack obj ID",
	/* 11 */ "temp[temp]",
	/* 12 */ "menu advertisement",
	/* 13 */ "stack obj's temp",
	/* 14 */ "my motives",
	/* 15 */ "stack obj's motives",
	/* 16 */ "stack obj's slot",
	/* 17 */ "stack obj's motive[temp]",
	/* 18 */ "my person data",
	/* 19 */ "stack obj's person data",
	/* 20 */ "my slot",
	/* 21 */ "stack obj's definition",
	/* 22 */ "stack obj attr[param]",
	/* 23 */ "room[temp 0]",
	/* 24 */ "neighbor in stack obj",
	/* 25 */ "local",
	/* 26 */ "constant",
	/* 27 */ "dynamic sprite flag[temp] of stack obj",
	/* 28 */ "menu personality",
	/* 29 */ "menu min",
	/* 30 */ "my person data[temp]",
	/* 31 */ "stack obj's person data[temp]",
	/* 32 */ "neighbor's person data",
	/* 33 */ "job data[temp 0,1]",
	/* 34 */ "neighborhood data",
	/* 35 */ "stack obj's function",
	/* 36 */ "my type attr",
	/* 37 */ "stack obj's type attr",
	0};
int BhavStr132Len = (sizeof BhavStr132/sizeof BhavStr132[0]) - 1;

const char *BhavStr134[] = {	// motive strings
	/*  0 */ "motive[0]",
	/*  1 */ "motive[1]",
	/*  2 */ "motive[2]",
	/*  3 */ "mood",
	/*  4 */ "motive[4]",
	/*  5 */ "energy",
	/*  6 */ "comfort",
	/*  7 */ "hunger",
	/*  8 */ "hygiene",
	/*  9 */ "bladder",
	/* 10 */ "motive[10]",
	/* 11 */ "sleep state",
	/* 12 */ "motive[12] (stress)",
	/* 13 */ "room",
	/* 14 */ "social",
	/* 15 */ "fun",
	0};
int BhavStr134Len = (sizeof BhavStr134/sizeof BhavStr134[0]) - 1;

const char *BhavStr135[] = {	// miscellaneous strings
	/*  0 */ "N/A",
	/*  1 */ "save changes to tree table `$' before closing?",
	/*  2 */ "<maximum>",
	/*  3 */ "inc",
	/*  4 */ "dec",
	0};
int BhavStr135Len = (sizeof BhavStr135/sizeof BhavStr135[0]) - 1;

const char *BhavStr136[] = {	// operators
	/*  0 */ ">",
	/*  1 */ "<",
	/*  2 */ "Equals?",
	/*  3 */ "+=",
	/*  4 */ "-=",
	/*  5 */ "Assign To:",
	/*  6 */ "*=",
	/*  7 */ "/=",
	/*  8 */ "Flag Set?",
	/*  9 */ "Set Flag",
	/* 10 */ "Clear Flag",
	/* 11 */ "++ and <",
	/* 12 */ "mod=",
	/* 13 */ "and=",
	/* 14 */ ">=",
	/* 15 */ "<=",
	/* 16 */ "Not Equal To",
	/* 17 */ "-- and >",
	// added in Vacation
	/* 18 */ "or=",
	/* 19 */ "xor=",
	/* 20 */ "=sqrt(RHS)",
	0};
int BhavStr136Len = (sizeof BhavStr136/sizeof BhavStr136[0]) - 1;

const char *BhavStr137[] = {	// search types
	// where is this used?
	/*  0 */ "as close as possible to",
	/*  1 */ "above",
	/*  2 */ "below",
	0};
int BhavStr137Len = (sizeof BhavStr137/sizeof BhavStr137[0]) - 1;

const char *BhavStr139[] = {	// Primitives
	/*  0 */ "sleep",
	/*  1 */ "generic sims call",
	/*  2 */ "expression",
	/*  3 */ "find best interaction",
	/*  4 */ "grab",
	/*  5 */ "drop",
	/*  6 */ "change suit/accessory",
	/*  7 */ "refresh",
	/*  8 */ "random number",
	/*  9 */ "burn",
	/* 10 */ "tutorial",
	/* 11 */ "get distance to",
	/* 12 */ "get direction to",
	/* 13 */ "push interaction",
	/* 14 */ "find best object for function",
	/* 15 */ "tree break point",
	/* 16 */ "find location for",
	/* 17 */ "idle for input",
	/* 18 */ "remove object instance",
	/* 19 */ "make new character",
	/* 20 */ "run functional tree",
	/* 21 */ "show string (UNUSED)",
	/* 22 */ "look towards",
	/* 23 */ "play sound event",
	/* 24 */ "old relationship (DEPRECATED)",
	/* 25 */ "alter budget",
	/* 26 */ "relationship",
	/* 27 */ "go to relative position",
	/* 28 */ "run tree by name",
	/* 29 */ "set motive change",
	/* 30 */ "gosub found action",
	/* 31 */ "set to next",
	/* 32 */ "test object type",
	/* 33 */ "find five worst motives",
	/* 34 */ "UI effect",
	/* 35 */ "special effect",
	/* 36 */ "dialog",
	/* 37 */ "test sim interacting with",
	/* 38 */ unused,
	/* 39 */ unused,
	/* 40 */ unused,
	/* 41 */ "set balloon/headline",
	/* 42 */ "create new object instance",
	/* 43 */ "drop onto",
	/* 44 */ "animate sim",
	/* 45 */ "go to routing slot",
	/* 46 */ "snap",
	/* 47 */ "reach",
	/* 48 */ "stop ALL sounds",
	/* 49 */ "notify the stack object out of idle",
	/* 50 */ "add/change the action string",
	/* 51 */ "manage inventory[HD, animate object in TSO]",
	/* 52 */ "change light color[TSO]",
	/* 53 */ "change sun color[TSO]",
	/* 54 */ "point light at object[TSO]",
	/* 55 */ "sync field[TSO]",
	/* 56 */ "ownership[TSO]",
	/* 57 */ "start persistant dialog[TSO]",
	/* 58 */ "end persistant dialog[TSO]",
	/* 59 */ "update persistant dialog[TSO]",
	/* 60 */ "poll persistant dialog[TSO]",
	/* 61 */ "~unused[TSO]",
	/* 62 */ "invoke plugin[TSO]",
	/* 63 */ "get terrain info[TSO]",
	0};
int BhavStr139Len = (sizeof BhavStr139/sizeof BhavStr139[0]) - 1;

const char *BhavStr141[] = {	// Data labels
	/*  0 */ "graphic",
	/*  1 */ "direction",
	/*  2 */ "container ID",
	/*  3 */ "slot number",
	/*  4 */ "allowed height flags",
	/*  5 */ "wall adjacency flags",
	/*  6 */ "route ID",
	/*  7 */ "room impact",
	/*  8 */ "flags1",
	/*  9 */ "route preference",
	/* 10 */ "route penalty",
	/* 11 */ "object ID",
	/* 12 */ "target ID [OBSOLETE]",
	/* 13 */ "wall placement flags",
	/* 14 */ "slot hier number",
	/* 15 */ "repair state",
	/* 16 */ "light source",
	/* 17 */ "walk style",
	/* 18 */ "sim age",
	/* 19 */ "gender [OBSOLETE]",	// moved to person data
	/* 20 */ "tree table entry",
	/* 21 */ "birth minute",
	/* 22 */ "speed",
	/* 23 */ "rotation notches",
	/* 24 */ "birth hour",
	/* 25 */ "lockout count",
	/* 26 */ "parent ID",
	/* 27 */ "weight",
	/* 28 */ "support strength",
	/* 29 */ "room ID",
	/* 30 */ "room placement",
	/* 31 */ "prep value",
	/* 32 */ "cook value",
	/* 33 */ "surface value",
	/* 34 */ "hidden",
	/* 35 */ "temperature",
	/* 36 */ "dispose value",
	/* 37 */ "wash dish value",
	/* 38 */ "eating surface value",
	/* 39 */ "dirty level",
	/* 40 */ "flags2",
	/* 41 */ "current value",
	/* 42 */ "placement flags",
	/* 43 */ "movement flags",
	/* 44 */ "maximum grade",
	/* 45 */ "birth year",
	/* 46 */ "birth month",
	/* 47 */ "birth day",
	/* 48 */ "age in months",
	/* 49 */ "size",
	/* 50 */ "hide interaction",
	/* 51 */ "lighting contribution (0..100)",
	/* 52 */ "primitive result",
	/* 53 */ "wall block flags",
	/* 54 */ "primitive result ID",
	/* 55 */ "UNUSED classical score",
	/* 56 */ "UNUSED eclectic score",
	/* 57 */ "UNUSED trailer score",
	/* 58 */ "object version",
	/* 59 */ "category",
	/* 60 */ "simulate on pause",
	/* 61 */ "serving surface value",
	/* 62 */ "use count",
	/* 63 */ "exclusive placement flags",
	/* 64 */ "gardening value",
	/* 65 */ "wash hands value",
	/* 66 */ "function score",
	/* 67 */ "slot count",
	0};
int BhavStr141Len = (sizeof BhavStr141/sizeof BhavStr141[0]) - 1;

const char *BhavStr142[] = {	// flags for flag field
	/*  0 */ unused,
	/*  1 */ "disallow person intersection",
	/*  2 */ "has zero extent",
	/*  3 */ "can walk",
	/*  4 */ "allow person intersection",
	/*  5 */ "in use",
	/*  6 */ "notified by idle for input",
	/*  7 */ unused,
	/*  8 */ "chair facing",
	/*  9 */ "burning",
	/* 10 */ "hide for cutaway",
	/* 11 */ "fireproof",
	// added in Vacation
	/* 12 */ "allow walk on water[V]",
	// added in Unleashed
	/* 13 */ "not slot zero exclusive[U]",
	0};
int BhavStr142Len = (sizeof BhavStr142/sizeof BhavStr142[0]) - 1;

const char *BhavStr150[] = {	// avatar action labels
	/*  0 */ "step with left foot",
	/*  1 */ "step with right foot",
	/*  2 */ "turn left",
	/*  3 */ "turn right",
	/*  4 */ "walk",
	/*  5 */ "stop",
	/*  6 */ "interact",
	0};
int BhavStr150Len = (sizeof BhavStr150/sizeof BhavStr150[0]) - 1;

const char *BhavStr153[] = {	// short owner list
	/*  0 */ "my",
	/*  1 */ "stack obj's",
	/*  2 */ "target's [OBSOLETE]",
	0};
int BhavStr153Len = (sizeof BhavStr153/sizeof BhavStr153[0]) - 1;

const char *BhavStr154[] = {	// tracer action strings
	/*  0 */ "dead",
	/*  1 */ "stopped",
	/*  2 */ "break",
	/*  3 */ "running",
	/*  4 */ "stepping over",
	/*  5 */ "stepping into",
	/*  6 */ "stepping out",
	/*  7 */ "watching",
	/*  8 */ "editing",
	/*  9 */ "suspended",
	/* 10 */ "system break (Mac only)",
	/* 11 */ "error",
	0};
int BhavStr154Len = (sizeof BhavStr154/sizeof BhavStr154[0]) - 1;

const char *BhavStr155[] = {	// Tracer Menu Strings
	/*  0 */ "data...",
	/*  1 */ "stack...",
	/*  2 */ "tree table...",
	/*  3 */ "weights...",
	/*  4 */ "needs...",
	/*  5 */ "sounds...",
	/*  6 */ "behaviors...",
	/*  7 */ "relationships...",
	/*  8 */ "slots...",
	/*  9 */ "reset object",
	0};
int BhavStr155Len = (sizeof BhavStr155/sizeof BhavStr155[0]) - 1;

#if 0	// use BhavStr153 - short owner list
const char *BhavStr156[] = {	// kill object options
	/*  0 */ "my",
	/*  1 */ "stack obj's",
	/*  2 */ "target's [OBSOLETE]",
	0};
int BhavStr156Len = (sizeof BhavStr156/sizeof BhavStr156[0]) - 1;
#endif

const char *BhavStr157[] = {	// tree types
	// where is this used?
	/*  0 */ "generic",
	/*  1 */ "portal",
	/*  2 */ "check",
	/*  3 */ "container",
	/*  4 */ "switch",
	0};
int BhavStr157Len = (sizeof BhavStr157/sizeof BhavStr157[0]) - 1;

const char *BhavStr158[] = {	// showhide
	// data labels:34 - hidden?  But see STR# 177
	/*  0 */ "show",
	/*  1 */ "hide",
	0};
int BhavStr158Len = (sizeof BhavStr158/sizeof BhavStr158[0]) - 1;

const char *BhavStr159[] = {	// headline prim
	/*  0 */ "local",
	/*  1 */ "global",
	0};
int BhavStr159Len = (sizeof BhavStr159/sizeof BhavStr159[0]) - 1;

const char *BhavStr160[] = {	// set headline 2
	/*  0 */ "me",
	/*  1 */ "stack obj",
	0};
int BhavStr160Len = (sizeof BhavStr160/sizeof BhavStr160[0]) - 1;

const char *BhavStr161[] = {	// bubble icons
	/*  0 */ "food",
	/*  1 */ "toilet",
	/*  2 */ "wired",
	/*  3 */ "shower",
	/*  4 */ "lightning",
	/*  5 */ "comfy chair",
	/*  6 */ "TV",
	/*  7 */ "snooze",
	/*  8 */ "sleepy",
	/*  9 */ "very tired",
	/* 10 */ "dancing",
	/* 11 */ "doubly lit candle",
	/* 12 */ "candle",
	/* 13 */ "house",
	/* 14 */ "blah blah",
	/* 15 */ "weather",
	/* 16 */ "prayer",
	/* 17 */ "newspaper",
	/* 18 */ "government",
	0};
int BhavStr161Len = (sizeof BhavStr161/sizeof BhavStr161[0]) - 1;

const char *BhavStr162[] = {	// balloon types
	/*  0 */ "thought balloon",
	/*  1 */ "scream balloon",
	/*  2 */ "speak balloon",
	/*  3 */ "headline",
	0};
int BhavStr162Len = (sizeof BhavStr162/sizeof BhavStr162[0]) - 1;

const char *BhavStr163[] = {	// forever
	/*  0 */ "forever",
	/*  1 */ "-",
	/*  2 */ "flash 1",
	/*  3 */ "flash 2",
	0};
int BhavStr163Len = (sizeof BhavStr163/sizeof BhavStr163[0]) - 1;

const char *BhavStr164[] = {	// next object param
	/*  0 */ "object",
	/*  1 */ "person",
	/*  2 */ "non-person",
	/*  3 */ "part of a multi-tile obj",
	/*  4 */ "obj of type",
	/*  5 */ "neighbor ID",
	/*  6 */ "obj with category == param[0]",
	/*  7 */ "neighbor of type",
	/*  8 */ "obj on same tile",
	/*  9 */ "obj adjacent to obj in ",
	/* 10 */ "carreer",
	/* 11 */ "closest house",
	/* 12 */ "family member[V]",
	0};
int BhavStr164Len = (sizeof BhavStr164/sizeof BhavStr164[0]) - 1;

const char *BhavStr165[] = {	// motive search types
	/*  0 */ "motives",
	/*  1 */ "mental motives",
	/*  2 */ "physical motives",
	0};
int BhavStr165Len = (sizeof BhavStr165/sizeof BhavStr165[0]) - 1;

const char *BhavStr167[] = {	// where to create the object
	/*  0 */ "in front of me",
	/*  1 */ "on top of me",
	/*  2 */ "in my hand",
	/*  3 */ "in front of stack obj",
	/*  4 */ "in slot 0 of stack obj",
	/*  5 */ "in my tile",		// walk-over-able objects only
	/*  6 */ "in stack obj",	// out of world
	/*  7 */ "in tile of obj in ",	// param[0]
	/*  8 */ "in tile of obj in ",	// local[x]
	/*  9 */ "next to me in direction of ",	// local[x]
	0};
int BhavStr167Len = (sizeof BhavStr167/sizeof BhavStr167[0]) - 1;

const char *BhavStr168[] = {	// how to create the object
	/*  0 */ "create obj normally.",
	/*  1 */ "do not duplicate obj.",
	/*  2 */ "transfer current stack obj to new obj and put my ID in param 0",
	0};
int BhavStr168Len = (sizeof BhavStr168/sizeof BhavStr168[0]) - 1;

const char *BhavStr169[] = {	// rel. var. get/set
	/*  0 */ "get",
	/*  1 */ "set",
	0};
int BhavStr169Len = (sizeof BhavStr169/sizeof BhavStr169[0]) - 1;

const char *BhavStr170[] = {	// rel. var me/stack obj
	/*  0 */ "me to stack obj",
	/*  1 */ "stack obj to me",
	/*  2 */ "stack obj to param[0]",
	/*  3 */ "param[0] to stack obj",
	0};
int BhavStr170Len = (sizeof BhavStr170/sizeof BhavStr170[0]) - 1;

const char *BhavStr171[] = {	// rel. var if not exist
	/*  0 */ "create new relationship",
	/*  1 */ "fail",
	0};
int BhavStr171Len = (sizeof BhavStr171/sizeof BhavStr171[0]) - 1;

const char *BhavStr172[] = {	// interrupt
	/*  0 */ "do not allow",
	/*  1 */ "allow",
	0};
int BhavStr172Len = (sizeof BhavStr172/sizeof BhavStr172[0]) - 1;

const char *BhavStr173[] = {	// spend ref.
	/*  0 */ "literal value",
	/*  1 */ "parameter",
	/*  2 */ "local variable",
	0};
int BhavStr173Len = (sizeof BhavStr173/sizeof BhavStr173[0]) - 1;

const char *BhavStr174[] = {	// Where to reach
	/*  0 */ "reach to the stack obj",
	/*  1 */ "reach to a slot on the stack obj",
	/*  2 */ "reach to mouth",
	0};
int BhavStr174Len = (sizeof BhavStr174/sizeof BhavStr174[0]) - 1;

const char *BhavStr176[] = {	// 0123
	/*  0 */ "0",
	/*  1 */ "1",
	/*  2 */ "2",
	/*  3 */ "3",
	0};
int BhavStr176Len = (sizeof BhavStr176/sizeof BhavStr176[0]) - 1;

#if 0	// use BhavStr153 - short owner list
const char *BhavStr177[] = {	// who to show hide
	/*  0 */ "me",
	/*  1 */ "stack obj",
	0};
int BhavStr177Len = (sizeof BhavStr177/sizeof BhavStr177[0]) - 1;
#endif

const char *BhavStr178[] = {	// censorship flags
	// person data:30 - censorship flags
	/*  0 */ "pelvis",
	/*  1 */ "spine if female",
	/*  2 */ "head",
	/*  3 */ "left hand",
	/*  4 */ "right hand",
	/*  5 */ "left foot",
	/*  6 */ "right foot",
	/*  7 */ "full body",
	0};
int BhavStr178Len = (sizeof BhavStr178/sizeof BhavStr178[0]) - 1;

const char *BhavStr200[] = {	// Person Data Labels
	/*   0 */ "sitting state",
	/*   1 */ "money amount over head",
	/*   2 */ "niceness|loyalty",
	/*   3 */ "active|playful",
	/*   4 */ "generousity (UNUSED)",
	/*   5 */ "playful|smart",
	/*   6 */ "outgoing|friendly",
	/*   7 */ "neat|quiet",
	/*   8 */ "current outfit",
	/*   9 */ "cleaning skill",
	/*  10 */ "cooking|housebroken",
	/*  11 */ "charisma|obedience",
	/*  12 */ "mechanical|tricks",
	/*  13 */ "exercise interest[HD])",
	/*  14 */ "food interest[HD]",
	/*  15 */ "creativity",
	/*  16 */ "party interest[HD]",
	/*  17 */ "body|furniture",
	/*  18 */ "logic skill",
	/*  19 */ "UNUSED 19/DO NOT USE",
	/*  20 */ "style interest",	// originally "personal style"
	/*  21 */ "costume trunk offset[HP]",
	/*  22 */ "left hand gesture",
	/*  23 */ "right hand gesture",
	/*  24 */ "job data",
	/*  25 */ "scratch1",
	/*  26 */ "Hollywood interest[HD]",
	/*  27 */ "tick counter",
	/*  28 */ "scratch2",
	/*  29 */ "motives static",
	/*  30 */ "censorship flags",
	/*  31 */ "neighbor ID",
	/*  32 */ "person type",
	/*  33 */ "priority",
	/*  34 */ "greet status",
	/*  35 */ "visitor schedule",
	/*  36 */ "autonomy level",
	/*  37 */ "route entry flags",
	/*  38 */ "multiple routes",
	/*  39 */ "routing complete",
	/*  40 */ "walking up stairs",
	/*  41 */ "head seek object",
	/*  42 */ "head seek state",
	/*  43 */ "head seek finish action",
	/*  44 */ "head seek limit action",
	/*  45 */ "head seek timeout",
	/*  46 */ "travel|toys interest",
	/*  47 */ "violence|aliens interest",
	/*  48 */ "politics|pets interest",
	/*  49 */ "60s|school interest",
	/*  50 */ "weather interest",
	/*  51 */ "sports interest",
	/*  52 */ "music interest",
	/*  53 */ "outdoors interest",
	/*  54 */ "technology interest[HD]",
	/*  55 */ "romance interest[HD]",
	/*  56 */ "job type",
	/*  57 */ "job promotion level",
	/*  58 */ "age",
	/*  59 */ "social object ID[HD]",
	/*  60 */ "skin color",
	/*  61 */ "family number",
	/*  62 */ "route result",
	/*  63 */ "job performance",
	/*  64 */ "is swimming",
	/*  65 */ "gender",
	/*  66 */ "private",
	/*  67 */ "lingering house number",
	/*  68 */ "is ghost",
	/*  69 */ "last day at work",
	/*  70 */ "zodiac",
	/*  71 */ "non-interruptible",
	/*  72 */ "route footprint mask",
	/*  73 */ "footprint extension",
	/*  74 */ "display flags",
	/*  75 */ "female preference[HD]",
	/*  76 */ "male preference[HD]",
	/*  77 */ "autoFollow[HD]",
	/*  78 */ "freeze for idle[HD]",
	/*  79 */ "obj soc avail flags[HD]",
	0};
int BhavStr200Len = (sizeof BhavStr200/sizeof BhavStr200[0]) - 1;

const char *BhavStr201Obj[] = {	// Functions
	/*  0 */ "preparing food",
	/*  1 */ "cooking food",
	/*  2 */ "flat surface",
	/*  3 */ "disposing",
	/*  4 */ "eating",
	/*  5 */ "picking up from slot",
	/*  6 */ "washing dish",
	/*  7 */ "eating surface",
	/*  8 */ "siting",
	/*  9 */ "standing",
	/* 10 */ "serving surface",
	/* 11 */ "cleaning",
	/* 12 */ "gardening",
	/* 13 */ "washing hands",
	/* 14 */ "repairing",
	/* 15 */ "sleeping[V]",
	0};
const char *BhavStr201Run[] = {	// Functions
	/*  0 */ "prepare food",
	/*  1 */ "cook food",
	/*  2 */ "put on flat surface",
	/*  3 */ "dispose",
	/*  4 */ "eat",
	/*  5 */ "pick up from slot",
	/*  6 */ "wash dish",
	/*  7 */ "put on eating surface",
	/*  8 */ "sit",
	/*  9 */ "stand",
	/* 10 */ "put on serving surface",
	/* 11 */ "clean",
	/* 12 */ "garden",
	/* 13 */ "wash hands",
	/* 14 */ "repair",
	/* 15 */ "sleep[V]",
	0};
int BhavStr201Len = (sizeof BhavStr201Obj/sizeof BhavStr201Obj[0]) - 1;

const char *BhavStr202[] = {	// Placement Flags
	/*  0 */ "on floor",
	/*  1 */ "on terrain",
	/*  2 */ "on water",
	/*  3 */ "on surface",
	/*  4 */ "on door",
	/*  5 */ "on window",
	/*  6 */ "on locked tile",
	/*  7 */ unused,
	/*  8 */ "on slope",
	/*  9 */ "in air",
	/* 10 */ "in wall",
	/* 11 */ "allow on pool",
	/* 12 */ "require pool",
	/* 13 */ "require water[V]",
	0};
int BhavStr202Len = (sizeof BhavStr202/sizeof BhavStr202[0]) - 1;

const char *BhavStr203[] = {	// Movement Flags
	/*  0 */ "sims can move it",
	/*  1 */ "players can move it",
	/*  2 */ "self propelled",
	/*  3 */ "players can delete it",
	/*  4 */ "stays after evict",
	0};
int BhavStr203Len = (sizeof BhavStr203/sizeof BhavStr203[0]) - 1;

const char *BhavStr204[] = {	// definition labels
	/*  0 */ "version_1",
	/*  1 */ "version_2",
	/*  2 */ "initial stack size",
	/*  3 */ "base graphic",
	/*  4 */ "num graphics",
	/*  5 */ "old tree ID (main)",
	/*  6 */ "old tree ID (gardening)",
	/*  7 */ "tree table ID",
	/*  8 */ "interaction group",
	/*  9 */ "object type",
	/* 10 */ "master ID",
	/* 11 */ "sub index",
	/* 12 */ "old tree ID (wash hands)",
	/* 13 */ "anim table ID",
	/* 14 */ "GUID_1",
	/* 15 */ "GUID_2",
	/* 16 */ "disabled",
	/* 17 */ "old tree ID (portal)",
	/* 18 */ "price",
	/* 19 */ "body strings ID",
	/* 20 */ "slots ID",
	/* 21 */ "old tree ID (allow intersection)",
	/* 22 */ unused,
	/* 23 */ unused,
	/* 24 */ "old tree ID (prepare food)",
	/* 25 */ "old tree ID (cook food)",
	/* 26 */ "old tree ID (place on surface)",
	/* 27 */ "old tree ID (dispose)",
	/* 28 */ "old tree ID (eat food)",
	/* 29 */ "old tree ID (pick up from slot)",
	/* 30 */ "old tree ID (wash dish)",
	/* 31 */ "old tree ID (eating surface)",
	/* 32 */ "old tree ID (sit)",
	/* 33 */ "old tree ID (stand)",
	/* 34 */ "sale price",
	/* 35 */ "initial depreciation",
	/* 36 */ "daily depreciation",
	/* 37 */ "self depreciating",
	/* 38 */ "depreciation limit",
	/* 39 */ "room sort",
	/* 40 */ "function sort",
	/* 41 */ "catalog strings ID",
	/* 42 */ "is global sim object",
	/* 43 */ "old tree ID (init)",
	/* 44 */ "old tree ID (place)",
	/* 45 */ "old tree ID (user pick up)",
	/* 46 */ "wall style",
	/* 47 */ "old tree ID (load)",
	/* 48 */ "old tree ID (user place)",
	/* 49 */ "object version",
	/* 50 */ "old tree ID (room changed)",
	/* 51 */ "motive effects ID",
	/* 52 */ "old tree ID (cleanup)",
	/* 53 */ "old tree ID (level info request)",
	/* 54 */ "catalog popup ID",
	/* 55 */ "old tree ID (serving surface)",
	/* 56 */ "level offset",
	/* 57 */ "shadow",
	/* 58 */ "num attributes",
	/* 59 */ "old tree ID (clean)",
	/* 60 */ "old tree ID (queue skipped)",
	/* 61 */ "front direction",
	/* 62 */ "old tree ID (wall adjacency changed)",
	/* 63 */ "MT lead object",
	/* 64 */ "dynamic sprites base ID",
	/* 65 */ "num dynamic sprites",
	/* 66 */ "chair entry flags",
	/* 67 */ "tile width",
	/* 68 */ "inhibit suit copying",
	/* 69 */ "build mode type",
	/* 70 */ "original GUID_1",
	/* 71 */ "original GUID_2",
	/* 72 */ "suit GUID_1",
	/* 73 */ "suit GUID_2",
	/* 74 */ "old tree ID (pick up)",
	/* 75 */ "thumbnail graphic",
	/* 76 */ "shadow flags",
	/* 77 */ "footprint mask",
	/* 78 */ "old tree ID (dynamic multi-tile update)",
	/* 79 */ "shadow brightness",
	/* 80 */ "old tree ID (repair)",
	/* 81 */ "wall style sprite ID",
	/* 82 */ "hunger rating",
	/* 83 */ "comfort rating",
	/* 84 */ "hygiene rating",
	/* 85 */ "bladder rating",
	/* 86 */ "energy rating",
	/* 87 */ "fun rating",
	/* 88 */ "room rating",
	/* 89 */ "rating skill flags",
	/* 90 */ "num type attributes",
	/* 91 */ "misc flags",
	/* 92 */ "type attr GUID_1",
	/* 93 */ "type attr GUID_2",
	/* 94 */ "function sub-sort[HD]",
	/* 95 */ "downtown sort[HD]",
	/* 96 */ "keep buying[HD]",
	/* 97 */ "vacation sort[V]",
	/* 98 */ "reset lot action[V]",
	/* 99 */ "community sort[U]",
	/* 100 */ "dream flags[U]",
	/* 101 */ "render flags[U]",
	0};
int BhavStr204Len = (sizeof BhavStr204/sizeof BhavStr204[0]) - 1;

const char *BhavStr205[] = {	// Room sort flags
	// definition labels:39 - room sort
	/*  0 */ "kitchen",
	/*  1 */ "bedroom",
	/*  2 */ "bathroom",
	/*  3 */ "family room",
	/*  4 */ "outside",
	/*  5 */ "dining room",
	/*  6 */ "miscellaneous",
	/*  7 */ "study",
	0};
int BhavStr205Len = (sizeof BhavStr205/sizeof BhavStr205[0]) - 1;

const char *BhavStr206[] = {	// Function sort flags
	// definition labels:40 - function sort
	/*  0 */ "seating",
	/*  1 */ "surfaces",
	/*  2 */ "appliances",
	/*  3 */ "electronics",
	/*  4 */ "plumbing",
	/*  5 */ "decorative",
	/*  6 */ "general",
	/*  7 */ "lighting",
	0};
int BhavStr206Len = (sizeof BhavStr206/sizeof BhavStr206[0]) - 1;

const char *BhavStr207[] = {	// How To Snap
	/*  0 */ "slot number in stack param",
	/*  1 */ "contained in the stack obj",
	/*  2 */ "in front of the stack obj",
	/*  3 */ "slot number",
	/*  4 */ "global slot",
	0};
int BhavStr207Len = (sizeof BhavStr207/sizeof BhavStr207[0]) - 1;

const char *BhavStr208[] = {	// wall adjacency flags
	/*  0 */ "wall on left",
	/*  1 */ "wall on right",
	/*  2 */ "wall in front",
	/*  3 */ "wall behind",
	/*  4 */ "wall above left",
	/*  5 */ "wall above right",
	0};
int BhavStr208Len = (sizeof BhavStr208/sizeof BhavStr208[0]) - 1;

const char *BhavStr209[] = {	// person render flags
	/*  0 */ "is invisible",
	/*  1 */ "is green (zombied)",
	0};
int BhavStr209Len = (sizeof BhavStr209/sizeof BhavStr209[0]) - 1;

const char *BhavStr210[] = {	// Personal Styles
	// person data labels:20 - personal style
	// unused in House Party
	// changed to style interest in Hot Date
	/*  0 */ "natural",
	/*  1 */ "romantic",
	/*  2 */ "dramatic",
	/*  3 */ "classical",
	/*  4 */ "eclectic",
	/*  5 */ "trailer park",
	0};
int BhavStr210Len = (sizeof BhavStr210/sizeof BhavStr210[0]) - 1;

#if 0	// use BhavStr153 - short owner list
const char *BhavStr211[] = {	// update who
	/*  0 */ "my",
	/*  1 */ "stack obj's",
	0};
int BhavStr211Len = (sizeof BhavStr211/sizeof BhavStr211[0]) - 1;
#endif

const char *BhavStr212[] = {	// update what
	/*  0 */ "graphic",
	/*  1 */ "lighting contribution",
	/*  2 */ "room score contribution",
	0};
int BhavStr212Len = (sizeof BhavStr212/sizeof BhavStr212[0]) - 1;

#if 0	// probably a glitch
const char *BhavStr213[] = {	// update who
	// is this used?  or is it just a glitch that should be 214?
	/*  0 */ "can break",
	/*  1 */ "can die",
	/*  2 */ "can be repossessed",
	/*  3 */ "obstructs view",
	/*  4 */ "floats",
	/*  5 */ "burns",
	/*  6 */ "fixable",
	/*  7 */ "can be stolen",
	/*  8 */ "generates heat",
	/*  9 */ "can be lighted",
	/* 10 */ "generates light",
	/* 11 */ "can get dirty",
	/* 12 */ "contributes to asthetic",
	0};
int BhavStr213Len = (sizeof BhavStr213/sizeof BhavStr213[0]) - 1;
#endif

const char *BhavStr214[] = {	// Flags for Flag Field 2
	/*  0 */ "can break",
	/*  1 */ "can die",
	/*  2 */ "can be repossessed",
	/*  3 */ "obstructs view",
	/*  4 */ "floats",
	/*  5 */ "burns",
	/*  6 */ "fixable",
	/*  7 */ "cannot be stolen",
	/*  8 */ "generates heat",
	/*  9 */ "can be lighted",
	/* 10 */ "generates light",
	/* 11 */ "can get dirty",
	/* 12 */ "contributes to asthetic",
	/* 13 */ "can't be billed",
	0};
int BhavStr214Len = (sizeof BhavStr214/sizeof BhavStr214[0]) - 1;

const char *BhavStr215[] = {	// Routing slot param types
	/*  0 */ "goto the routing slot with index specified in stack param",
	/*  1 */ "goto the literal routing slot number",
	/*  2 */ "goto the global slot",
	0};
int BhavStr215Len = (sizeof BhavStr215/sizeof BhavStr215[0]) - 1;

const char *BhavStr216[] = {	// how to look towards
	/*  0 */ "turn head towards stack obj",
	/*  1 */ "turn body towards camera",
	/*  2 */ "turn body towards stack obj",
	/*  3 */ "turn body away from stack obj",
	0};
int BhavStr216Len = (sizeof BhavStr216/sizeof BhavStr216[0]) - 1;

const char *BhavStr217[] = {	// dialog types
	/*  0 */ "message",
	/*  1 */ "yes-no",
	/*  2 */ "tri-choice",
	/*  3 */ "text entry",
	/*  4 */ "tutorial",
	/*  5 */ "downtown[HD]",
	/*  6 */ "clothing[HD]",
	/*  7 */ "vacation[V]",
	/*  8 */ "neighborhood[U]",
	/*  9 */ "pet choice[U]",
	/* 10 */ "phone book[U]",
	0};
int BhavStr217Len = (sizeof BhavStr217/sizeof BhavStr217[0]) - 1;

#if 0		// not used
const char *BhavStr218[] = {	// dialog type descriptions
	/*  0 */ "Display a dialog with a message and yes button.",
	/*  1 */ "Display a dialog with a message, a yes button and a no button. Return true on yes and false on no.",
	/*  2 */ "Display a dialog with a yes, no, and cancel button. If yes is chosen, returns true. If no is chosen, returns false and sets temp to 0. If cancel is chosen, returns false, and sets temp to 1.",
	/*  3 */ "Display a dialog with an OK button and a space for the user to type in a name. The next call to ""make new character"" will use the typed name as the name of the new character.",
	/*  4 */ "Display a tutorial dialog, with only an OK button.",
	/*  5 */ "Display A Downtown Lot Selection Dialog",
	/*  6 */ "Display a Change Clothes Dialog",
	0};
int BhavStr218Len = (sizeof BhavStr218/sizeof BhavStr218[0]) - 1;
#endif

const char *BhavStr219[] = {	// room values
	/*  0 */ "ambient light(0..100)",
	/*  1 */ "outside",
	/*  2 */ "level",
	/*  3 */ "area",
	0};
int BhavStr219Len = (sizeof BhavStr219/sizeof BhavStr219[0]) - 1;

const char *BhavStr220[] = {	// generic sim calls
	/*  0 */ "house tutorial complete",
	// /*  1 */ "UNUSED[LL] - center view on stack obj",
	/*  1 */ "swap my and stack obj's slots[HD]",
	/*  2 */ "set action icon to stack obj",
	// /*  3 */ "UNUSED[LL] - uncenter view",
	/*  3 */ "pull down taxi dialog[HD]",
	/*  4 */ "add stack obj to family",
	/*  5 */ "take assets of family in temp 0",
	/*  6 */ "remove stack obj from family",
	/*  7 */ "DEPRECATED - make new neighbor",
	/*  8 */ "family tutorial complete",
	/*  9 */ "architecture tutorial complete",
	/* 10 */ "disable build and buy",
	/* 11 */ "enable build and buy",
	/* 12 */ "temp 0 := distance to camera",
	/* 13 */ "abort interactions with stack obj",
	/* 14 */ "house radio station := temp 0",
	/* 15 */ "my footprint extension := temp 0",
	/* 16 */ "change normal outfit to next available",
// Added in Hot Date
	/* 17 */ "change to lot in temp 0[HD]",
	/* 18 */ "build the downtown Sim and place obj ID in temp 0[HD]",
	/* 19 */ "spawn downtown date of person in temp 0; place spawned autofollow Sim in temp 0[HD]",
	/* 20 */ "spawn take back home date of person in temp 0; place spawned autofollow Sim in temp 0[HD]",
	/* 21 */ "spawn inventory SimData effects[HD]",
	/* 22 */ "select downtown lot[HD]",
	/* 23 */ "get downtown time from SO's inventory(Hours in T0, Minutes in T1)[HD]",
	/* 24 */ "change suits permanently[HD]",
	/* 25 */ "save this Sim's persistent data[HD]",
// Added in Vacation
	/* 26 */ "build vacation family; temp 0 := family number[V]",
	/* 27 */ "temp 0 :=  number of available vacation lots[V]",
// Added in Unleashed
	/* 28 */ "temp 0 := temp[0]'s lot's zoning type[U]",
	/* 29 */ "set stack obj's suit: type := temp[0], index := temp[1]; temp[1] := old index[U]",
	/* 30 */ "get stack obj's suit: temp[0] := type. temp[1] := index[U]",
	/* 31 */ "temp[1] := count stack obj's suits of type temp[0][U]",
	/* 32 */ "create all purchased pets near owner[U]",
	/* 33 */ "add to family in temp 0[U]",
	0};
int BhavStr220Len = (sizeof BhavStr220/sizeof BhavStr220[0]) - 1;

const char *BhavStr221[] = {	// neighbor data labels
	/*  0 */ "person instance ID",
	/*  1 */ "belongs in house",
	/*  2 */ "person age",
	/*  3 */ "relationship raw score",
	/*  4 */ "relationship score",
	/*  5 */ "friend count",
	/*  6 */ "house number",
	/*  7 */ "has telephone",
	/*  8 */ "has baby",
	/*  9 */ "family friend count",
	0};
int BhavStr221Len = (sizeof BhavStr221/sizeof BhavStr221[0]) - 1;

const char *BhavStr222[] = {	// how to call named tree
	/*  0 */ "run in my stack",
	/*  1 */ "run in stack obj's stack",
	/*  2 */ "push onto my stack",
	0};
int BhavStr222Len = (sizeof BhavStr222/sizeof BhavStr222[0]) - 1;

const char *BhavStr224[] = {	// priorities
	// person data labels:33 - priority
	/*  0 */ "inherited",
	/*  1 */ "max",
	/*  2 */ "autonomous",
	/*  3 */ "user",
	0};
int BhavStr224Len = (sizeof BhavStr224/sizeof BhavStr224[0]) - 1;

const char *BhavStr225[] = {	// times of day
	// is this used somewhere?
	/*  0 */ "day",
	/*  1 */ "dusk",
	/*  2 */ "night",
	/*  3 */ "dawn",
	0};
int BhavStr225Len = (sizeof BhavStr225/sizeof BhavStr225[0]) - 1;

const char *BhavStr226[] = {	// tree categories
	// is this used somewhere?
	/*  0 */ "primitives",
	/*  1 */ "global trees",
	/*  2 */ "private trees",
	/*  3 */ "semi global trees",
	/*  4 */ "tree tables",
	/*  5 */ "semi global tree tables",
	/*  6 */ "private strings",
	/*  7 */ "semi global strings",
	/*  8 */ "global strings",
	/*  9 */ "private constants",
	/* 10 */ "semi global constants",
	/* 11 */ "global constants",
	0};
int BhavStr226Len = (sizeof BhavStr226/sizeof BhavStr226[0]) - 1;

const char *BhavStr227[] = {	// suit locations
	/*  0 */ "global",
	/*  1 */ "person",
	/*  2 */ "object",
	// Added in Hot Date
	/*  3 */ "object model",
	0};
int BhavStr227Len = (sizeof BhavStr227/sizeof BhavStr227[0]) - 1;

const char *BhavStr228[] = {	// dress/undress
	/*  0 */ "add",
	/*  1 */ "remove",
	0};
int BhavStr228Len = (sizeof BhavStr228/sizeof BhavStr228[0]) - 1;

const char *BhavStr229[] = {	// wall placement flags
	/*  0 */ "wall required in front",
	/*  1 */ "wall required on right",
	/*  2 */ "wall required behind",
	/*  3 */ "wall required on left",
	/*  4 */ "corner not allowed",
	/*  5 */ "corner required",
	/*  6 */ "diagonal required",
	/*  7 */ "diagonal allowed",
	/*  8 */ "wall not allowed in front",
	/*  9 */ "wall not allowed on right",
	/* 10 */ "wall not allowed behind",
	/* 11 */ "wall not allowed on left",
	0};
int BhavStr229Len = (sizeof BhavStr229/sizeof BhavStr229[0]) - 1;

const char *BhavStr230[] = {	// entry types
	// is this present somewhere?
	/*  0 */ "unknown",
	/*  1 */ "interaction",
	/*  2 */ "check tree",
	/*  3 */ "functional",
	/*  4 */ "callback",
	/*  5 */ "subroutine",
	0};
int BhavStr230Len = (sizeof BhavStr230/sizeof BhavStr230[0]) - 1;

const char *BhavStr231[] = {	// what to burn
	/*  0 */ "stack obj",
	/*  1 */ "tile in front of stack obj",
	/*  2 */ "floor under stack obj",
	0};
int BhavStr231Len = (sizeof BhavStr231/sizeof BhavStr231[0]) - 1;

const char *BhavStr232[] = {	// personality ads
	// data owner:28 - menu personality
	/*  0 */ "none",
	/*  1 */ "nice|loyal",
	/*  2 */ "grouchy|not loyal",
	/*  3 */ "active|playful",
	/*  4 */ "lazy|serious",
	/*  5 */ "generous(unused)",
	/*  6 */ "selfish(unused)",
	/*  7 */ "playful|smart",
	/*  8 */ "serious|stupid",
	/*  9 */ "outgoing|friendly",
	/* 10 */ "shy|mean",
	/* 11 */ "neat|quiet",
	/* 12 */ "sloppy|loud",
	/* 13 */ "cleaning skill",
	/* 14 */ "cooking|housebroken skill",
	/* 15 */ "charisma|obedience skill",
	/* 16 */ "mechanical|tricks skill",
	/* 17 */ "gardening skill(unused)",
	/* 18 */ "music skill(unused)",
	/* 19 */ "creative skill",
	/* 20 */ "literacy skill(unused)",
	/* 21 */ "body|furniture skill",
	/* 22 */ "logic skill",
	0};
int BhavStr232Len = (sizeof BhavStr232/sizeof BhavStr232[0]) - 1;

const char *BhavStr233[] = {	// attenuations
	/*  0 */ "custom",
	/*  1 */ "none",
	/*  2 */ "low",
	/*  3 */ "moderate",
	/*  4 */ "high",
	0};
int BhavStr233Len = (sizeof BhavStr233/sizeof BhavStr233[0]) - 1;

const char *BhavStr234[] = {	// build mode types
	// definition labels:69 - build mode type
	/*  0 */ "none",
	/*  1 */ "door",
	/*  2 */ "window",
	/*  3 */ "stair",
	/*  4 */ "plant",
	/*  5 */ "fireplace",
	/*  6 */ "column",
	/*  7 */ "pool equipment",
	0};
int BhavStr234Len = (sizeof BhavStr234/sizeof BhavStr234[0]) - 1;

const char *BhavStr235[] = {	// which relationship 2
	/*  0 */ "me to stack obj",
	/*  1 */ "stack obj to me",
	/*  2 */ "stack obj to obj in local",
	/*  3 */ "obj in local to stack obj",
	0};
int BhavStr235Len = (sizeof BhavStr235/sizeof BhavStr235[0]) - 1;

const char *BhavStr236[] = {	// object light sources
	// data labels:16 - light source
	/*  0 */ "none",
	/*  1 */ "lamp",
	0};
int BhavStr236Len = (sizeof BhavStr236/sizeof BhavStr236[0]) - 1;

const char *BhavStr237[] = {	// dialog behavior
	/*  0 */ "engage and block sim",
	/*  1 */ "return and block sim",
	/*  2 */ "engage and continue sim",
	/*  3 */ "return and continue sim",
	0};
int BhavStr237Len = (sizeof BhavStr237/sizeof BhavStr237[0]) - 1;

const char *BhavStr238[] = {	// situation action descriptions
	/*  0 */ "begin",
	/*  1 */ "end",
	0};
int BhavStr238Len = (sizeof BhavStr238/sizeof BhavStr238[0]) - 1;

const char *BhavStr239[] = {	// find good location behaviors
	/*  0 */ "normal",
	/*  1 */ "out-of-world",
	/*  2 */ "smoke",
	/*  3 */ "object vector",
	/*  4 */ "lateral",
	// added in Hot Date
	/*  5 */ "random[HD]",
	0};
int BhavStr239Len = (sizeof BhavStr239/sizeof BhavStr239[0]) - 1;

const char *BhavStr240[] = {	// expense types
	/*  0 */ "misc expense",
	/*  1 */ "job income",
	/*  2 */ "misc income",
	/*  3 */ "food expense",
	/*  4 */ "bill payment",
	/*  5 */ "maint expense",
	/*  6 */ "purchase",
	/*  7 */ "architecture",
	0};
int BhavStr240Len = (sizeof BhavStr240/sizeof BhavStr240[0]) - 1;

const char *BhavStr241[] = {	// route result codes
	// person data labels:62 - route result
	/*  0 */ "success",
	/*  1 */ "unknown",
	/*  2 */ "room could not be reached",
	/*  3 */ "path not found",
	/*  4 */ "interrupted",
	/*  5 */ "couldnt sit down",
	/*  6 */ "couldnt stand up",
	/*  7 */ "no valid goals",
	/*  8 */ "dest tile occupied",
	/*  9 */ "dest chair occupied",
	/* 10 */ "no chair found",
	/* 11 */ "wall in the way",
	/* 12 */ "altitudes don't match",
	/* 13 */ "dest tile occupied by person",
	0};
int BhavStr241Len = (sizeof BhavStr241/sizeof BhavStr241[0]) - 1;

const char *BhavStr242[] = {	// add subtract
	// unknown
	/*  0 */ "add",
	/*  1 */ "subtract",
	0};
int BhavStr242Len = (sizeof BhavStr242/sizeof BhavStr242[0]) - 1;

const char *BhavStr243[] = {	// job data
	/*  0 */ "number of levels",
	/*  1 */ "salary",
	/*  2 */ "min friend count",
	/*  3 */ "min cook skill",
	/*  4 */ "min repair skill",
	/*  5 */ "min social skill",
	/*  6 */ "min body skill",
	/*  7 */ "min logic skill",
	/*  8 */ "min creative skill",
	/*  9 */ "min req 7",
	/* 10 */ "min req 8",
	/* 11 */ "min req 9",
	/* 12 */ "start hour",
	/* 13 */ "end hour",
	/* 14 */ "hunger hourly delta",
	/* 15 */ "comfort hourly delta",
	/* 16 */ "hygiene hourly delta",
	/* 17 */ "bladder hourly delta",
	/* 18 */ "energy hourly delta",
	/* 19 */ "fun hourly delta",
	/* 20 */ "social hourly delta",
	/* 21 */ "car ID",
	/* 22 */ "has suit",
	0};
int BhavStr243Len = (sizeof BhavStr243/sizeof BhavStr243[0]) - 1;

const char *BhavStr244[] = {	// dialog icon types
	/*  0 */ "automatic",
	/*  1 */ "none",
	/*  2 */ "neighbor",
	/*  3 */ "indexed",
	/*  4 */ "named",
	0};
int BhavStr244Len = (sizeof BhavStr244/sizeof BhavStr244[0]) - 1;

const char *BhavStr245[] = {	// entry points
	/*  0 */ "init",
	/*  1 */ "main",
	/*  2 */ "load",
	/*  3 */ "cleanup",
	/*  4 */ "queue skipped",
	/*  5 */ "allow intersection",
	/*  6 */ "wall adjacency changed",
	/*  7 */ "room changed",
	/*  8 */ "dynamic multi-tile update",
	/*  9 */ "placement",
	/* 10 */ "pick up",
	/* 11 */ "user placement",
	/* 12 */ "user pick up",
	/* 13 */ "level info request",
	/* 14 */ "serving surface",
	/* 15 */ "portal",
	/* 16 */ "gardening",
	/* 17 */ "wash hands",
	/* 18 */ "prep",
	/* 19 */ "cook",
	/* 20 */ "surface",
	/* 21 */ "dispose",
	/* 22 */ "food",
	/* 23 */ "pick up from slot",
	/* 24 */ "wash dish",
	/* 25 */ "eating surface",
	/* 26 */ "sit",
	/* 27 */ "stand",
	/* 28 */ "clean",
	/* 29 */ "repair",
	/* 30 */ "UI event",
	0};
int BhavStr245Len = (sizeof BhavStr245/sizeof BhavStr245[0]) - 1;

const char *BhavStr246[] = {	// object types
	// object definition:9 - type ??
	// person data labels:32 - person type ??
	/*  0 */ "unknown",
	/*  1 */ unused,
	/*  2 */ "person",
	/*  3 */ unused,
	/*  4 */ "normal",
	/*  5 */ unused,
	/*  6 */ unused,
	/*  7 */ "sim type",
	/*  8 */ "portal",
	/*  9 */ "cursor",
	/* 10 */ unused,
	/* 11 */ "internal",
	0};
int BhavStr246Len = (sizeof BhavStr246/sizeof BhavStr246[0]) - 1;

const char *BhavStr247[] = {	// UI effects
	/*  0 */ "flashing button with ID ==",
	/*  1 */ "flashing neighbor with ID ==",
	/*  2 */ "flashing relationship button",
	0};
int BhavStr247Len = (sizeof BhavStr247/sizeof BhavStr247[0]) - 1;

const char *BhavStr248[] = {	// sim global modes
	/*  0 */ "live",
	/*  1 */ "build",
	/*  2 */ "buy",
	/*  3 */ "options",
	/*  4 */ "camera",
	0};
int BhavStr248Len = (sizeof BhavStr248/sizeof BhavStr248[0]) - 1;

const char *BhavStr249[] = {	// neighborhood data labels
	/*  0 */ "level complete",
	/*  1 */ "tutorial progress",
	/*  2 */ "tutorial house number",
	/*  3 */ "hide arrow",
	0};
int BhavStr249Len = (sizeof BhavStr249/sizeof BhavStr249[0]) - 1;

const char *BhavStr250[] = {	// outfits
	/*  0 */ "normal",
	/*  1 */ "naked",
	/*  2 */ "swimsuit",
	/*  3 */ "job",
	/*  4 */ "formal",
	/*  5 */ "sleep",
	/*  6 */ "skeleton",
	/*  7 */ "skeleton neg",
	// added in House Party to match PersonGlobal STR# 304
	/*  8 */ "toga[HP]",
	/*  9 */ "country/western[HP]",
	/* 10 */ "luau[HP]",
	/* 11 */ "rave[HP]",
	/* 12 */ "costume[HP]",
	/* 13 */ "expanded formal[HP]",
	/* 14 */ "expanded swimsuit[HP]",
	/* 15 */ "expanded pajamas[HP]",
	/* 16 */ "disco[HP]",
	// added in Vacation
	/* 17 */ "winter[V]",
	0};
int BhavStr250Len = (sizeof BhavStr250/sizeof BhavStr250[0]) - 1;

const char *BhavStr251[] = {	// exclusive placement flags
	/*  0 */ "floor",
	/*  1 */ "wall",
	0};
int BhavStr251Len = (sizeof BhavStr251/sizeof BhavStr251[0]) - 1;

const char *BhavStr252[] = {	// Game Edition
	/*  0 */ "Livin' Large",
	/*  1 */ "House Party",
	/*  2 */ "Hot Date",
	/*  3 */ "Vacation",
	/*  4 */ "Deluxe",
	/*  5 */ "Unleashed",
	0};
int BhavStr252Len = (sizeof BhavStr252/sizeof BhavStr252[0]) - 1;

const char *BhavStr500[] = {	// icon group labels
	/*  0 */ "old style",
	/*  1 */ "balloon",
	/*  2 */ "conversation",
	/*  3 */ "motive",
	/*  4 */ "relationship",
	/*  5 */ "headline",
	/*  6 */ "relationship/social/debug",
	/*  7 */ "algorithmic",
	/*  8 */ "route failure",
	/*  9 */ "progress",
	0};
int BhavStr500Len = (sizeof BhavStr500/sizeof BhavStr500[0]) - 1;

const char *BhavStr501[] = {	// conversation icon labels
	// changed in Livin' Large from five icons/category to
	// three icons/category and more categories
	/*  0 */ "STR#501[temp[0]]",	// "Travel 1",
	/*  1 */ "travel 2",
	/*  2 */ "travel 3",
	/*  3 */ "violence 1",
	/*  4 */ "violence 2",
	/*  5 */ "violence 3",
	/*  6 */ "politics 1",
	/*  7 */ "politics 2",
	/*  8 */ "politics 3",
	/*  9 */ "60s 1",
	/* 10 */ "60s 2",
	/* 11 */ "60s 3",
	/* 12 */ "weather 1",
	/* 13 */ "weather 2",
	/* 14 */ "weather 3",
	/* 15 */ "sports 1",
	/* 16 */ "sports 2",
	/* 17 */ "sports 3",
	/* 18 */ "music 1",
	/* 19 */ "music 2",
	/* 20 */ "music 3",
	/* 21 */ "outdoor 1",
	/* 22 */ "outdoor 2",
	/* 23 */ "outdoor 3",
	/* 24 */ "toys 1",
	/* 25 */ "toys 2",
	/* 26 */ "toys 3",
	/* 27 */ "aliens 1",
	/* 28 */ "aliens 2",
	/* 29 */ "aliens 3",
	// added in Livin' Large
	/* 30 */ "pets 1",
	/* 31 */ "pets 2",
	/* 32 */ "pets 3",
	/* 33 */ "school 1",
	/* 34 */ "school 2",
	/* 35 */ "school 3",
	// added in Hot Date
	/* 36 */ "exercise #1",
	/* 37 */ "exercise #2",
	/* 38 */ "exercise #3",
	/* 39 */ "food #1",
	/* 40 */ "food #2",
	/* 41 */ "food #3",
	/* 42 */ "parties #1",
	/* 43 */ "parties #2",
	/* 44 */ "parties #3",
	/* 45 */ "style #1",
	/* 46 */ "style #2",
	/* 47 */ "style #3",
	/* 48 */ "health #1",
	/* 49 */ "health #2",
	/* 50 */ "health #3",
	/* 51 */ "romance #1",
	/* 52 */ "romance #2",
	/* 53 */ "romance #3",
	/* 54 */ "charisma #1",
	/* 55 */ "charisma #2",
	/* 56 */ "charisma #3",
	/* 57 */ "job - business",
	/* 58 */ "job - entertainment",
	/* 59 */ "job - law enforcement",
	/* 60 */ "job - crime",
	/* 61 */ "job - medical",
	/* 62 */ "job - military",
	/* 63 */ "job - politics",
	/* 64 */ "job - sports",
	/* 65 */ "job - science",
	/* 66 */ "job - extreme",
	/* 67 */ "job - music",
	/* 68 */ "job - slacker",
	/* 69 */ "job - paranormal",
	/* 70 */ "job - journalism",
	/* 71 */ "job - hacker",
	/* 72 */ "job - unemployed",
	/* 73 */ "bored with social",
	// name changed in Vacation
	/* 74 */ "red plumb bomb",
	/* 75 */ "bad mood",
	// added in vacation
	/* 76 */ "bored social",
	/* 77 */ "VI logo",
	0};
int BhavStr501Len = (sizeof BhavStr501/sizeof BhavStr501[0]) - 1;

const char *BhavStr502[] = {	// motive icon labels
	/*  0 */ "hunger",
	/*  1 */ "bladder",
	/*  2 */ "unused alertness",
	/*  3 */ "hygiene",
	/*  4 */ "energy",
	/*  5 */ "comfort",
	/*  6 */ "entertainment",
	/*  7 */ "unused sleeping",
	/*  8 */ "unused tired",
	/*  9 */ "unused really tired",
	/* 10 */ "social",
	/* 11 */ "unused stress",
	/* 12 */ "unused candle",
	/* 13 */ "environment",
	/* 14 */ "unused NO MONEY",
	0};
int BhavStr502Len = (sizeof BhavStr502/sizeof BhavStr502[0]) - 1;

const char *BhavStr503[] = {	// relationship icon labels
	/*  0 */ "lovers",
	/*  1 */ "friends",
	0};
int BhavStr503Len = (sizeof BhavStr503/sizeof BhavStr503[0]) - 1;

const char *BhavStr504[] = {	// headline icon labels
	/*  0 */ "hate",
	/*  1 */ "stress",
	/*  2 */ "surprise",
	/*  3 */ "idea",
	/*  4 */ "love",
	/*  5 */ "drunk",
	/*  6 */ "hurt",
	/*  7 */ "smell",
	/*  8 */ "flies",
	0};
int BhavStr504Len = (sizeof BhavStr504/sizeof BhavStr504[0]) - 1;

const char *BhavStr505[] = {	// balloon icon labels
	/*  0 */ "thought",
	/*  1 */ "scream",
	/*  2 */ "speak",
	/*  3 */ "not",
	0};
int BhavStr505Len = (sizeof BhavStr505/sizeof BhavStr505[0]) - 1;

const char *BhavStr506[] = {	// Debug
	/*  0 */ "debug",
	/*  1 */ "hug",
	/*  2 */ "gift",
	/*  3 */ "back rub",
	/*  4 */ "cheer up",
	/*  5 */ "entertain",
	/*  6 */ "tickle",
	/*  7 */ "brag",
	/*  8 */ "slap",
	/*  9 */ "scare",
	/* 10 */ "tease",
	/* 11 */ "attack",
	/* 12 */ "no chair",
	/* 13 */ "in use",
	/* 14 */ "can't route",
	/* 15 */ "++",
	/* 16 */ "+",
	/* 17 */ "-",
	/* 18 */ "--",
	/* 19 */ "pizza",
	/* 20 */ "moving out of way",
	/* 21 */ "moving off door",
	/* 22 */ "route waiting",
	/* 23 */ "asking to move",
	/* 24 */ "can't find room",
	/* 25 */ "can't sit down",
	/* 26 */ "can't stand up",
	/* 27 */ "destination occupied",
	/* 28 */ "chair occupied",
	/* 29 */ "wall in the way",
	/* 30 */ "friends",
	/* 31 */ "romance",
	/* 32 */ "altitudes don't match",
	// added in Hot Date
	/* 33 */ "crush[HD]",
	0};
int BhavStr506Len = (sizeof BhavStr506/sizeof BhavStr506[0]) - 1;

const char *BhavStr507[] = {	// Algorithmic icons
	/*  0 */ "icon of stack obj",
	/*  1 */ "icon of neighbor",
	/*  2 */ "icon of obj in ",
	0};
int BhavStr507Len = (sizeof BhavStr507/sizeof BhavStr507[0]) - 1;

const char *BhavStr508[] = {	// Route failure icons
	/*  0 */ "chair not found",
	/*  1 */ "door not found",
	/*  2 */ "wall in the way",
	/*  3 */ "terrain not level",
	/*  4 */ "no pool ladder",
	0};
int BhavStr508Len = (sizeof BhavStr508/sizeof BhavStr508[0]) - 1;

const char *BhavStr509[] = {	// Skill/Repair Progress
	/*  0 */ "0% skill",
	/*  1 */ "10%",
	/*  2 */ "20%",
	/*  3 */ "30%",
	/*  4 */ "40%",
	/*  5 */ "50%",
	/*  6 */ "60%",
	/*  7 */ "70%",
	/*  8 */ "80%",
	/*  9 */ "90%",
	/* 10 */ "0% repair",
	/* 11 */ "10% repair",
	/* 12 */ "20% repair",
	/* 13 */ "30% repair",
	/* 14 */ "40% repair",
	/* 15 */ "50% repair",
	/* 16 */ "60% repair",
	/* 17 */ "70% repair",
	/* 18 */ "80% repair",
	/* 19 */ "90% repair",
	// added in Hot Date
	/* 20 */ "0% interest[HD]",
	/* 21 */ "10% interest[HD]",
	/* 22 */ "20% interest[HD]",
	/* 23 */ "30% interest[HD]",
	/* 24 */ "40% interest[HD]",
	/* 25 */ "50% interest[HD]",
	/* 26 */ "60% interest[HD]",
	/* 27 */ "70% interest[HD]",
	/* 28 */ "80% interest[HD]",
	/* 29 */ "90% interest[HD]",
	0};
int BhavStr509Len = (sizeof BhavStr509/sizeof BhavStr509[0]) - 1;
