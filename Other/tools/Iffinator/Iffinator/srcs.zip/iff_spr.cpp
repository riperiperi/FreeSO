#include "iff_spr.h"
#include "crack.h"
#include <iostream>

// use these inline functions to serialize access to the stream
static inline int littleShort(std::istream *s)
{
	int a = s->get(), b = s->get();
	return (b<<8) + a;
}
static inline int bigShort(std::istream *s)
{
	int a = s->get(), b = s->get();
	return (a<<8) + b;
}

simIFF_SPR::simIFF_SPR(std::istream *s)
:	m_count(-1), m_in(0)
{
	m_version = littleShort(s);
	if (m_version == 0) {
		// it's big-endian; read version
		m_version = bigShort(s);
		m_in = new crackBig(s);
	} else {
		// it's little-endian; skip zero bytes
		if (littleShort(s) != 0) return;
		m_in = new crackLittle(s);
	}
	switch (m_version) {
	default:
		std::cout << "LOOK: unknown SPR version "
			<< m_version << std::endl;
		return;
	// known SPR# versions...
	case 502: case 503: case 504: case 505:
	// known SPR2 versions...
	case 1000:
		break;
	}
	m_count = m_in->readInt();
	m_palette = m_in->readInt();
	m_transparent = -1;
}

int simIFF_SPR::hasTransparent(void) const
{
	switch (m_version) {
	default:
		return -1;	// "can't happen"
	case 502: case 503: case 504: case 505:
		return 0;	// SPR# doesn't have one
	case 1000:
		return 1;	// SPR2 has one
	}
}

simIFF_SPR::~simIFF_SPR(void)
{
	delete m_in;
}

struct tmp {
	char *cur_z, *cur_img, *cur_alpha;
	unsigned char cur_trans;
	tmp(char *z, char *img, char *alpha)
		: cur_z(z), cur_img(img), cur_alpha(alpha)
		{}
};

static inline void floodline(tmp &t, int width)
{
	while (--width >= 0) {
		*t.cur_z++ = 0;
		*t.cur_img++ = t.cur_trans;
		*t.cur_alpha++ = 0;
	}
}

#if defined(DebugCode) && DebugCode
static int maybeFlags;
#define	MaybeSetFlags(f)	maybeFlags |= f;
#define MaybeClearFlags		maybeFlags = 0;
#define MaybeFlags		maybeFlags
#else
#define MaybeSetFlags(f)
#define MaybeClearFlags
#define MaybeFlags		sprite.flags()
#endif

static inline int uncompress1(crack &in, tmp &t, int height, int width)
{
	MaybeSetFlags(1);
	int wid = 0, x;
	while (height >= 0) {
		int format = in.readByte();
		int pixels = in.readByte();
		switch (format) {
		default:	return 1;
		case 1:		// fill with background
			wid -= pixels;
			floodline(t, pixels);
			break;
		case 2: 	// run-length encoding
			wid -= pixels;
			x = t.cur_trans;
			t.cur_trans = in.readByte();
			in.readByte();	// unused
			floodline(t, pixels);
			t.cur_trans = x;
			break;
		case 3: 	// copy pixels to image
			wid -= pixels;
			x = pixels&1;
			while (--pixels >= 0) {
				*t.cur_z++ = 255;
				*t.cur_img++ = in.readByte();
				*t.cur_alpha++ = 255;
			}
			if (x != 0) in.readByte();	// force even
			break;
		case 9:		// fill multiple background lines
			height -= pixels;
			wid += width*pixels;
			// actual fill will be done by case 4 or 5
			break;
		case 4:		// line with data
			--height;
			floodline(t, wid);
			wid = width;
			break;
		case 5:		// end marker
			floodline(t, wid);
			return height > 0;
		}
	}
	return 0;
}

static inline int uncompress2(crack &in, tmp &t, int height, int width)
{
	int wid = 0, x;
	while (height >= 0) {
		// little-endian short: fffppppppppppppp
		int pixels = in.readByte();
		int format = in.readByte();
		pixels |= (format&0x1F) << 8, format >>= 5;
		switch (format) {
		default:	return 1;
		case 3:		// fill with background
			wid -= pixels;
			floodline(t, pixels);
			break;
		case 6:		// one byte per pixel, image data
			MaybeSetFlags(1);
			wid -= pixels;
			x = pixels&1;
			while (--pixels >=0) {
				*t.cur_z++ = 255;
				*t.cur_img++ = in.readByte();
				*t.cur_alpha++ = 255;
			}
			if (x != 0) in.readByte();	// force even
			break;
		case 1:		// two bytes per pixel, z-buffer and image
			MaybeSetFlags(3);
			wid -= pixels;
			while (--pixels >=0) {
				*t.cur_z++ = in.readByte();
				*t.cur_img++ = in.readByte();
				*t.cur_alpha++ = 255;
			}
			break;
		case 2:		// three bytes per pixel, z, image, alpha
			MaybeSetFlags(7);
			wid -= pixels;
			x = pixels&1;
			while (--pixels >=0) {
				*t.cur_z++ = in.readByte();
				*t.cur_img++ = in.readByte();
				*t.cur_alpha++ = in.readByte();
			}
			if (x != 0) in.readByte();	// force even
			break;
		case 4:		// fill multiple background lines
			height -= pixels;
			wid += width*pixels;
			// actual fill will be done by case 0 or 5
			break;
		case 0:		// line with data
			--height;
			floodline(t, wid);
			wid = width;
			break;
		case 5:		// end marker
			floodline(t, wid);
			return height > 0;
		}
	}
	return 0;
}

simSprite::simSprite(simIFF_SPR &spr, int ix)
:	m_zdepth(0)
{
	if (spr.err()) return;
	if (ix >= spr.count()) return;
	m_palette = spr.palette();
	crack &in = *spr.m_in;
	in.s()->seekg(12 + 4*ix);
	in.s()->seekg(in.readInt());
	switch (spr.m_version) {
	// known SPR# versions...
	case 502: case 503: case 504: case 505: {
			in.readInt();			// unknown; always zero
			m_height = in.readShort();
			m_width = in.readShort();
			m_unknown = in.readShort();	// unknown
			m_flags = 1;
			m_transparent = spr.m_transparent;
			m_xloc = 0, m_yloc = 0;
			m_zdepth = new char[3*m_width*m_height];
			m_image = m_zdepth + m_width*m_height;
			m_alpha = m_image + m_width*m_height;
			tmp t(m_zdepth, m_image, m_alpha);
			t.cur_trans = m_transparent;
			if (uncompress1(in, t, m_height, m_width)) {
				delete[] m_zdepth;
				m_zdepth = 0;
				return;
			}
			break;
		}
	// known SPR2 versions...
	case 1000: {
			m_width = in.readShort();
			m_height = in.readShort();
			m_flags = in.readShort();	// always 1, 3, or 7
			m_unknown = in.readShort();	// always zero
			unsigned short palette = in.readShort();
			if (palette != 0xA3A3) m_palette = palette;
			m_transparent = in.readShort();
			m_yloc = in.readShort();
			m_xloc = in.readShort();
			m_zdepth = new char[3*m_width*m_height];
			m_image = m_zdepth + m_width*m_height;
			m_alpha = m_image + m_width*m_height;
			tmp t(m_zdepth, m_image, m_alpha);
			t.cur_trans = m_transparent;
			if (uncompress2(in, t, m_height, m_width)) {
				delete[] m_zdepth;
				m_zdepth = 0;
				return;
			}
			break;
		}
	default:	return;		// "can't happen"
	}
}

simSprite::~simSprite(void)
{
	delete[] m_zdepth;
}
