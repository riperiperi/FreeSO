#ifndef __SIMS_nocopy_h
#define __SIMS_nocopy_h

//  classes derived from simNoCopy cannot be copied or assigned

class simNoCopy
{
	// unimplemented...
	simNoCopy(const simNoCopy&);
	const simNoCopy& operator=(const simNoCopy&);
protected:	// protected so can only be created by derived class
	simNoCopy() {}
	~simNoCopy() {}
};

#endif // __SIMS_nocopy_h
