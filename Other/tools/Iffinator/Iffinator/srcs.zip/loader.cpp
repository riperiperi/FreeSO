class GameLoader
{
public:
	class filetype {
		friend class GameLoader;
		filetype *m_next;
		const char *m_suffix;
	protected:
		filetype(const char* suffix);
	private:
		virtual ~filetype(void);
	};
	friend class filetype;
private:
	filetype *m_first;
	int load(const char *dir, const char *name);
public:
	GameLoader(void);
	virtual ~GameLoader(void);
	int load_game(const char *global_path, const char *local = 0);
};

// #include "loader.h"
#include <iostream>
#include <sys/stat.h>
#include <dirent.h>

GameLoader::GameLoader(void)
:	m_first(0)
{
}

GameLoader::~GameLoader(void)
{
	while (m_first != 0) {
		filetype *p = m_first;
		m_first = p->m_next;
		delete p;
	}
}

// If a path to a directory, call ourselves recursively with each
// name in the directory.  For a file, look at the suffix and call
// a specialized routine for the specific file type.
int GameLoader::load(const char *dir, const char *name)
{
	char path[strlen(dir) + strlen(name) + 2], *p = path;
	while ((*p++ = *dir++) != '\0') {}
	*--p = '/';
	int mac_len = 0;	// Mac names are limited to 31 chars
	char *suf = 0;		// points to suffix, if any
	while ((*++p = *name++) != '\0') {
		++mac_len;
		if (*p == '.') suf = p;
	}
	struct stat buf;
	if (::stat(path, &buf) < 0) return -1;
	switch (buf.st_mode&S_IFMT) {
	default: return -1;
	case S_IFDIR: {
// cout << "dir " << path << endl;
			DIR *dp;
			if ((dp = ::opendir(path)) == 0) return -1;
			for (struct dirent *e; (e = ::readdir(dp)) != 0; ) {
				if (e->d_name[0] == '.') continue;
				if (load(path, e->d_name) != 0) return -1;
			}
		}
		return 0;
	case S_IFREG: {
			if (suf == 0) {
				if (mac_len >= 31) {
cout << "file " << path << " (possible truncation)" << endl;
				} else {
cout << "file " << path << " (no suffix)" << endl;
				}
				// anything else to do?
				return 0;
			}
			++suf;
cout << "file " << path << " suffix " << suf << endl;
			// xxxxxxx
		}
		return 0;
	}
	return -1;
}

int GameLoader::load_game(const char *global_path, const char *local = 0)
{
	load(global_path, "GameData");
	load(global_path, "SoundData");
	load(global_path, "Downloads");
	if (local != 0) load(local, ".");
	return 0;
}

// TEMPORARY BELOW THIS
int main(int argc, char **argv)
{
	if (argc < 2) {
		cout << "Usage: " << *argv << " game-dir" << endl;
		exit(1);
	}
	GameLoader ld;
	ld.load_game(argv[1]);
	return 0;
}
