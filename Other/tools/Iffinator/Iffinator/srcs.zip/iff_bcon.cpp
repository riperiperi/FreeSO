#include "iff_bcon.h"
#include "crack.h"
#include <iostream>

simIFF_BCON::simIFF_BCON(std::istream *s)
:	m_val(0)
{
	crackLittle in(s);
	m_count = in.readByte();
	m_flags = in.readByte();
	m_val = (m_count > m_opt) ? new short[m_count] : m_array;
	for (int i = 0; i < m_count; ++i) m_val[i] = in.readShort();
	// in.dump();
}

simIFF_BCON::~simIFF_BCON(void)
{
	if (m_count > m_opt) delete[] m_val;
}
