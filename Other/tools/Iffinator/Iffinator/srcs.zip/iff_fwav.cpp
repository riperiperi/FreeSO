#include "iff_fwav.h"
#include "crack.h"
#include <iostream>

simIFF_FWAV::simIFF_FWAV(std::istream *s)
{
	if (s == 0) {
		m_fwav[0] = '\0';
		return;
	}
	size_t i = 0;
	for (int c; (c = s->get()) != '\0' && c != EOF; ++i) m_fwav[i] = c;
	m_fwav[i] = '\0';
	delete s;
}
