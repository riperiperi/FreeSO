#include "iff_trcn.h"
#include "crack.h"
#include <iostream>

static char nulStr[1] = { 0 };

inline simIFF_TRCN::Label::Label(void) : m_str1(0), m_str2(0) {}
inline simIFF_TRCN::Label::~Label(void)
{
	if (m_str1 != nulStr) delete m_str1;
	if (m_str2 != nulStr) delete m_str2;
}

simIFF_TRCN::simIFF_TRCN(std::istream *s)
:	m_count(-1), m_labels(0)
{
	if (s == 0) return;
	crackLittle in(s);
	if (in.readInt() != 0) return;
	m_version = in.readInt();
	switch(m_version) {
	default:
		return;
	case 0: case 1: case 2:
		break;
	}
	// HACK: some version 2 resources don't have the 'TRCN' signature,
	// hopefully due to a bug that will be fixed, but for now, we'll
	// also accept zero.
	//if (in.readInt() != (((((('T'<<8)|'R')<<8)|'C')<<8)|'N')) return;
	int sig = in.readInt();
	if (sig == (((((('T'<<8)|'R')<<8)|'C')<<8)|'N')) goto OK;
	if (m_version == 2 && sig == 0) goto OK;
	return;
    OK:;
	if ((m_count = in.readInt()) <= 0) return;
	m_labels = new Label[m_count];
	for (int i = 0; i < m_count; ++i) {
		Label &e = m_labels[i];
		e.m_used = in.readInt();
		e.m_unknown = in.readInt();
		if (m_version < 2) {
			e.m_str1 = in.readEvenString();
			e.m_str2 = in.readEvenString();
		} else {
			e.m_str1 = in.readCountString();
			e.m_str2 = in.readCountString();
		}
		if (e.m_str1 == 0) e.m_str1 = nulStr;
		if (e.m_str2 == 0) e.m_str2 = nulStr;
		if (m_version == 0) {
			e.m_range = 0, e.m_low = 0, e.m_high = 100;
		} else {
			e.m_range = in.readByte();
			e.m_low = in.readShort();
			e.m_high = in.readShort();
		}
	}
	//in.dump();
}

simIFF_TRCN::~simIFF_TRCN(void)
{
	delete[] m_labels;
}
