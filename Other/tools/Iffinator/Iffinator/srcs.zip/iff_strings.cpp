#include "crack.h"
#include <iff_strings.h>
#include <iostream>
using std::endl;

inline static int getBig(std::istream *in)
{
	unsigned char a = in->get(), b = in->get();
	return (a<<8)|b;
}

inline static short getLittle(std::istream *in)
{
	unsigned char a = in->get(), b = in->get();
	return (b<<8)|a;
}

// strings resource format
void simIFF_string::init(std::istream *s)
{
	m_sets = 1, m_set = 0, m_entry = -1, m_len1 = 0, m_len2 = 0, m_in = s;
	if (s == 0) { m_type = 1; return; }
	m_type = getBig(m_in);
	if (((signed short)m_type) >= 0) {
		m_entries = m_type;
		m_type = 0;	// force code type of zero
	} else {
		switch (m_type) {
		default:	// UNKNOWN
/*DEBUG*/std::cerr << "UNKNOWN STRING TYPE " << m_type << "; RESOURCE ASSUMED BAD" << endl;
#if 0
/*DEBUG*/cout << "UNKNOWN STRING TYPE " << m_type << endl;
/*DEBUG*/crackLittle x(new dupstream(m_in)); x.dump(); exit(-1);
#endif
/*DEBUG*/m_entries = 0;
			m_type = 1;
			return;
		case 0xFCFF:
			// this format has multiple string sets
			m_sets = m_in->get();
			// fall through
		case 0xFFFF: case 0xFEFF: case 0xFDFF:
			m_entries = getLittle(m_in);
			break;
		}
	}
}

simIFF_string::~simIFF_string()
{
	if (m_len1 > 0) delete[] m_str1;
	if (m_len2 > 0) delete[] m_str2;
	delete m_in;
}

static char nulStr[1] = { 0 };

// Pascal-style counted string
static void pasStr(std::istream *in, short &len, char *&str)
{
	len = in->get();
	if (len == 0) {
		// optimization for empty strings
		str = nulStr;
	} else {
		str = new char[len + 1];
		in->read(str, len);
		str[len] = '\0';
	}
}

// counted string with compressed count
static void pasStr1(std::istream *in, short &len, char *&str)
{
	len = in->get();
	if (len > 127) len = (len - 128) + (in->get()<<7);
	if (len == 0) {
		// optimization for empty strings
		str = nulStr;
	} else {
		str = new char[len + 1];
		in->read(str, len);
		str[len] = '\0';
	}
}

// null-terminated string
static void nullStr(std::istream *in, short &len, char *&str)
{
	// extract a null-terminated string
	// and store its length and value
	int here = in->tellg(), l = 0;
	for (int c; (c = in->get()) != 0; ++l) {
		// paranoia, should never happen
		if (c == EOF) return;
	}
	if (l == 0) {
		// optimization for empty strings
		len = 0, str = nulStr;
		return;
	}
	len = l, str = new char[l + 1];
	in->seekg(here);
	in->read(str, l + 1);
}

int simIFF_string::next(void)
{
	while (++m_entry >= m_entries) {
		if (++m_set >= m_sets) return EOF;
		m_entries =getLittle(m_in);
		m_entry = -1;
	}
	if (m_len1 > 0) delete[] m_str1;
	if (m_len2 > 0) delete[] m_str2;
	switch (m_type) {
	case 0:
		// Pascal-style counted string
		m_code = -1;
		pasStr(m_in, m_len1, m_str1);
		m_str2 = nulStr;
		return 0;
	case 0xFFFF:
		// just a null-terminated string
		m_code = -1;
		nullStr(m_in, m_len1, m_str1);
		m_str2 = nulStr;
		return 0;
	case 0xFEFF:
		// two null-terminated strings
		m_code = -1;
		nullStr(m_in, m_len1, m_str1);
		nullStr(m_in, m_len2, m_str2);
		return 0;
	case 0xFDFF:
		// string code, then two null-terminated strings
		m_code = m_in->get();
		nullStr(m_in, m_len1, m_str1);
		nullStr(m_in, m_len2, m_str2);
		return 0;
	case 0xFCFF:
		// string code, then two specially-counted strings
		// for some reason, the language code is one below the
		// documented values.  we adjust this here, which
		// unfortunately makes non-translated strings strange.
		m_code = m_in->get() + 1;
		pasStr1(m_in, m_len1, m_str1);
		pasStr1(m_in, m_len2, m_str2);
		// this is a gross hack, but whatever they're using to
		// create this format doesn't seem to deal with null
		// strings, so it inserts one byte of garbage.  A base
		// string can be one character, but if we find a one-
		// character comment string, we zap it.
		if (m_len2 == 1) {
			delete m_str2, m_len2 = 0, m_str2 = nulStr;
		}
		return 0;
	}
	exit(1);
}

int simIFF_string::next(int id)
{
	while (next() != EOF) if (m_code == id) return 0;
	return EOF;
}

// only called within this file, so we can make them inline
inline simIFF_strings::String::String(void)
:	m_len1(0), m_len2(0)
{ }
inline simIFF_strings::String::~String(void)
{
	if (m_len1 > 0) delete[] m_str1;
	if (m_len2 > 0) delete[] m_str2;
}

void simIFF_strings::init(simIFF_string &in)
{
	m_strings = 0;
	if ((m_entries = in.entries()) == 0) return;
	m_strings = new String[m_entries];
	for (int i = 0; in.next() != EOF; ++i) {
		String &p = m_strings[i];
		p.m_code = in.code();
		p.m_str1 = ((p.m_len1 = in.len1()) == 0) ? nulStr : in.take1();
		p.m_str2 = ((p.m_len2 = in.len2()) == 0) ? nulStr : in.take2();
	}
}

simIFF_strings::simIFF_strings(std::istream *s)
{
	if (s == 0) { m_entries = 0; m_strings = 0;; return; }
	simIFF_string in(s);
	init(in);
}

simIFF_strings::~simIFF_strings()
{
	delete[] m_strings;
}
