#include "iff_objd.h"
#include "crack.h"
#include <iostream>
using std::cout;
using std::endl;

// for better performance, we do this in-line
// instead of using the crackLittle class
static short get(std::istream *s)
{
	int a = s->get(), b = s->get();
	return (a == EOF || b == EOF) ? 0 : ((b<<8)|a);
}

// OBJD resource format
static void init(OBJD_t &t, std::istream *s)
{
	crackLittle in(s);
	int i = in.readInt();
	if (i != 138) {
		cout << "UNKNOWN OBJD VERSION " << i
			<< "; resource ignored " << endl;
		// in.dump();
		t.m_guid.itself = 0;
		return;
	}
	// modified from Behavior.iff STR# 204 ("definition labels")
	t.m_stackSz = get(s);			// initial stack
	t.m_baseGraphic = get(s);		// base graphic
	t.m_numGraphics = get(s);		// graphics count
	t.m_oldTreeID.main = get(s);		// old tree ID (main)
	t.m_oldTreeID.garden = get(s);		// old tree ID (gardening)
	t.m_treeTblID = get(s);			// tree table ID
	t.m_interactGrp = get(s);		// interaction group
	t.m_type = get(s);			// type
	t.m_masterID = get(s);			// master ID
	t.m_subIndex = get(s);			// sub-index
	t.m_oldTreeID.washHands = get(s);	// old tree ID (wash hands)
	t.m_animTblID = get(s);			// anim table ID
	t.m_guid.itself = in.readInt();		// GUID
	t.m_disabled = get(s);			// disabled
	t.m_oldTreeID.portal = get(s);		// old tree ID (portal)
	t.m_depreciation.buy = get(s);		// buy price
	t.m_bodyID = get(s);			// body string ID
	t.m_slotID = get(s);			// slot ID
	t.m_oldTreeID.intersection = get(s);	// old tree ID (allow intersection)
	t.m_unused[0] = get(s);			// unused
	t.m_unused[1] = get(s);			// unused
	t.m_oldTreeID.prepareFood = get(s);	// old tree ID (prepare food)
	t.m_oldTreeID.cookFood = get(s);	// old tree ID (cook food)
	t.m_oldTreeID.placeSurface = get(s);	// old tree ID (place on surface)
	t.m_oldTreeID.dispose = get(s);		// old tree ID (dispose)
	t.m_oldTreeID.eat = get(s);		// old tree ID (eat food)
	t.m_oldTreeID.pickUp = get(s);		// old tree ID (slot pick up)
	t.m_oldTreeID.washDish = get(s);	// old tree ID (wash dish)
	t.m_oldTreeID.eatSurface = get(s);	// old tree ID (eating surface)
	t.m_oldTreeID.sit = get(s);		// old tree ID (sit)
	t.m_oldTreeID.stand = get(s);		// old tree ID (stand)
	t.m_depreciation.sell = get(s);		// sale price
	t.m_depreciation.initial = get(s);	// initial depreciation
	t.m_depreciation.daily = get(s);	// daily depreciation
	t.m_depreciation.isSelf = get(s);	// self depreciation
	t.m_depreciation.limit = get(s);	// limit of depreciation
	t.m_sort.room = get(s);			// room flags
	t.m_sort.fn = get(s);			// function flags
	t.m_catalogStr = get(s);		// CTSS ID (catalog text)
	t.m_isGlobal = get(s);			// global flag
	t.m_oldTreeID.init = get(s);		// old tree ID (init)
	t.m_oldTreeID.place = get(s);		// old tree ID (place)
	t.m_oldTreeID.godPickup = get(s);	// old tree ID (user pickup)
	t.m_wall.style = get(s);		// wall style
	t.m_oldTreeID.load = get(s);		// old tree ID (load)
	t.m_oldTreeID.godPlace = get(s);	// old tree ID (user place)
	t.m_objVers = get(s);			// object version
	t.m_oldTreeID.roomChange = get(s);	// old tree ID (room changed)
	t.m_motiveID = get(s);			// motive effects ID
	t.m_oldTreeID.cleanup = get(s);		// old tree ID (cleanup)
	t.m_oldTreeID.levelInfo = get(s);	// old tree ID (level info request)
	t.m_catalogID = get(s);			// catalog popup ID
	t.m_oldTreeID.servingSurf = get(s);	// old tree ID (serving surface)
	t.m_levelOffset = get(s);		// level offset
	t.m_shadow.itself = get(s);		// shadow
	t.m_numAttrs = get(s);			// number of attributes
	t.m_oldTreeID.clean = get(s);		// old tree ID (clean)
	t.m_oldTreeID.qSkip = get(s);		// old tree ID (queue skipped)
	t.m_frontDir = get(s);			// front direction
	t.m_oldTreeID.wallAdj = get(s);		// old tree ID (wall adjacency changed)
	t.m_leadObj = get(s);			// MT lead object
	t.m_spriteID = get(s);			// sprite base ID
	t.m_numSprites = get(s);		// number of sprites
	t.m_chairFlgs = get(s);			// chair flags
	t.m_tileWidth = get(s);			// tile width
	t.m_noSuitCopy = get(s);		// inhibit suit copy
	t.m_sort.build = get(s);		// build mode type
	t.m_guid.orig = in.readInt();		// original GUID
	t.m_guid.suit = in.readInt();		// suit GUID
	t.m_oldTreeID.pickup = get(s);		// old tree ID (pickup)
	t.m_thumbnail = get(s);			// thumbnail graphic
	t.m_shadow.flags = get(s);		// shadow flags
	t.m_footprint = get(s);			// footprint mask
	t.m_oldTreeID.multiTile = get(s);	// old tree ID (dynamic multi-tile update)
	t.m_shadow.bright = get(s);		// shadow brightness
	t.m_oldTreeID.repair = get(s);		// old tree ID (repair)
	t.m_wall.sprite = get(s);		// wall sprite ID
	t.m_rating.hunger = get(s);		// hunger
	t.m_rating.comfort = get(s);		// comfort
	t.m_rating.hygiene = get(s);		// hygiene
	t.m_rating.bladder = get(s);		// bladder
	t.m_rating.energy = get(s);		// energy
	t.m_rating.fun = get(s);		// fun
	t.m_rating.room = get(s);		// room
	t.m_rating.skills = get(s);		// skill flags
	t.m_numTypes = get(s);			// number of type attrs
	t.m_misc = get(s);			// misc flags
	t.m_guid.typeAttr = in.readInt();	// type attr GUID
	// added in HotDate
	t.m_sort.fnSubSort = get(s);		// function subsort
	t.m_sort.downtown = get(s);		// downtown sort
	t.m_keepBuying = get(s);		// keep buying
	// added in Vacation
	t.m_sort.vacation = get(s);		// vacation sort
	t.m_resetLot = get(s);			// reset lot action
	t.m_sort.community = get(s);		// community sort
	t.m_sort.studiotown = 0;		// studiotown sort
	for (size_t i = 2; i < sizeof t.m_unused/sizeof t.m_unused[0]; ++i) {
		t.m_unused[i] = get(s);
	}
	// in.dump();
}

simIFF_OBJD::simIFF_OBJD(std::istream *s)
{
	init(tbl, s);
}

static inline void dumpShort(std::ostream *s, unsigned short v)
{
	s->put(v), s->put(v>>8);
}
static inline void dumpLong(std::ostream *s, unsigned int v)
{
	s->put(v), s->put(v >>= 8), s->put(v >>= 8), s->put(v>>8);
}

static inline void dump2stream(std::ostream *s, const simIFF_OBJD &o)
{
	dumpLong(s, 138);	// version
	dumpShort(s, o->m_stackSz);
	dumpShort(s, o->m_baseGraphic);
	dumpShort(s, o->m_numGraphics);
	dumpShort(s, o->m_oldTreeID.main);
	dumpShort(s, o->m_oldTreeID.garden);
	dumpShort(s, o->m_treeTblID);
	dumpShort(s, o->m_interactGrp);
	dumpShort(s, o->m_type);
	dumpShort(s, o->m_masterID);
	dumpShort(s, o->m_subIndex);
	dumpShort(s, o->m_oldTreeID.washHands);
	dumpShort(s, o->m_animTblID);
	dumpLong(s, o->m_guid.itself);
	dumpShort(s, o->m_disabled);
	dumpShort(s, o->m_oldTreeID.portal);
	dumpShort(s, o->m_depreciation.buy);
	dumpShort(s, o->m_bodyID);
	dumpShort(s, o->m_slotID);
	dumpShort(s, o->m_oldTreeID.intersection);
	dumpShort(s, o->m_unused[0]);	// unused
	dumpShort(s, o->m_unused[1]);	// unused
	dumpShort(s, o->m_oldTreeID.prepareFood);
	dumpShort(s, o->m_oldTreeID.cookFood);
	dumpShort(s, o->m_oldTreeID.placeSurface);
	dumpShort(s, o->m_oldTreeID.dispose);
	dumpShort(s, o->m_oldTreeID.eat);
	dumpShort(s, o->m_oldTreeID.pickUp);
	dumpShort(s, o->m_oldTreeID.washDish);
	dumpShort(s, o->m_oldTreeID.eatSurface);
	dumpShort(s, o->m_oldTreeID.sit);
	dumpShort(s, o->m_oldTreeID.stand);
	dumpShort(s, o->m_depreciation.sell);
	dumpShort(s, o->m_depreciation.initial);
	dumpShort(s, o->m_depreciation.daily);
	dumpShort(s, o->m_depreciation.isSelf);
	dumpShort(s, o->m_depreciation.limit);
	dumpShort(s, o->m_sort.room);
	dumpShort(s, o->m_sort.fn);
	dumpShort(s, o->m_catalogStr);
	dumpShort(s, o->m_isGlobal);
	dumpShort(s, o->m_oldTreeID.init);
	dumpShort(s, o->m_oldTreeID.place);
	dumpShort(s, o->m_oldTreeID.godPickup);
	dumpShort(s, o->m_wall.style);
	dumpShort(s, o->m_oldTreeID.load);
	dumpShort(s, o->m_oldTreeID.godPlace);
	dumpShort(s, o->m_objVers);
	dumpShort(s, o->m_oldTreeID.roomChange);
	dumpShort(s, o->m_motiveID);
	dumpShort(s, o->m_oldTreeID.cleanup);
	dumpShort(s, o->m_oldTreeID.levelInfo);
	dumpShort(s, o->m_catalogID);
	dumpShort(s, o->m_oldTreeID.servingSurf);
	dumpShort(s, o->m_levelOffset);
	dumpShort(s, o->m_shadow.itself);
	dumpShort(s, o->m_numAttrs);
	dumpShort(s, o->m_oldTreeID.clean);
	dumpShort(s, o->m_oldTreeID.qSkip);
	dumpShort(s, o->m_frontDir);
	dumpShort(s, o->m_oldTreeID.wallAdj);
	dumpShort(s, o->m_leadObj);
	dumpShort(s, o->m_spriteID);
	dumpShort(s, o->m_numSprites);
	dumpShort(s, o->m_chairFlgs);
	dumpShort(s, o->m_tileWidth);
	dumpShort(s, o->m_noSuitCopy);
	dumpShort(s, o->m_sort.build);
	dumpLong(s, o->m_guid.orig);
	dumpLong(s, o->m_guid.suit);
	dumpShort(s, o->m_oldTreeID.pickup);
	dumpShort(s, o->m_thumbnail);
	dumpShort(s, o->m_shadow.flags);
	dumpShort(s, o->m_footprint);
	dumpShort(s, o->m_oldTreeID.multiTile);
	dumpShort(s, o->m_shadow.bright);
	dumpShort(s, o->m_oldTreeID.repair);
	dumpShort(s, o->m_wall.sprite);
	dumpShort(s, o->m_rating.hunger);
	dumpShort(s, o->m_rating.comfort);
	dumpShort(s, o->m_rating.hygiene);
	dumpShort(s, o->m_rating.bladder);
	dumpShort(s, o->m_rating.energy);
	dumpShort(s, o->m_rating.fun);
	dumpShort(s, o->m_rating.room);
	dumpShort(s, o->m_rating.skills);
	dumpShort(s, o->m_numTypes);
	dumpShort(s, o->m_misc);
	dumpLong(s, o->m_guid.typeAttr);
	dumpShort(s, o->m_sort.fnSubSort);
	dumpShort(s, o->m_sort.downtown);
	dumpShort(s, o->m_keepBuying);
	dumpShort(s, o->m_sort.vacation);
	dumpLong(s, o->m_resetLot);
	for (size_t i = 2; i < sizeof o->m_unused/sizeof o->m_unused[0]; ++i) {
		dumpShort(s, o->m_unused[i]);
	}
}

#include <stdio.h>
static inline void prettyPrintBits(char **str, unsigned int bits)
{
	if (bits == 0) {
		printf(" NONE");
		return;
	}
	static char *extra[] = {
		"XX00", "XX01", "XX02", "XX03", "XX04",
		"XX05", "XX06", "XX07", "XX08", "XX09",
		"XX10", "XX11", "XX12", "XX13", "XX14",
		"XX15", "XX16", "XX17", "XX18", "XX19",
		0
	};
	for (; bits != 0; ++str, bits >>= 1) {
		if (*str == 0) str = extra;
		if ((bits&1) != 0) printf(" %s", *str);
	}
}
static inline void prettyPrintMaster(const simIFF_OBJD &o, std::ostream *out)
{
	if (o->m_masterID != 0 && o->m_subIndex != -1) return;
	printf("Master information:\n");
	printf("%5d object type\n", o->m_type);
	printf("%5d interaction group\n", o->m_interactGrp);
	printf("%5d disabled\n", o->m_disabled);
	if (o->m_sort.build != 0) {
		static char *s[] = {
			"door", "window", "stair", "plant",
			"fireplace", "column", "pool"
		};
		if (o->m_sort.build < int(sizeof s/sizeof s[0]) + 1) {
			printf("      build type: %s\n",
				s[o->m_sort.build - 1]);
		} else {
			printf("%5d build type\n", o->m_sort.build);
		}
	}
	static char *fns[] = {
		"seating", "surface", "appliance", "electronics",
		"plumbing", "decorative", "general", "lighting", 0
	};
	static char x10[] = "0x10";
	static char x20[] = "0x20";
	static char x40[] = "0x40";
	static char misc[] = "miscellaneous";
	if (o->m_sort.fn != 0) {
		// this needs to be articulated better
		printf("      function buy mode:");
		prettyPrintBits(fns, o->m_sort.fn);
		printf("; subsort:");
		char **subfn;
		static char other1[] = "other1";
		static char other2[] = "other2";
		switch (o->m_sort.fn) {
		case OBJD_t::m_sort::functSeating: {		// seating
				static char *strs[] = {
					"dining", "lounge", "sofa", "bed",
					other1, x20, x40, other2,
					0
				};
				subfn = strs;
			}
			break;
		case OBJD_t::m_sort::functSurface: {		// surface
				static char *strs[] = {
					"counter", "table", "end table", "desk",
					other1, x20, x40, other2,
					0
				};
				subfn = strs;
			}
			break;
		case OBJD_t::m_sort::functAppliance: {	// appliance
				static char *strs[] = {
					"stove", "fridge", "small", "large",
					other1, x20, x40, other2,
					0
				};
				subfn = strs;
			}
			break;
		case OBJD_t::m_sort::functElectronics: {	// electronics
				static char *strs[] = {
					"entertainment", "video", "audio", "phones",
					other1, x20, x40, other2,
					0
				};
				subfn = strs;
			}
			break;
		case OBJD_t::m_sort::functPlumbing: {		// plumbing
				static char *strs[] = {
					"toilet", "shower/tub", "sink", "hot tub",
					other1, x20, x40, other2,
					0
				};
				subfn = strs;
			}
			break;
		case OBJD_t::m_sort::functDecorative: {		// decorative
				static char *strs[] = {
					"painting", "sculpture", "rug", "plant",
					other1, x20, x40, other2,
					0
				};
				subfn = strs;
			}
			break;
		case OBJD_t::m_sort::functGeneral: {		// general
				static char *strs[] = {
					"recreation", "knowledge", "creativity", "wardrobe",
					other1, "pets", x40, other2,
					0
				};
				subfn = strs;
			}
			break;
		case OBJD_t::m_sort::functLighting: {		// lighting
				static char *strs[] = {
					"table", "floor", "wall", "hanging",
					other1, x20, x40, other2,
					0
				};
				subfn = strs;
			}
			break;
		default: {
				static char *strs[] = {
					"0x01", "0x02", "0x04", "0x08",
					other1, x20, x40, other2,
					0
				};
				subfn = strs;
			}
			break;
		}
		prettyPrintBits(subfn, o->m_sort.fnSubSort);
		putchar('\n');
	}
	if (o->m_sort.room != 0) {
		printf("      room buy mode:");
		static char *strs[] = {
			"kitchen", "bedroom", "bathroom", "family room",
			"outside", "dining room", misc, "study",
			0
		};
		prettyPrintBits(strs, o->m_sort.room);
		printf("; subsort:");
		prettyPrintBits(fns, o->m_sort.fn);
		putchar('\n');
	}
	if (o->m_sort.downtown != 0) {
		printf("      downtown buy mode:");
		static char *strs[] = {
			"dining", "shops", "outdoors", "street",
			x10, x20, x40, misc,
			0
		};
		prettyPrintBits(strs, o->m_sort.downtown);
		printf("; subsort:");
		prettyPrintBits(fns, o->m_sort.fn);
		putchar('\n');
	}
	if (o->m_sort.vacation != 0) {
		printf("      vacation buy mode:");
		static char *strs[] = {
			"lodging", "shops", "recreation", "amenities",
			x10, x20, x40, misc,
			0
		};
		prettyPrintBits(strs, o->m_sort.vacation);
		printf("; subsort:");
		prettyPrintBits(fns, o->m_sort.fn);
		putchar('\n');
	}
	if (o->m_sort.community != 0) {
		printf("      community buy mode:");
		static char *strs[] = {
			"food", "shops", "outdoors", "street",
			x10, x20, x40, misc,
			0
		};
		prettyPrintBits(strs, o->m_sort.community);
		printf("; subsort:");
		prettyPrintBits(fns, o->m_sort.fn);
		putchar('\n');
	}
	if (o->m_sort.studiotown != 0) {
		printf("      community buy mode:");
		static char *strs[] = {
			"food", "shops", "studio", "spa",
			x10, x20, x40, misc,
			0
		};
		prettyPrintBits(strs, o->m_sort.community);
		printf("; subsort:");
		prettyPrintBits(fns, o->m_sort.fn);
		putchar('\n');
	}
	printf("%5d buy ", o->m_depreciation.buy);
	printf("%d sell; depreciation ", o->m_depreciation.sell);
	printf("%d self ", o->m_depreciation.isSelf);
	printf("%d initial ", o->m_depreciation.initial);
	printf("%d daily ", o->m_depreciation.daily);
	printf("%d limit\n", o->m_depreciation.limit);
	printf("%5d keep buying\n", o->m_keepBuying);
	printf("%5d CTSS ID (catalog text) ", o->m_catalogStr);
	printf("%d catalog popup ID\n", o->m_catalogID);
	printf("%5d thumbnail graphic\n", o->m_thumbnail);
	if ((o->m_rating.hunger | o->m_rating.comfort | o->m_rating.hygiene
	   | o->m_rating.bladder | o->m_rating.energy | o->m_rating.fun
	   | o->m_rating.room) != 0)
	{
		printf("      motives:");
		if (o->m_rating.hunger != 0) {
			printf(" hunger %d", o->m_rating.hunger);
		}
		if (o->m_rating.comfort != 0) {
			printf(" comfort %d", o->m_rating.comfort);
		}
		if (o->m_rating.hygiene != 0) {
			printf(" hygiene %d", o->m_rating.hygiene);
		}
		if (o->m_rating.bladder != 0) {
			printf(" bladder %d", o->m_rating.bladder);
		}
		if (o->m_rating.energy != 0) {
			printf(" energy %d", o->m_rating.energy);
		}
		if (o->m_rating.fun != 0) {
			printf(" fun %d", o->m_rating.fun);
		}
		if (o->m_rating.room != 0) {
			printf(" room %d", o->m_rating.room);
		}
		putchar('\n');
	}
	if (o->m_rating.skills != 0) {
		static char *skills[] = {
			"cooking", "mechanical", "logic", "body",
			"creativity", "charisma", "school-study",
			0
		};
		printf("      skills:");
		prettyPrintBits(skills, o->m_rating.skills);
		putchar('\n');
	}
}
static inline void prettyPrintSlave(const simIFF_OBJD &o, std::ostream *out)
{
	if (o->m_masterID != 0 && o->m_subIndex == -1) return;
	printf("Slave information:\n");
	printf("%5d base graphic\n", o->m_baseGraphic);
	printf("%5d graphics count\n", o->m_numGraphics);
	printf("%5d anim table ID\n", o->m_animTblID);
	printf("%5d shadow ", o->m_shadow.itself);
	printf("%3.3X flags ", o->m_shadow.flags);
	printf("%d brightness\n", o->m_shadow.bright);
	printf("%5d sprite base ID ", o->m_spriteID);
	printf("%d count\n", o->m_numSprites);
	printf("%5d wall style ", o->m_wall.style);
	printf("%d sprite ID\n", o->m_wall.sprite);
	printf("%5d chair flags\n", o->m_chairFlgs);
	printf("%5d tile width\n", o->m_tileWidth);
}
static void printEntry(const char *fmt, int entry)
{
	static int once = 0;
	if (fmt == 0) {
		once = 0;
		return;
	}
	if (entry != 0) {
		if (once == 0) {
			++once;
			printf("Non-zero entry points:\n");
		}
		printf(fmt, entry);
	}
}
void simIFF_OBJD::prettyPrint(std::ostream *out) const
{
	printf("version %d\n", 138);
	if (tbl.m_masterID == 0) {
		printf("Single-tile object, sub-index (%d) ignored\n",
			tbl.m_subIndex);
	} else if (tbl.m_subIndex == -1) {
		printf("Multi-tile ID %d master\n", tbl.m_masterID);
	} else {
		printf("Multi-tile ID %d slave at (%d, %d) level %d\n",
			tbl.m_masterID,
			tbl.m_subIndex&0xFF, tbl.m_subIndex>>8,
			tbl.m_levelOffset);
	}
	printf("%8.8X GUID\n", tbl.m_guid.itself);
	printf("%8.8X original GUID\n", tbl.m_guid.orig);
	printf("%8.8X suit GUID\n", tbl.m_guid.suit);
	printf("%8.8X type attr GUID\n", tbl.m_guid.typeAttr);
	printf("%5d initial stack\n", tbl.m_stackSz);
	// moving.......
	printf("%5d body string ID\n", tbl.m_bodyID);
	printf("%5d slot ID\n", tbl.m_slotID);
	printf("%5d reset lot action\n", tbl.m_resetLot);
	printf("%5d global flag\n", tbl.m_isGlobal);
	printf("%5d object version\n", tbl.m_objVers);
	printf("%5d motive effects ID\n", tbl.m_motiveID);
	printf("%5d number of attributes\n", tbl.m_numAttrs);
	printf("%5d front direction\n", tbl.m_frontDir);
	printf("%5d MT lead object\n", tbl.m_leadObj);
	printf("%5d inhibit suit copy\n", tbl.m_noSuitCopy);
	printf("%5d footprint mask\n", tbl.m_footprint);
	printf("%5d number of type attrs\n", tbl.m_numTypes);
	printf("%5d misc flags\n", tbl.m_misc);
	printf("%5d tree table ID\n", tbl.m_treeTblID);
	prettyPrintMaster(*this, out);
	prettyPrintSlave(*this, out);
	for (size_t i = 0; i < sizeof tbl.m_unused/sizeof tbl.m_unused[0]; ++i) {
		if (tbl.m_unused[i] != 0) printf("%5d unused[%d]\n",
						tbl.m_unused[i], (int)i);
	}
	//
	printEntry(0, 0);	// initialize
	printEntry("%5d main\n", tbl.m_oldTreeID.main);
	printEntry("%5d init\n", tbl.m_oldTreeID.init);
	printEntry("%5d load\n", tbl.m_oldTreeID.load);
	printEntry("%5d cleanup\n", tbl.m_oldTreeID.cleanup);
	printEntry("%5d queue skipped\n", tbl.m_oldTreeID.qSkip);
	printEntry("%5d clean\n", tbl.m_oldTreeID.clean);
	printEntry("%5d gardening\n", tbl.m_oldTreeID.garden);
	printEntry("%5d repair\n", tbl.m_oldTreeID.repair);
	printEntry("%5d wash hands\n", tbl.m_oldTreeID.washHands);
	printEntry("%5d portal\n", tbl.m_oldTreeID.portal);
	printEntry("%5d serving surface\n", tbl.m_oldTreeID.servingSurf);
	printEntry("%5d eating surface\n", tbl.m_oldTreeID.eatSurface);
	printEntry("%5d prepare food\n", tbl.m_oldTreeID.prepareFood);
	printEntry("%5d cook food\n", tbl.m_oldTreeID.cookFood);
	printEntry("%5d eat food\n", tbl.m_oldTreeID.eat);
	printEntry("%5d wash dish\n", tbl.m_oldTreeID.washDish);
	printEntry("%5d place on surface\n", tbl.m_oldTreeID.placeSurface);
	printEntry("%5d pick up\n", tbl.m_oldTreeID.pickup);
	printEntry("%5d pick up from slot\n", tbl.m_oldTreeID.pickUp);
	printEntry("%5d dispose\n", tbl.m_oldTreeID.dispose);
	printEntry("%5d place\n", tbl.m_oldTreeID.place);
	printEntry("%5d user pickup\n", tbl.m_oldTreeID.godPickup);
	printEntry("%5d user place\n", tbl.m_oldTreeID.godPlace);
	printEntry("%5d sit\n", tbl.m_oldTreeID.sit);
	printEntry("%5d stand\n", tbl.m_oldTreeID.stand);
	printEntry("%5d allow intersection\n", tbl.m_oldTreeID.intersection);
	printEntry("%5d room changed\n", tbl.m_oldTreeID.roomChange);
	printEntry("%5d wall adjacency changed\n", tbl.m_oldTreeID.wallAdj);
	printEntry("%5d dynamic multi-tile update\n", tbl.m_oldTreeID.multiTile);
	printEntry("%5d level info request\n", tbl.m_oldTreeID.levelInfo);
}
