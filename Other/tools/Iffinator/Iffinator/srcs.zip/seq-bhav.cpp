class Inst
{
	Inst *m_next;		// assigned next position
	Inst *m_norm;		// next normal flow; null if exit
	Inst *m_alt;		// next alternate flow; null if exit
	unsigned char m_label;	// this is the nth instruction
	unsigned char m_inst[12]; // instruction
public:
	Inst(unsigned char l, unsigned char *i);
	~Inst(void);
	int norm(void)		{ return m_inst[2]; }
	int alt(void)		{ return m_inst[3]; }
	int label(void)		{ return m_label; }
	void append(Inst *i)	{ m_next = i; }
	void resequence(void);
};

class Block
{
	Block *m_prev, *m_next;	// linked list of blocks
	Inst *m_first, *m_last;	// instructions in block
	Block *m_norm, *m_alt;	// block with normal/alternate instructions
	short m_refs;		// references to instruction at head of block
	short m_resolved;	// resolved references
public:
	Block(Block *prev, Inst *initial);
	void ref(void)		{ ++m_refs; }
	void resolve(void)	{ ++m_resolved; }
	int refs(void)		{ return m_refs - m_resolved; }
	int out(void)		{ return (m_norm != 0) + (m_alt != 0); }
	Block *dest(void);	// get destination if unique
	void merge(Block *b);	// merge block into this one
	void basic_block(void);	// create basic block
	int loop(Block *p);	// resolve loop back-references
	int eval(void);		// evaluate complex flow
	void resequence(void);	// resequence instructions
};

Inst::Inst(unsigned char l, unsigned char *inst)
:	m_next(0), m_label(l)
{
	m_norm = (inst[2] < 253) ? this + (inst[2] - l) : 0;
	m_alt  = (inst[3] < 253) ? this + (inst[3] - l) : 0;
	for (int i = 0; i < 12; ++i) m_inst[i] = inst[i];
}

void Inst::resequence(void)
{
	int i = 0;
	for (Inst *p = this; p != 0; p = p->m_next) {
		p->m_label = i++;
	}
}

Block::Block(Block *prev, Inst *initial)
:	m_prev(prev), m_next(0), m_first(initial), m_last(initial),
	m_refs(0), m_resolved(0)
{
	if (prev != 0) prev->m_next = this;
	if (initial->norm() >= 253) {
		m_norm = 0;
	} else {
		m_norm = this + (initial->norm() - initial->label());
		m_norm->ref();
		if (m_norm == this) {
			// an instruction can branch to itself
			resolve();
			m_norm = 0;
		}
	}
	if (initial->alt() >= 253) {
		m_alt = 0;
	} else {
		m_alt = this + (initial->alt() - initial->label());
		if (m_norm == m_alt) {
			// both lead to same; no need to track both
			m_alt = 0;
		} else {
			m_alt->ref();
			if (m_alt == this) {
				// branch to self
				resolve();
				m_alt = 0;
			}
		}
	}
}

Block *Block::dest(void)
{
	// returns destination if single-out, otherwise null
	if (m_norm == 0) return m_alt;
	if (m_alt == 0) return m_norm;
	return 0;
}

void Block::merge(Block *p)
{
	// unlink p from list
	if (p->m_prev != 0) p->m_prev->m_next = p->m_next;
	if (p->m_next != 0) p->m_next->m_prev = p->m_prev;
	// add its list to ours
	m_last->append(p->m_first);
	m_last = p->m_last;
}

void Block::basic_block(void)
{
	// absorb singleton instructions until complex flow is encountered
	int branches = out();
	// can't flow if we aren't single-out
	while (branches == 1) {
		Block *p = dest();
		// can't flow to multiple-in block
		if (p->refs() != 1) break;
		merge(p);
		// our tail is now its tail
		m_norm = p->m_norm, m_alt = p->m_alt;
		// keep flowing if we are single-out
		branches = out();
	}
}

int Block::loop(Block *p)
{
	// resolve back references
	int progress = 0;
	if (m_norm == p) {
		p->resolve();
		m_norm = 0;
		++progress;
	}
	if (m_alt == p) {
		p->resolve();
		m_alt = 0;
		++progress;
	}
	return progress;
}

int Block::eval(void)
{
	int progress = 0, type;
    again:;
	if ((type = out()) == 0) return progress; // no more progress to make
	if (type == 1) {
		// single-out; see if it's part of our loop
		Block *p = dest();
		progress += p->loop(this);
		// see if can merge
		if (p->refs() == 1) {
			// only one reference and we are it
			merge(p);
			// our tail is now its tail
			m_norm = p->m_norm, m_alt = p->m_alt;
			// we are agressive about absorbing
			// single-out, single-in sequences...
			++progress;
			goto again;
		}
		return progress;
	}
	// both exits are present; see what we can do
	progress += m_norm->loop(this) + m_alt->loop(this);
	// one-branch if: we share a common destination
	// note that dest() returns null if not single-out
	if (m_norm->refs() == 1 && m_norm->dest() == m_alt) {
		merge(m_norm);
		m_norm = 0;
		return progress + 1;
	}
	if (m_alt->refs() == 1 && m_alt->dest() == m_norm) {
		merge(m_alt);
		m_alt = 0;
		return progress + 1;
	}
	// two-branch if: both branches share a common destination
	if (m_norm->refs() == 1 && m_alt->refs() == 1
	    && m_norm->dest() == m_alt->dest())
	{
	}
	// pull in singleton sequence
	if (m_norm->refs() == 1 && m_norm->out() <= 1) {
		merge(m_norm);
		m_norm = m_norm->m_norm;
		return progress + 1;
	}
	if (m_alt->refs() == 1 && m_alt->out() <= 1) {
		merge(m_alt);
		m_alt = m_alt->m_alt;
		return progress + 1;
	}
	return progress;
}

void Block::resequence(void)
{
	ref();	// treat entry point as a reference so it won't be merged
	
	// create basic blocks
	for (Block *p = this; p != 0; p = p->m_next) {
		p->basic_block();
	}

	while (m_next != 0) {
		int progress = 0;
		for (Block *p = this; p != 0; p = p->m_next) {
			progress += p->eval();
		}
		if (progress > 0) continue;
		// no progress on this iteration; forcibly merge
		while (m_next != 0) merge(m_next);
	}
	m_first->resequence();
	--m_refs;
}
