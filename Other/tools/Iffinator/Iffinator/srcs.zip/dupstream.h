#ifndef __SIMS_dupstream_h
#define __SIMS_dupstream_h

// a disposable version of another stream
//
// When an istream must be handed to a routine that takes ownership of it
// (i.e., deletes it when it's done), this class provides a disposable
// istream that simply highjacks the underlying istream's buffer.

#include <iostream>

class dupstream : public std::istream
{
public:
	dupstream(std::istream *source)
	:	std::istream(source->rdbuf())
	{
		seekg(0);	// make sure it's rewound before use
	}
	~dupstream(void) { }
};

#endif // __SIMS_dupstream_h
