#include <fstream>
#include "far.h"
#include "substream.h"

//using namespace std;

inline simFAR::Entry::Entry(void) : m_name(0) { }
inline simFAR::Entry::~Entry(void) { delete[] m_name; }

std::istream *simFAR::Entry::stream(void) const
{
	return new substream(m_parent->m_stream, m_offset, m_length);
	return 0;
}

static inline int readInt(std::istream *in)
{
	// need to do it this way to make sure references are serialized
	unsigned char a = in->get(), b = in->get(), c = in->get();
	return (((((in->get()<<8) | c)<<8) | b)<<8) | a;
}

void simFAR::init(void)
{
	m_list = 0;
	std::istream *in = m_stream;
	if (in->fail()) return;
	for (char *p = signature(); *p; ++p) {
		char c;
		in->get(c);
		if (c != *p) {
			return;	/// ERROR: invalid signature
		}
	}
	if ((m_version = readInt(in)) != 1) {
		return; /// ERROR: we only know this format
	}
	in->seekg(readInt(in), std::ios::beg);
	m_entries = readInt(in);
	m_list = new Entry[m_entries];
	for (unsigned int i = 0; i < m_entries; ++i) {
		Entry *p = &m_list[i];
		p->m_parent = this;
		p->m_length = readInt(in);
		int t = readInt(in);	// keep minimum
		if (t < p->m_length) p->m_length = t;
		p->m_offset = readInt(in);
		p->m_namLen = readInt(in);
		p->m_name = new char[p->m_namLen + 1];
		in->read(p->m_name, p->m_namLen);
		p->m_name[p->m_namLen] = '\0';
	}
}

simFAR::simFAR(const char *file)
{
	m_stream = new std::ifstream(file);
	init();
}

simFAR::~simFAR(void)
{
	delete m_stream;
	delete[] m_list;
}
