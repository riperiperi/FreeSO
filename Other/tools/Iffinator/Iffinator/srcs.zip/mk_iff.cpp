#include <iosfwd>

class simIFF;

class simMkIFF_Input
{
public:
	virtual ~simMkIFF_Input(void);
	virtual int write(std::ostream *out) = 0;
};

class simMkIFF
{
public:
	struct entry {
		entry *m_next;		// link to next entry
		simMkIFF_Input *m_input; // input for this entry
		const char *m_name;	// name for this entry
		unsigned int m_start;	// offset of header
		unsigned short m_id;	// resource ID
		unsigned short m_flags;	// flags for this entry
		~entry(void);		// clean up
	};
	struct type {
		type *m_next;		// link to next type
		entry *m_entries;	// list of entries of this type
		char m_type[4];		// four-character resource type
		int m_count;		// number of entries
		~type(void);		// clean up
	} *m_types;
private:
	std::ostream *m_stream;		// output stream
	int m_count;			// number of types
	struct myIFF;			// a list of IFFs
	myIFF *m_iffs;			// IFFs loaded in this class
public:
	simMkIFF(std::ostream *out);	// write to existing stream
	simMkIFF(const char *file);	// write to filename
	~simMkIFF(void);		// finish off
	int err(void) const	{ return m_stream == 0; }
	void add(simMkIFF_Input *in, const char *type, int id,
		int flags, const char *name);	// add stream by name
	void add(std::istream *in, const char *type, int id,
		int flags, const char *name);	// add stream by name
	void add(simIFF *in);		// add contents of existing .iff
	void add(const char *name);	// add from filesystem
	void zap(const char *type, int id); // delete entry
};

class simMkIFF_Input_Stream : public simMkIFF_Input
{
	std::istream *m_stream;
public:
	simMkIFF_Input_Stream(std::istream *s) : m_stream(s) {}
	~simMkIFF_Input_Stream(void);
	int write(std::ostream *out);
};

// #include "mkiff.h"
#include "iff.h"
#include <iostream>
#include <fstream>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>

simMkIFF::simMkIFF(std::ostream *out)
{
	m_stream = out;
	m_types = 0, m_count = 0;
	m_iffs = 0;
}

simMkIFF::simMkIFF(const char *file)
{
	if (!(m_stream = new std::ofstream(file))->good()) {
		// open failed
		delete m_stream;
		m_stream = 0;
	}
	m_types = 0, m_count = 0;
	m_iffs = 0;
}

simMkIFF::entry::~entry(void)
{
	delete m_input;
	delete[] m_name;
}

simMkIFF::type::~type(void)
{
}

static inline void writeIntLittle(std::ostream *out, int i)
{
	// write integer in little-endian
	out->put((char)i), i >>= 8;
	out->put((char)i), i >>= 8;
	out->put((char)i), i >>= 8;
	out->put((char)i);
}

static inline void writeIntBig(std::ostream *out, int i)
{
	// write integer in big-endian
	out->put((char)(i>>24));
	out->put((char)(i>>16));
	out->put((char)(i>>8));
	out->put((char)i);
}

static inline int isType(const unsigned char *a, const unsigned char *b)
{
	if (a[0] != b[0]) return a[0] - b[0];
	if (a[1] != b[1]) return a[1] - b[1];
	if (a[2] != b[2]) return a[2] - b[2];
	return b[3] - a[3];
}
static inline int isType(const char *a, const char *b)
{
	return isType((const unsigned char *)a, (const unsigned char *)b);
}

void simMkIFF::add(simMkIFF_Input *in, const char *ptype,
		int id, int flags, const char *name)
{
	if (isType(ptype, "XXXX") == 0 || isType(ptype, "rsmp") == 0) {
		// never put resource types 'XXXX' or 'rsmp' in file
		delete in;
		return;
	}
	// for no particular reason other than neatness,
	// types are kept sorted
	type *t, **p = &m_types;
	while ((t = *p) != 0) {
		if (isType(t->m_type, ptype) == 0) goto found_type;
		if (isType(t->m_type, ptype) > 0) break;
		p = &t->m_next;
	}
	*p = new type, (*p)->m_next = t, t = *p, ++m_count;
	t->m_entries = 0;
	strncpy(t->m_type, ptype, 4);
	t->m_count = 0;
    found_type:
	// for the same reason, entries are sorted by ID
	entry *e, **q = &t->m_entries;;
	while ((e = *q) != 0) {
		if (e->m_id == id) {
			#if 0
				// already have an entry with this ID
				// so just drop the latest candidate
				delete in;
				return;
			#else
				// if already have an entry with this
				// ID so delete existing entry
				entry *p = e;
				e = e->m_next; --t->m_count;
				delete p;
				break;
			#endif
		}
		if (e->m_id > id) break;
		q = &e->m_next;
	}
	*q = new entry, (*q)->m_next = e, e = *q, ++t->m_count;
	e->m_input = in;
	e->m_name = new char[strlen(name) + 1];
	strcpy((char *)e->m_name, name);
	e->m_id = id;
	e->m_flags = flags;
}

void simMkIFF::add(std::istream *in, const char *ptype,
		int id, int flags, const char *name)
{
	add(new simMkIFF_Input_Stream(in), ptype, id, flags, name);
}

struct simMkIFF::myIFF
// a list of simIFFs so we can delete them after processing
{
	myIFF *m_next;
	simIFF *m_iff;
	myIFF(myIFF *next, simIFF *iff) : m_next(next), m_iff(iff) {}
	~myIFF(void)	{ delete m_iff; };
};

void simMkIFF::add(simIFF *in)
{
	m_iffs = new myIFF(m_iffs, in);
	for (int i = 0; i < in->entries(); ++i) {
		simIFF::Entry &e = (*in)[i];
		add(e.stream(), e.type(), e.id(), e.flags(), e.name());
	}
}

static int skipSpace(std::istream &in)
{
	int c;
	do {
		if ((c = in.get()) == EOF || c == '\n' || c == '\r') break;
	} while (c == ' ' || c == '\t');
	return c;
}

static int getInt(std::istream &in)
{
	int c = skipSpace(in);
	// must be at least one digit
	if (c < '0' || c > '9') return -1;
	int v = c - '0';
	for (;;) {
		if ((c = in.get()) == EOF || c == '\n' || c == '\r') break;
		if (c < '0' || c > '9') break;
		v = v*10 + (c - '0');
	}
	in.unget();
	return v;
}

static int getOct(std::istream &in)
{
	int c = skipSpace(in);
	// must be at least one digit
	if (c < '0' || c > '7') return -1;
	int v = c - '0';
	for (;;) {
		if ((c = in.get()) == EOF || c == '\n' || c == '\r') break;
		if (c < '0' || c > '7') break;
		v = (v<<3) + (c - '0');
	}
	in.unget();
	return v;
}

void simMkIFF::add(const char *file)
// add to new .iff from filesystem
// if file is a regular file, then it is a table of contents to be added
// if file is a directory, then the table of contents is the .toc file
// relative pathnames are always relative to the table of contents file
{
	struct stat sb;
	if (stat(file, &sb) < 0) return;
	if ((sb.st_mode&S_IFMT) == S_IFDIR) {
		// if it's a directory, add /.toc to get the toc
		char toc[strlen(file) + 6];
		strcpy(toc, file);
		strcat(toc, "/.toc");
		add(toc);
		return;
	}
	// if it's a regular file, try opening it
	if ((sb.st_mode&S_IFMT) != S_IFREG) return;
	std::ifstream toc(file);
	if (!toc.good()) return;
	// it can be opened; see if it's an IFF file
	simIFF *iff = new simIFF(file);
	if (!iff->err()) {
		// yup, it's an iff file...
		add(iff);
		return;
	}
	delete iff;
	//
	// find the base for relative pathnames
	const char *base = "./"; int baselen = 2;
	for (const char *f = file; *f != '\0'; ++f) {
		if (*f == '/') {
			base = file;
			baselen = f - file + 1;
		}
	}
	// for each line of the TOC, add an entry
	for (;;) {
		// everything up to the tab is the filename
		char filename[1024], *f = filename;
		int c;
		do {
			if ((c = toc.get()) == EOF) return;
		} while (c == '\n' || c == '\r');
		if (c != '/') {
			strncpy(filename, base, baselen);
			f += baselen;
		}
		while (c != '\t') {
			// simple malformedness check
			if (c == EOF || c == '\n' || c == '\r') return;
			*f++ = c;
			c = toc.get();
		}
		*f = '\0';
		//
		// next four characters are the resource type
		char type[4];
		if ((c = toc.get()) == EOF || c == '\n' || c == '\r') return;
		type[0] = c;
		if ((c = toc.get()) == EOF || c == '\n' || c == '\r') return;
		type[1] = c;
		if ((c = toc.get()) == EOF || c == '\n' || c == '\r') return;
		type[2] = c;
		if ((c = toc.get()) == EOF || c == '\n' || c == '\r') return;
		type[3] = c;
		//
		// next is decimal number of resource ID
		int id = getInt(toc);
		if (id < 0) return;
		//
		// next is octal number of resource flags
		int flags = getOct(toc);
		if (flags < 0) return;
		// rest of line is descriptive text
		c = skipSpace(toc);
		char name[1024], *n = name;
		while (c != '\n' && c != '\r') {
			*n++ = c;
			c = toc.get();
		}
		*n = '\0';
		// OK, we've read the line and collected the information,
		// it's time to add it to our collection
		if (stat(filename, &sb) < 0) continue;
		if ((sb.st_mode&S_IFMT) != S_IFREG) continue;
		std::ifstream *in = new std::ifstream(filename);
		if (!in->good()) { delete in; continue; }
		add(in, type, id, flags, name);
	}
}

void simMkIFF::zap(const char *rsrc, int id)
// remove an entry permenently
{
	// find the type
	for (type *t = m_types; t != 0; t = t->m_next) {
		if (strncmp(t->m_type, rsrc, 4) == 0) continue;
		// find the ID
		for (entry *e, **p = &t->m_entries; (e = *p) != 0;
			p = &e->m_next)
		{
			if (e->m_id != id) continue;
			// remove and delete it
			*p = e->m_next; --t->m_count;
			delete e;
			break;
		}
		break;
	}
}

static inline void writeShortBig(std::ostream *out, int v)
{
	out->put(char(v>>8));
	out->put(char(v));
}

static inline void writeShortLittle(std::ostream *out, int v)
{
	out->put(char(v));
	out->put(char(v>>8));
}

// a class derived from simMkIFF_Input that is
// used for writing the resource map

class my_rsmp : public simMkIFF_Input
{
	simMkIFF::type *m_types;
	int m_count;
public:
	my_rsmp(simMkIFF::type *t, int i) : m_types(t), m_count(i) {}
	int write(std::ostream *out);
};
int my_rsmp::write(std::ostream *out)
{
	unsigned int start = out->tellp();
	//
	// write the resource header
	writeIntLittle(out, 0);		// unknown
	writeIntLittle(out, 0);		// version
	out->write("pmsr", 4);
	writeIntLittle(out, 0);		// size is ignored if zero
	writeIntLittle(out, m_count);	// count of resource types
	//
	// walk the entries and write the information for each one
	// as we go, delete the dynamically allocated storage
	simMkIFF::type *t; simMkIFF::entry *e;
	while ((t = m_types) != 0) {
		(*out) << t->m_type[3]<<t->m_type[2]<<t->m_type[1]<<t->m_type[0];
		writeIntLittle(out, t->m_count);
		m_types = t->m_next;
		while ((e = t->m_entries) != 0) {
			t->m_entries = e->m_next;
			writeIntLittle(out, e->m_start);
			writeShortLittle(out, e->m_id);
			writeShortLittle(out, e->m_flags);
			out->write(e->m_name, strlen(e->m_name) + 1);
			if (((out->tellp() - std::streampos(start))&1) != 0) {
				out->put('\0');
			}
			delete e;
		}
		delete t;
	}
	// TODO: insert the size (fourth field)
	return 0;
}

static inline
void iff_entry(std::ostream *out, const char *type, simMkIFF::entry *e)
{
	// fill in the resource offset, used when creating rsmp
	e->m_start = out->tellp();
	//
	// write resource header: type, length, ID, flags, and name
	out->write(type, 4);
	out->seekp(4, std::ios::cur);	// space for length
	writeShortBig(out, e->m_id);
	writeShortBig(out, e->m_flags);
	const char *p = e->m_name;
	for (int i = 0; i < 64; ++i) {
		out->put(*p);
		if (*p != 0) ++p;
	}
	//
	// write contents
	e->m_input->write(out);
	//
	// insert length into header
	unsigned int here = out->tellp();
	out->seekp(e->m_start + 4);
	writeIntBig(out, here - e->m_start);
	out->seekp(here);
}

simMkIFF::~simMkIFF(void)
{
	static char signature[] = {
		"IFF FILE 2.5:TYPE FOLLOWED BY SIZE\0"
		" JAMIE DOORNBOS & MAXIS 1\0\0\0" };
	unsigned int here = m_stream->tellp();
	//
	// write file signature (and space for rsmp pointer)
	m_stream->write(signature, 64);
	//
	// walk through the entries and write each resource
	type *t; entry *e;
	for (t = m_types; t != 0; t = t->m_next) {
		for (e = t->m_entries; e != 0; e = e->m_next) {
			// write resource and adjust offset
			iff_entry(m_stream, t->m_type, e);
			e->m_start -= here;
		}
	}
	//
	// insert resource map pointer
	unsigned int now = m_stream->tellp();
	m_stream->seekp(here + 60);
	writeIntBig(m_stream, now - here);
	m_stream->seekp(now);
	//
	// dummy up an IFF entry, then write it
	struct entry rsmp;
	rsmp.m_input = new my_rsmp(m_types, m_count);
	rsmp.m_name = "resource map by mk_iff";
	rsmp.m_id = 0, rsmp.m_flags = 0x10;
	iff_entry(m_stream, "rsmp", &rsmp);
	rsmp.m_name = 0;	// don't delete name!
	//
	// finally, delete any simIFF files that were used
	for (myIFF *p = m_iffs, *q; p != 0; p = q) {
		q = p->m_next;
		delete p;
	}
};

simMkIFF_Input::~simMkIFF_Input(void)
{
}

int simMkIFF_Input_Stream::write(std::ostream *out)
{
	char buf[4096];
	int l;
	while ((l = m_stream->read(buf, sizeof buf).gcount()) > 0) {
		out->write(buf, l);
	}
	return 0;
}

simMkIFF_Input_Stream::~simMkIFF_Input_Stream(void)
{
	delete m_stream;
}

// #include "mkiff.h"
#include "iff.h"
#include <iostream>

int main(int argc, char **argv)
{
	if (argc < 3) {
		std::cout << "Usage: mk_iff out.iff arg ..." << std::endl;
		std::cout << " where arg can be a directory, "
			"a table-of-contents file, "
			"or an iff archive" << std::endl;
		return 1;
	}
	simMkIFF iff(argv[1]);
	int errs = 0;
	if (iff.err()) {
		std::cout << "Could not open output file `" << argv[1] << "'"
			<< std::endl;
		++errs;
	}
	for (int i = 2; i < argc; ++i) iff.add(argv[i]);
	return errs;
}
