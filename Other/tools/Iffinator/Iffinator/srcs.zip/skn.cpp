#include "skn.h"
#include <fstream>
#include "crack.h"

simSkin::simSkin(std::istream *stream, int ascii)
{
	m_name = 0, m_suit = 0, m_bones = 0, m_bone = 0,
	m_face = 0, m_bind = 0, m_blend = 0, m_textures = 0;
	if (stream->fail()) return;
	crack *in = ascii	// choxe appropriate stream cracker
		? (crack*)new crackASCII(stream)
		: (crack*)new crackLittle(stream);
	m_name = in->readCountString();
	m_suit = in->readCountString();
	m_bones = in->readInt();
	m_bone = new char*[m_bones];
	for (int i = 0; i < m_bones; ++i) {
		m_bone[i] = in->readCountString();
	}
	m_faces = in->readInt();
	m_face = new Face[m_faces];
	for (int i = 0; i < m_faces; ++i) {
		m_face[i].vert1 = in->readInt();
		m_face[i].vert2 = in->readInt();
		m_face[i].vert3 = in->readInt();
	}
	m_binds = in->readInt();
	//if (m_binds != m_bones) cout << "LOOK binds " << m_binds << " bones " << m_bones << endl;
	m_bind = new Bind[m_binds];
	for (int i = 0; i < m_binds; ++i) {
		m_bind[i].bone = in->readInt();
		//if (m_bind[i].bone != i) cout << "LOOK " << i << " binding " << m_bind[i].bone << endl;
		m_bind[i].vert = in->readInt();
		m_bind[i].cnt = in->readInt();
		m_bind[i].bvert = in->readInt();
		m_bind[i].bcnt = in->readInt();
	}
	m_textures = in->readInt();
	m_texture = new Texture[m_textures];
	for (int i = 0; i < m_textures; ++i) {
		m_texture[i].x = in->readFloat();
		m_texture[i].y = in->readFloat();
	}
	m_blends = in->readInt();
	m_blend = new Blend[m_blends];
	for (int i = 0; i < m_blends; ++i) {
		// for some reason, these two fields are in one
		// order in the ASCII file and the reverse order
		// in the binary file.
		if (ascii) {
			m_blend[i].vert = in->readInt();
			m_blend[i].weight = in->readInt();
		} else {
			m_blend[i].weight = in->readInt();
			m_blend[i].vert = in->readInt();
		}
	}
	int verts = in->readInt();
	// The number of verts should be equal to the sum of
	// the number of textures plus the number of blends.
	// If it's more, there's a problem, but we can simply
	// ignore the excess values.  If it's less, we have a
	// major catastrophe...
	if (verts < (m_textures + m_blends)) {
		// what to do?
		delete in;
		return;
	}
	for (int i = 0; i < m_textures; ++i) {
		m_texture[i].offset.x = in->readFloat();
		m_texture[i].offset.y = in->readFloat();
		m_texture[i].offset.z = in->readFloat();
		m_texture[i].normal.x = in->readFloat();
		m_texture[i].normal.y = in->readFloat();
		m_texture[i].normal.z = in->readFloat();
	}
	for (int i = 0; i < m_blends; ++i) {
		m_blend[i].offset.x = in->readFloat();
		m_blend[i].offset.y = in->readFloat();
		m_blend[i].offset.z = in->readFloat();
		m_blend[i].normal.x = in->readFloat();
		m_blend[i].normal.y = in->readFloat();
		m_blend[i].normal.z = in->readFloat();
	}
	//in->dump();
	delete in;
}

simSkinASCII::simSkinASCII(char *file)
:	simSkin(new std::ifstream(file), 1)
{
}

simSkinBinary::simSkinBinary(char *file)
:	simSkin(new std::ifstream(file), 0)
{
}

void simSkin::put_skn(ostream &out) const
{
	static char NewLine[] = "\r\n";
	if (err()) return;
	out << name() << NewLine;
	out << suit() << NewLine;
	out << bones() << NewLine;
	for (int i = 0; i < bones(); ++i) {
		out << bone(i) << NewLine;
	}
	out << faces() << NewLine;
	for (int i = 0; i < faces(); ++i) {
		out	<< face(i).vert1 << ' '
			<< face(i).vert2 << ' '
			<< face(i).vert3 << NewLine;
	}
	out << binds() << NewLine;
	for (int i = 0; i < binds(); ++i) {
		out	<< bind(i).bone << ' '
			<< bind(i).vert << ' '
			<< bind(i).cnt << ' '
			<< bind(i).bvert << ' '
			<< bind(i).bcnt << NewLine;
	}
	out << textures() << NewLine;
	for (int i = 0; i < textures(); ++i) {
		out << texture(i).x << ' ' <<  texture(i).y << NewLine;
	}
	out << blends() << NewLine;
	for (int i = 0; i < blends(); ++i) {
		out << blend(i).vert << ' ' << blend(i).weight << NewLine;
	}
	out << verts() << NewLine;
	for (int i = 0; i < verts(); ++i) {
		out	<< vert(i).offset.x << ' '
			<< vert(i).offset.y << ' '
			<< vert(i).offset.z << ' '
			<< vert(i).normal.x << ' '
			<< vert(i).normal.y << ' '
			<< vert(i).normal.z << NewLine;
	}
}

static void writeIt(ostream &out, const char *v)
{
	// Pascal counted string
	const char *p = v;
	while (*p != '\0') ++p;
	out.put(p - v);
	while (*v != '\0') out.put(*v++);
}

static void writeIt(ostream &out, int v)
{
	// little-endian 32-bit integer
	out.put(v);
	out.put(v >>= 8);
	out.put(v >>= 8);
	out.put(v >>= 8);
}

static inline void writeIt(ostream &out, float v)
{
	int t = *(int*)&v;
	writeIt(out, t);
}

void simSkin::put_bmf(ostream &out) const
{
	if (err()) return;
	writeIt(out, name());
	writeIt(out, suit());
	writeIt(out, bones());
	for (int i = 0; i < bones(); ++i) {
		writeIt(out, bone(i));
	}
	writeIt(out, faces());
	for (int i = 0; i < faces(); ++i) {
		writeIt(out, face(i).vert1);
		writeIt(out, face(i).vert2);
		writeIt(out, face(i).vert3);
	}
	writeIt(out, binds());
	for (int i = 0; i < binds(); ++i) {
		writeIt(out, bind(i).bone);
		writeIt(out, bind(i).vert);
		writeIt(out, bind(i).cnt);
		writeIt(out, bind(i).bvert);
		writeIt(out, bind(i).bcnt);
	}
	writeIt(out, textures());
	for (int i = 0; i < textures(); ++i) {
		writeIt(out, texture(i).x);
		writeIt(out, texture(i).y);
	}
	writeIt(out, blends());
	for (int i = 0; i < blends(); ++i) {
		writeIt(out, blend(i).weight);
		writeIt(out, blend(i).vert);
	}
	writeIt(out, verts());
	for (int i = 0; i < verts(); ++i) {
		writeIt(out, vert(i).offset.x);
		writeIt(out, vert(i).offset.y);
		writeIt(out, vert(i).offset.z);
		writeIt(out, vert(i).normal.x);
		writeIt(out, vert(i).normal.y);
		writeIt(out, vert(i).normal.z);
	}
}

simSkin::~simSkin(void)
{
	delete[] m_name;
	delete[] m_suit;
	for (int i = 0; i < m_bones; ++i) delete m_bone[i];
	delete[] m_bone;
	delete[] m_face;
	delete[] m_bind;
	delete[] m_texture;
	delete[] m_blend;
}
