#include "iff_bhav.h"
#include "iff.h"
#include "iff_fwav.h"
#include "iff_strings.h"
#include <iostream>
#include <fstream>
#include <iomanip>
using std::cout;
using std::endl;
using std::ios;
using std::hex;
using std::dec;
using std::setfill;
using std::setw;

#define CountOf(x)	(sizeof x/sizeof x[0])

static const char assignop[] = { " := " };

// internal struct to speed up decoding by marshalling all
// shared parameters into one place
struct iffDecode {
	unsigned const char *inst;	// instruction being decoded
	std::ostream *out;		// output stream for decoded info
	simIFF *iff;			// local context for decoding
	// return the two-byte word starting at the indicated offest
	inline int oper(int i) const	{ return (inst[i+1]<<8)|inst[i]; }
	// return the character at the indicated offset
	inline unsigned const char &operator[](int i) const { return inst[i]; }
};

static inline		// convert two bytes into a short
int Oper(const unsigned char *oper)
{
	return (oper[1]<<8)|oper[0];
}

static inline		// convert two bytes into a short
int GUID(const unsigned char *oper)
{
	return (((((oper[3]<<8)|oper[2])<<8)|oper[1])<<8)|oper[0];
}

static simIFF *iff;
static inline simIFF::Entry *getEntry(const char *type, int id)
{
	return (iff != 0) ? (*iff)[type].id(id) : 0;
}
static inline const char *EntryName(const char *type, int id)
{
	simIFF::Entry *entry = getEntry(type, id);
	return (entry != 0) ? entry->name() : "";
}
static inline std::istream *EntryStream(const char *type, int id)
{
	simIFF::Entry *entry = getEntry(type, id);
	return (entry != 0) ? entry->stream() : 0;
}

static void AsBits(const char **bits, unsigned int value)
{
	if (value == 0) {
		cout << " (none)";
		return;
	}
	for (int t = 0, i = 1; value != 0; ++i, value >>= 1) {
		if ((value&1) != 0) {
			if (t == 0) t = 1; else cout << '+';
			if (*bits != 0) {
				cout << *bits;
			} else {
				cout << "BIT_" << i;
			}
		}
		if (*bits != 0) ++bits;
	}
}

// Data owners from Behavior.iff STR# 132 (through Unleashed)
// heavily edited
static const char *DataOwners[] = {
	/*  0 */ 0,	// "my attr",
	/*  1 */ 0,	// "stack obj's attr",
	/*  2 */ 0,	// "targ obj's attr [OBSOLETE]",
	/*  3 */ 0,	// "my",			// STR# 141
	/*  4 */ 0,	// "stack obj's",		// STR# 141
	/*  5 */ 0,	// "targ obj's [OBSOLETE]",	// STR# 141
	/*  6 */ "sim global",				// STR# 129
	/*  7 */ 0,	// "literal",
	/*  8 */ "temp",
	/*  9 */ "param",
	/* 10 */ "stack obj ID",
	/* 11 */ "temp[temp ",		// "array of temps"
	/* 12 */ "menu advertisement",
	/* 13 */ "stack obj's temp",
	/* 14 */ 0,	// "my motive",			// STR# 134
	/* 15 */ 0,	// "stack obj's motive",	// STR# 134
	/* 16 */ "stack obj's slot",
	/* 17 */ "stack obj's motive[temp ",		// STR# 134
	/* 18 */ 0,	// "my person data",		// STR# 200
	/* 19 */ 0,	// "stack obj's person data",	// STR# 200
	/* 20 */ "my slot",
	/* 21 */ "stack obj's definition",
	/* 22 */ "stack obj attr[param ",
	/* 23 */ "room[temp 0].",			// STR# 219
	/* 24 */ "neighbor[stack obj].",		// STR# 221
	/* 25 */ "local",
	/* 26 */ 0,	// "constant",			// encoded
	/* 27 */ "stack obj's dynamic sprite flag[temp ",
	/* 28 */ "menu personality",
	/* 29 */ "menu min",
	/* 30 */ "my person data[temp ",		// STR# 200
	/* 31 */ "stack obj's person data[temp ",	// STR# 200
	/* 32 */ "neighbor's person data",		// STR# 200
	/* 33 */ "job data[temp 0,1].",			// STR# 243
	/* 34 */ "neighborhood data",			// STR# 249
	/* 35 */ "stack obj's function",		// STR# 170
	/* 36 */ "my type attr",			// only in HelpSystem
	/* 37 */ "stack obj's type attr",		// only in HelpSystem
	// added in The Sims Online
	/* 38 */ "BadOper38",
	/* 39 */ "BadOper39",
	/* 40 */ "local[temp ",			// "array of locals"
	/* 41 */ "stack obj's attr[temp ",	// "array of attrs"
	};
static void printExpOper(unsigned int code, unsigned int value)
{
	if (code >= CountOf(DataOwners)) {
		cout << "BadOper" << code << '[' << value << ']';
		return;
	}
	extern const char *BhavStr153[];	// short owner list
	switch (code) {
	case 0:		// my attribute
	case 1:		// stack obj's attribute
	case 2:		// target obj's attribute [OBSOLETE]
		cout << BhavStr153[code] << " attr[" << value << ']';
		break;
	case 3:		// my data labels
	case 4:		// stack obj's data labels
	case 5:	{	// target obj's data labels [OBSOLETE]
		cout << BhavStr153[code - 3] << ' ';
		extern int BhavStr141Len;	// Data labels
		if (value < unsigned(BhavStr141Len)) {
			extern const char *BhavStr141[];
			cout << BhavStr141[value];
		} else {
			cout << "data label[" << value << ']';
		}
		} break;
	case 6: {	// sim global
		extern int BhavStr129Len;	// global labels
		if (value >= unsigned(BhavStr129Len)) goto Default;
		extern const char *BhavStr129[];
		cout << BhavStr129[value];
		} break;
	case 7:		// literal
		cout << (short)value; break;
	case 10:	// stack obj ID
		if (value != 0) goto Default;
		cout << DataOwners[code];
		break;
	case 12:	// menu range[motive]
	case 28:	// menu personality[motive]
	case 29: {	// menu min[motive]
		extern int BhavStr134Len;	// motive strings
		if (value >= unsigned(BhavStr134Len)) goto Default;
		extern const char *BhavStr134[];
		cout << BhavStr134[value] << ' ' << DataOwners[code];
		} break;
	case 14:	// my motive
	case 15: {	// stack obj's motive
		cout << BhavStr153[code - 14] << ' ';
		extern int BhavStr134Len;	// motive strings
		if (value < unsigned(BhavStr134Len)) {
			extern const char *BhavStr134[];
			cout << BhavStr134[value] << " motive";
		} else {
			cout << "motive[" << value << ']';
		}
		} break;
	case 18:	// my person data
	case 19: {	// stack obj's person data
		cout << BhavStr153[code - 18] << ' ';
		extern int BhavStr200Len;	// Person Data Labels
		if (value < unsigned(BhavStr200Len)) {
			extern const char *BhavStr200[];
			cout << BhavStr200[value];
		} else {
			cout << "person data[" << value << ']';
		}
		} break;
	case 21: {	// stack obj's definition
		extern int BhavStr204Len;	// definition labels
		if (value >= unsigned(BhavStr204Len)) goto Default;
		extern const char *BhavStr204[];
		cout << BhavStr153[1] << ' ' << BhavStr204[value];
		} break;
	case 23: {	// room[temp 0]
		extern int BhavStr219Len;	// room values
		if (value >= unsigned(BhavStr219Len)) goto Default;
		extern const char *BhavStr219[];
		cout << DataOwners[code] << BhavStr219[value];
		} break;
	case 24: {	// stack obj as neighbor
		extern int BhavStr221Len;	// neighbor data labels
		if (value >= unsigned(BhavStr221Len)) goto Default;
		extern const char *BhavStr221[];
		cout << "neighbor's " << BhavStr221[value];
		} break;
	case 26: {	// reference to BCON constants;
		// const value is tttxxxxxxyyyyyyy
		// where
		//	ttt is three-bit code giving type of BCON
		// 	xxxxxx is six-bit offset from base for type
		//	yyyyyyy is seven-bit index within BCON
		int bcon = (value>>7)&63;	// extract offset
		switch ((value>>13)&7) {
		// only three codes are known
		// it may be that's all that will ever be
		case 0:	bcon += 4096; break;
		case 1:	bcon += 8192; break;
		case 2:	bcon += 256; break;
		default:
			cout << "BAD CONST[" << value << ']';
			break;
		}
		cout << "BCON[" << bcon << ',' << (value&127) << ']';
		} break;
	case 32: {	// neighbor's person data
		extern int BhavStr200Len;	// Person Data Labels
		if (value >= unsigned(BhavStr200Len)) goto Default;
		extern const char *BhavStr200[];
		cout << "neighbor's " << BhavStr200[value];
		} break;
	case 33: {	// job data[temp 0,1]
		extern int BhavStr243Len;	// job data
		if (value >= unsigned(BhavStr243Len)) goto Default;
		extern const char *BhavStr243[];
		cout << DataOwners[code] << BhavStr243[value];
		} break;
	case 34: {	// neighborhood data
		extern int BhavStr249Len;	// neighborhood data labels
		if (value >= unsigned(BhavStr249Len)) goto Default;
		extern const char *BhavStr249[];
		cout << BhavStr249[value];
		} break;
	case 35: {	// stack obj's function
		extern int BhavStr245Len;	// entry points
		if (value >= unsigned(BhavStr245Len)) goto Default;
		extern const char *BhavStr245[];
		cout << BhavStr153[1] << ' ' << BhavStr245[value] << " function";
		} break;
	case 11:	// temp[temp x]
	case 17:	// stack obj's motive[temp x]
	case 22:	// stack obj attr[param x]
	case 27:	// stack obj's dynamic sprite flag[temp x]
	case 30:	// my person data[temp x]
	case 31:	// stack obj's person data[temp x]
	case 40:	// local[temp x]
	case 41:	// stack obj attr[temp x]
		// indexed reference
		cout << DataOwners[code] << value << ']';
		break;
	default:
	Default:
		cout << DataOwners[code] << '[' << value << ']';
	}
}
// allow debugging code to intercept expressions
void (*doExpOper)(unsigned int code, unsigned int value) = printExpOper;

static void default_prim(iffDecode &p)
{
	unsigned int op = p.oper(0);	// operation code
	extern int BhavStr139Len;	// Primitives
	if (op < unsigned(BhavStr139Len)) {
		extern const char *BhavStr139[];
		*p.out << BhavStr139[op];
	} else {
		*p.out << "PRIM_" << op;
	}
	*p.out	<< '(' << p.oper(4) << ", " << p.oper(6) << ", "
		<< p.oper(8) << ", " << p.oper(10) << ')';
}

// Operators from Behavior.iff STR# 136 (through Unleashed)
static const char *Operators[] = {
	/*  0 */ ">",
	/*  1 */ "<",
	/*  2 */ "==",
	/*  3 */ "+=",
	/*  4 */ "-=",
	/*  5 */ ":=",
	/*  6 */ "*=",
	/*  7 */ "/=",
	/*  8 */ "FlagSet?",
	/*  9 */ "SetFlag",
	/* 10 */ "ClrFlag",
	/* 11 */ "++ and <",
	/* 12 */ "%=",
	/* 13 */ "&=",
	/* 14 */ ">=",
	/* 15 */ "<=",
	/* 16 */ "!=",
	/* 17 */ "-- and >",
	// added in Vacation
	/* 18 */ "or=",
	/* 19 */ "xor=",
	/* 20 */ "sqrt=",
	};
// returns zero if operand is not a candidate to be
// expanded for a bit field destination
// otherwise returns bits
static inline int bitop(int op, int own, short data)
{
	// src must be positive literal
	if (own != 7 || data <= 0) return 0;
	//
	switch (op) {
	case 8:		// FlagSet?
	case 9:		// SetFlag
	case 10:	// ClrFlag
	case 18:	// or=
	case 19:	// xor=
		// opcode is bit-op, provide scaled bit
		return 1<<(data - 1);
	case 5:		// assign
	case 2:		// equals
	case 16:	// not equals
		// opcode is a word op, return bits
		return data;
	}
	return 0;
}
static void prim02(const unsigned char *inst)
{
	// destination and source offsets
	int d = (inst[5]<<8) | inst[4], s = (inst[7]<<8) | inst[6];
	// print destination location
	doExpOper(inst[10], d);
	// print operand
	if (inst[9] >= CountOf(Operators)) {
		cout << " UNKNOWN_OP[" << int(inst[9]) << "] ";
	} else {
		cout << ' ' << Operators[inst[9]] << ' ';
	}
	// check for flags
	int t = bitop(inst[9], inst[11], s);
	if (t > 0) switch(inst[10]) {
	case 3: case 4: case 5:		// dest is object data
		switch (d) {
		case 4: {	// allowed height flags
			// TODO allowed height flags
			} break;
		case 5: {	// wall adjacency flags
			extern const char *BhavStr208[];
			AsBits(BhavStr208, t);
			} return;
		case 8: {	// flags field 1
			extern const char *BhavStr142[];
			AsBits(BhavStr142, t);
			} return;
		case 13: {	// wall placement flags
			extern const char *BhavStr229[];
			AsBits(BhavStr229, t);
			} return;
		case 40: {	// flags field 2
			extern const char *BhavStr214[];
			AsBits(BhavStr214, t);
			} return;
		case 42: {	// placement flags
			extern const char *BhavStr202[];
			AsBits(BhavStr202, t);
			} return;
		case 43: {	// movement flags
			extern const char *BhavStr203[];
			AsBits(BhavStr203, t);
			} return;
		case 53: {	// wall block flags
			// TODO walls blocked by open door
			// zero == blocks no walls
			// common values are 1, 4, 16
			} break;
		case 63: {	// exclusive placement flags
			extern const char *BhavStr251[];
			AsBits(BhavStr251, t);
			} return;
		}
		break;
	case 6: 			// dest is global
		switch (d) {
		case 20: { 	// game edition
			extern const char *BhavStr252[];
			AsBits(BhavStr252, t);
			} return;
		case 25: {	// debug flags
			static const char *flags[] = {
				"enable balloons",
				"social outcome"
			};
			AsBits(flags, t);
			} return;
		}
		break;
	case 18: case 19: case 32:	// dest is person data
		switch (d) {
		case 30: {	// censorship flags
			extern const char *BhavStr178[];
			AsBits(BhavStr178, t);
			} return;
		case 37: {	// route entry flags
			// TODO route entry flags
			// can have values of 1, 4, 16, 64
			// maybe STR# 130 plus two?
			} break;
		case 74: {	// render display flags
			extern const char *BhavStr209[];
			AsBits(BhavStr209, t);
			} return;
		case 79: {	// obj soc avail flags
			static const char *flags[] = {
				"available"
			};
			AsBits(flags, t);
			} return;
		}
		break;
	case 21:			// dest is object definition
		switch (d) {
		// case 39 - room sort - STR# 205
		// case 40 - function sort - STR# 206
		// case 66 - chair entry flags
		// case 76 - shadow flags
		// case 89 - rating skill flags
		// case 91 - misc flags
		// case 94 - function sub-sort
		// case 95 - downtown sort
		// case 97 - vacation sort
		// case 99 - community sort
		case 100: {	// dream flags
			static const char *flags[] = {
				"for dogs",
				"for cats"
			};
			AsBits(flags, t);
			} return;
		}
		// case 101 - render flags
		//	1 - alpha transparent
		break;
	}
	// print source location
	doExpOper(inst[11], s);
}

static void prim06(const unsigned char *inst)
{
	if (inst[5] > 3 || inst[6] > 1) {
		cout	<< "change article(" << int(inst[5])
			<< ", " << int(inst[6]) << ')';
		return;
	}
	cout	<< ((inst[6] == 0) ? "put on " : "take off ");
	switch (inst[5]) {	// STR# 227 suit locations
	case 0:		// global? (never used)
		cout << "global article " << int(inst[4]);
		break;
	case 1: {	// person, STR# 250 - outfits
		extern int BhavStr250Len;
		if (inst[4] < BhavStr250Len) {
			extern const char *BhavStr250[];
			cout << BhavStr250[inst[4]] << " outfit";
		} else {
			cout << "outfit[" << int(inst[4]) << ']';
		}
		} break;
	case 2: {	// object, in object's STR#304
		simIFF_strings outfit(EntryStream("STR#", 304));
		if (inst[4] < outfit.entries()) {
			cout << '"' << outfit[inst[4]].str1() << '"';
		} else {
			cout << "STR#[304," << int(inst[4]) << ']';
		}
		} break;
	case 3:		// object model? (never used)
		cout << "[HD] object model " << int(inst[4]);
		break;
		
	}
}

static void prim23(const unsigned char *inst)
{		// play sound
	if (inst[5] == 0xFF) { cout << "play sound"; return; }
	cout << "play(" << int(inst[7]) << ") ";
	int t = Oper(inst+4);
	simIFF_FWAV fwav(EntryStream("FWAV", t));
	if (fwav.err()) {
		cout << "FWAV[" << t << ']';
	} else {
		cout << '"' << fwav.fwav() << '"';
	}
//	switch (inst[7]) {
//	case 0:	cout << " from me"; break;
//	case 1:	cout << " from stack obj"; break;
//	default:cout << " from SRC" << int(inst[7]); break;
//	}
//	cout << " (" << int(inst[8]) << ", " << int(inst[9]) << ')';
	cout << " from " << (((inst[8]&0x02) != 0) ? "stack obj" : "me");
	if ((inst[8]&0x01) != 0) cout << " looped";
	if ((inst[8]&0x04) != 0) cout << " no-zoom";
	if ((inst[8]&0x08) != 0) cout << " no-pan";
	if ((inst[8]&0x10) != 0) cout << " auto-vary";
	if (inst[9] != 0) cout << " volume=" << int(inst[9]);
}

static void prim24which(iffDecode &p)
{
	if ((p[8]&0x02) != 0) *p.out << "neighbor ";
	extern const char *BhavStr170[];
	*p.out << "rel[" << int(p[5]) << "] of " << BhavStr170[p[7]];
}
static void prim24(iffDecode &p)
{
	extern int BhavStr170Len;	// rel. var me/stack obj
	if (p[7] >= BhavStr170Len) {
		default_prim(p);
		return;
	} else if (p[4] == 0) {		// STR# 169 0/1 ==> get/set
		doExpOper(9, p[6]);
		cout << assignop;
		prim24which(p);
	} else {
		prim24which(p);
		cout << assignop;
		doExpOper(9, p[6]);
	}
	// STR# 171 0/1 ==> create/fail
	if ((p[8]&0x01) != 0) cout << ", no create";
	cout << " [DEPRECATED]";
}

static void prim26which(const unsigned char *inst)
{
	if ((inst[8]&0x02) != 0) cout << "neighbor ";
	cout << "rel[" << int(inst[4]) << "] of ";
	switch (inst[5]) {
	case 0: case 1: {
		extern const char *BhavStr235[];	// which relationship 2
		cout << BhavStr235[inst[5]];
		} break;
	case 2:	cout << "stack obj to ";
		doExpOper(25, inst[7]);
		break;
	case 3:	doExpOper(25, inst[7]);
		cout << " to stack obj";
		break;
	default: cout << "WHICH[" << int(inst[5]) << ']';
	}
}
static void prim26(const unsigned char *inst)
{
	if ((inst[6]&0x04) == 0) {	// STR# 169 0/1 ==> get/set
		doExpOper(inst[8], Oper(inst+10));
		cout << assignop;
		prim26which(inst);
	} else {
		prim26which(inst);
		cout << assignop;
		doExpOper(inst[8], Oper(inst+10));
	}
	// STR# 171 0/1 ==> create/fail
	if ((inst[6]&0x01) != 0) cout << ", no create";
}

static void prim36(const unsigned char *inst)
{
	// probably merged with primitives 38 and 39
	// dialog type STR#217, STR#218
	extern int BhavStr217Len;	// dialog types
	if (inst[9] < BhavStr217Len) {
		extern const char *BhavStr217[];
		cout << BhavStr217[inst[9]];
	} else {
		cout << "TYPE=" << int(inst[9]);
	}
	cout << " dialog";
	//
	// STR#237 dialog behavior (bitmap)
	if ((inst[11]&0x01) != 0) cout << " async";
	if ((inst[11]&0x80) != 0) cout << " continue";
	//
	// STR#244 icon type, shifted left one
	switch ((inst[11]&0x0E)>>1) {
	case 0:	cout << " auto-icon"; if (inst[5] == 0) goto no_icon; break;
	case 1: if (inst[5] == 0) goto no_icon; cout << " ICON"; break;
	case 2: cout << " neighbor-icon"; break;
	case 3: cout << " indexed-icon"; break;
	case 4: cout << " named-icon"; break;
	default: cout << " ICON[" << ((inst[11]&0x0E)>>1) << ']';
	}
	cout << '=' << int(inst[5]);
    no_icon:
	//
	// STR#301 is dialog prim string set
	if (inst[10] != 0) cout << " title=" << int(inst[10] - 1);
	if (inst[6] != 0) cout << " text=" << int(inst[6] - 1);
	if (inst[7] != 0) cout << " btn1=" << int(inst[7] - 1);
	if (inst[8] != 0) cout << " btn2=" << int(inst[8] - 1);
	if (inst[4] != 0) cout << " btn3=" << int(inst[4] - 1);
	//
	if ((inst[11]&0x70) != 0) cout << " GACK=" << ((inst[11]&0x70)>>4);
}

static void prim42(const unsigned char *inst)
{		// create object instance
	if (inst[8] == 255) {
		cout << "create object instance";
		return;
	}
	// TODO: untangle how to display create instance
	cout	<< "create ";
	if ((inst[9]&0x04) != 0) {
		cout	<< "neighbor";
	} else {
		cout	<< "0x" << hex << setiosflags(ios::uppercase)
			<< GUID(inst+4)
			<< dec << resetiosflags(ios::uppercase);
	}
	extern int BhavStr167Len;	// where to create the object
	if (inst[8] < BhavStr167Len) {
		extern const char *BhavStr167[];
		cout << ' ' << BhavStr167[inst[8]];
		if (inst[8] == 7) {
			doExpOper(9, 0);
		} else if (inst[8] == 8 || inst[8] == 9) {
			doExpOper(25, (signed char)inst[10]);
		}
	} else {
		cout << " WHERE=" << int(inst[8]);
	}
	// some of these are STR#168 (how to create the object)
	if ((inst[9]&0x01) != 0) cout << ", no dup";
	if ((inst[9]&0x08) != 0) cout << ", must be empty";
	if ((inst[9]&0x02) != 0) cout << ", pass my ID to main";
	else if ((inst[9]&0x10) != 0) cout << ", pass temp[0] to main";
	if ((inst[9]&0x20) != 0) cout << ", FLAG20";
	if ((inst[9]&0x40) != 0) cout << ", FLAG40";
}

static bool prim44str(const char *str)
{
	if (*str == '\0') return false;		// empty string
	// if the string begins with 'a2o-' (ignoring case), then strip it off
	if (	(str[0] == 'a' || str[0] == 'A') && str[1] == '2' &&
		(str[2] == 'o' || str[2] == 'O') && str[3] == '-')
	{
		str += 4;
	}
	cout << '"' << str << '"';
	return true;
}
static void prim44id(const unsigned char *inst)
{
	int id = Oper(inst+4);
	switch (inst[8]) {
	// case 0 selects name from immediate object
	// (all?) other cases select from Global.iff
	case 0: {	// STR# 129 (a2o) if adult, 130 (c2o) if child
		simIFF_strings adult(EntryStream("STR#", 129));
		if (id < adult.entries()) {
			if (prim44str(adult[id].str1())) return;
		}
		simIFF_strings child(EntryStream("STR#", 130));
		if (id < child.entries()) {
			if (prim44str(child[id].str1())) return;
		}
		cout << "object STR# 129/130";
		} break;
	case 1: {	// STR# 128, Animations
		extern int GlobalStr128Len;
		if (id < GlobalStr128Len) {
			extern const char *GlobalStr128[];
			if (prim44str(GlobalStr128[id])) return;
		}
		cout << "global STR# 128";
		} break;
	case 2: {	// STR# 130, PersonAnimations
		extern int GlobalStr130Len;
		if (id < GlobalStr130Len) {
			extern const char *GlobalStr130[];
			if (prim44str(GlobalStr130[id])) return;
		}
		cout << "global STR# 130";
		} break;
	case 3: {	// STR# 156, MiscAdult, or STR#157, MiscChild
		extern int GlobalStr156Len;
		if (id < GlobalStr156Len) {
			extern const char *GlobalStr156[];
			if (prim44str(GlobalStr156[id])) return;
		}
		cout << "global STR# 156/157";
		} break;
	default:
		cout << "FROM=" << int(inst[8]);
	}
	cout << " ID=" << Oper(inst+4);
}
static void prim44(const unsigned char *inst)
{		// animate
	if ((inst[9]&0x04) == 0 && Oper(inst+4) == 0) {
		cout << "reset animate";
		if ((inst[9]&0x01) != 0) cout << ", async";
		if ((inst[9]&0x10) != 0) cout << ", carry";
		if ((inst[9]&0x08) != 0) cout << ", FLAG08";	// never
		if ((inst[9]&0x20) != 0) cout << ", FLAG20";	// sometimes
		if ((inst[9]&0x40) != 0) cout << ", FLAG40";	// never
		return;
	}
	if ((inst[9]&0x20) == 0) {
		doExpOper(9, 0);
	} else {
		doExpOper(25, Oper(inst+6));
	}
	cout << assignop;
	cout << "animate ";
	if ((inst[9]&0x04) == 0) {
		prim44id(inst);
	} else {
		switch (inst[8]) {
		// case 0 selects name from immediate object
		case 0:	cout << "object STR# 129/130"; break;
		// other cases select from Global.iff
		// STR# 128, Animations
		case 1:	cout << "global STR# 128"; break;
		// STR# 130, PersonAnimations
		case 2:	cout << "global STR# 130"; break;
		// STR# 156, MiscAdult, or STR#157, MiscChild
		case 3:	cout << "global STR# 156/157"; break;
		default: cout << "FROM=" << int(inst[8]);
		}
		cout << " s.v. " << Oper(inst+4);
	}
	if ((inst[9]&0x02) != 0) cout << ", backward";
	switch (inst[9]&0x11) {
	case 0x01: cout << ", async"; break;
	case 0x10: cout << ", carry"; break;
	case 0x11: cout << ", stop std carry"; break;	// TvD ???
	}
	if (Oper(inst+10) != 0) cout << " FLD3=" << Oper(inst+10);
	if ((inst[9]&0x08) != 0) cout << ", FLAG08";
	if ((inst[9]&0x40) != 0) cout << ", FLAG40";
}

static void prim45(const unsigned char *inst)
{		// goto routing slot
	cout << "go to routing slot ";
	int u = Oper(inst+4);
	switch (Oper(inst+6)) {		// STR# 215, Routing slot param types
	case 0:	doExpOper(9, u); break;
	default: cout << "TYPE[" << int(Oper(inst+6)) << "]=";
		// fall through to ..
	case 1:	cout << short(u); break;
	case 2:	cout << "global " << short(u); break;
	}
	if ((u = Oper(inst+8)) != 0) cout << " OPT=" << u;
}

static void prim46(const unsigned char *inst)
{		// snap
	cout << "snap ";
	int flgs = Oper(inst+8);
	if ((flgs&0x04) != 0) cout << "via footprint ";
	switch (Oper(inst+6)) {
		//extern int BhavStr207Len;	// How To Snap
		extern const char *BhavStr207[];
	case 0:
		cout << "to slot number ";
		doExpOper(9, Oper(inst+4));
		break;
	case 1:	case 2:
		cout << BhavStr207[Oper(inst+6)];
		break;
	case 3: case 4:
		cout	<< "to " << BhavStr207[Oper(inst+6)]
			<< ' ' << Oper(inst+4);
		break;
	default:
		cout << "HOW[" << Oper(inst+6) << "]=" << Oper(inst+4);
	}
	if ((flgs&0x02) != 0) cout << ", shoo";
	if ((flgs&0x01) != 0) cout << ", FLAG01";
}

static void prim47(const unsigned char *inst)
{		// reach
	static char reach[] = { "reach to " };
	int flg = Oper(inst+6);
	switch (Oper(inst+4)) {		// STR#174 Where to reach
	case 0:
		cout	<< ((flg != 0) ? "pick up " : reach)
			<< "stack obj";
		break;
	case 1:
		cout	<< ((flg != 0) ? "drop onto " : reach)
			<< "stack obj's slot ";
		doExpOper(9, Oper(inst+8));
		break;
	case 2:
		// no samples; don't know if flag has effect
		cout << reach << "mouth, flag=" << flg;
		break;
	default:
		cout << "WHERE=" << Oper(inst+4);
	}
}

static void prim48(const unsigned char *inst)
{		// stop all sounds
	cout << "stop ";
	switch (Oper(inst+4)) {		// STR# 153, short owner list
	case 0:	cout << "my"; break;
	case 1:	cout << "stack obj's"; break;
	case 2:	cout << "target obj's"; break;
	default:cout << "all(" << short(Oper(inst+4)) << ')';
	}
	cout << " sounds";
}

static void prim50(const unsigned char *inst)
{		// select menu string
	cout << "menu string := ";
	int str = Oper(inst+4), id = Oper(inst+8) - 1;
	simIFF_strings menu(EntryStream("STR#", str));
	if (id < menu.entries()) {
		cout << '"' << menu[id].str1() << '"';
	} else {
		cout << "STR#[" << str << ", " << id << ']';
	}
}

static void prim51type(const unsigned char *inst)
{
	cout << ' ';
	switch (inst[5]) {
	case 0:	cout << "gift"; break;
	case 1:	cout << "date"; break;
	case 2:	cout << "simdata"; break;
	case 3:	cout << "date"; break;
	case 4:	cout << "purchase"; break;
	case 5:	cout << "souvenir"; break;
	case 6:	cout << "skill"; break;
	default: cout << "TOKEN=" << int(inst[5]); return;
	}
	cout << " token";
}
static void prim51(const unsigned char *inst)
{		// manage inventory
#if 0
	cout << "manage inventory[HD]";
#else
	//cout << "manage inventory[HD]: ";
	switch (inst[4]) {
	case 0: cout << "add"; prim51type(inst); break;
	case 1: cout << "remove"; prim51type(inst); break;
	case 2: cout << "remove token at index"; break;
	case 3: cout << "find"; prim51type(inst); break;
	case 4: cout << "next"; prim51type(inst); break;
	case 5: cout << "add downtown date token of neighbor ID in temp"; break;
	case 6: cout << "add backhome date token of neighbor ID in temp"; break;
	default: cout << "WHAT=" << int(inst[4]); prim51type(inst);
	}
	if ((inst[6]&0x01) != 0) {
		cout << " with object ";
		unsigned long guid =  GUID(inst+8);
		if (guid != 0) {
			cout	<< "0x" << hex << setiosflags(ios::uppercase)
				<< guid << dec << resetiosflags(ios::uppercase);
		} else {
			cout << "from stack obj's GUID";
		}
	}
#endif
}

static void decodePrim(iffDecode &p)
{
	unsigned int op = p.oper(0);		// operation code
	switch (op) {				// STR# 139 - Primitives
		unsigned int u;			// scratch
	default: default_prim(p); break;
	case  0:
		*p.out << "sleep ";
		doExpOper(9, p.oper(4));
		*p.out << " ticks";
		break;
	case  1: {	// generic sim call
		extern int BhavStr220Len;	// generic sim calls
		extern const char *BhavStr220[];
		int t = p.oper(4);
		if (t < BhavStr220Len) {
			*p.out << BhavStr220[t];
		} else {
			*p.out << "generic sim call " << t;
		}
		} break;
	case  2: prim02(p.inst); break;
	case  3: *p.out << "find best interaction"; break;
	case  4: *p.out << "grab stack obj"; break;
	case  5: *p.out << "drop stack obj"; break;
	case  6: prim06(p.inst); break;
	case  7: {	// update
		*p.out << "refresh ";
		extern int BhavStr153Len;	// update who
		if (p[4] < BhavStr153Len) {
			extern const char *BhavStr153[];
			*p.out << BhavStr153[p[4]];
		} else {
			*p.out << "WHO=" << int(p[4]);
		}
		*p.out << ' ';
		extern int BhavStr212Len;	// update what
		if (p[6] < BhavStr212Len) {
			extern const char *BhavStr212[];
			*p.out << BhavStr212[p[6]];
		} else {
			*p.out << "WHAT=" << int(p[6]);
		}
		} break;
	case  8:	// random
		doExpOper(p[6], p.oper(4));
		*p.out << " := random ";
		doExpOper(p[10], p.oper(8));
		break;
	case  9: {	// burn
		*p.out << "burn ";
		extern int BhavStr231Len;	// what to burn
		if (p[4] < BhavStr231Len) {
			extern const char *BhavStr231[];
			*p.out << BhavStr231[p[4]];
		} else {
			*p.out << "WHAT[" << int(p[4]) << ']';
		}
		if (p[5] != 0) *p.out << " even if busy";
		} break;
	case 10:	// tutorial
		// STR#238 - situation action descriptions
		*p.out << "tutorial " << ((p[4] == 0) ? "begin" : "end");
		break;
	case 11:	// distance
		doExpOper(8, p.oper(4));
		*p.out << " := distance from stack obj to ";
		u = p.oper(8);
		if (p[6] == 0) {
			*p.out << "me";
		} else if (p[7] == 3 && u == 11) {
			*p.out << "me";
		} else {
			doExpOper(p[7], u);
		}
		break;
	case 12:	// direction to
		doExpOper(p[6], p.oper(4));
		*p.out << " := direction from stack obj to ";
		u = p.oper(10);
		if (p[8] == 0) {
			*p.out << "me";
		} else if (p[9] == 3 && u == 11) {
			*p.out << "me";
		} else {
			doExpOper(p[9], u);
		}
		break;
	case 13: {	// push interaction
		*p.out << "queue ";
		*p.out << int(p[4]) << " of ";
		doExpOper(((p[7]&2) != 0) ? 25 : 9, p[5]);
		//*p.out << " into stack obj's queue,";
		extern int BhavStr224Len;	// priorities
		if (p[6] < BhavStr224Len) {
			extern const char *BhavStr224[];
			if (p[6] > 0) cout << " pri=" << BhavStr224[p[6]];
		} else {
			*p.out << " PRI=" << int(p[6]);
		}
		if ((p[7]&1) != 0) {
			*p.out << " icon=";
			doExpOper(25, p.oper(8));
		}
		if ((p[7]&0x04) != 0) *p.out << ", continue as current";
		if ((p[7]&0x08) != 0) *p.out << ", use name";
		} break;
	case 14: {	// find best object for ...
		u = p.oper(4);
		*p.out << "find best object for ";
		extern int BhavStr201Len;	// functions
		if (int(u) < BhavStr201Len) {
			extern const char *BhavStr201Obj[];
			*p.out << BhavStr201Obj[u];
		} else {
			*p.out << "function " << u;
		}
		// TODO -- what are these values?
		int	x = p.oper(6),
			y = p.oper(8),
			z = p.oper(10);
		if (x == 0 && y == 0 && z == 0) break;
		*p.out << " (" << x << ", " << y << ", " << z << ')';
		} break;
	case 15:	// tree break point
		*p.out << "tree break point";
		u = p.oper(4);
		if (p[6] != 7 || u == 0) {
			// condition not a literal true
			*p.out << " if ";
			doExpOper(p[6], u);
			*p.out << " != 0";
		}
		break;
	case 16: {	// find location for
		*p.out << "find ";
		if ((p[6]&2) != 0) *p.out << "empty ";
		extern int BhavStr239Len;	// find location behav.
		if (p[4] < BhavStr239Len) {
			extern const char *BhavStr239[];
			*p.out << BhavStr239[p[4]];
		} else {
			*p.out << "LOC=" << int(p[4]);
		}
		*p.out << " loc";
		if ((p[6]&1) != 0) {
			*p.out << " start at ";
			doExpOper(25, p[5]);
		}
		if ((p[6]&4) != 0) *p.out << " user-editable";
		} break;
	case 17:	// idle for input
		*p.out << "idle for input ";
		doExpOper(9, p.oper(4));
		u = p.oper(6);		// STR# 172 - interrupt
		*p.out	<< " ticks, "
			<< ((u == 0) ? "forbid" : "allow") << " push";
		break;
	case 18: {	// remove object instance
		*p.out << "remove ";
		int who = p.oper(4);
		extern int BhavStr153Len;	// kill object options
		if (who < BhavStr153Len) {
			extern const char *BhavStr153[];
			*p.out << BhavStr153[who];
		} else {
			*p.out << "object[" << who << "]'s";
		}
		*p.out << " instance";
		if ((p[6]&1) != 0) *p.out << ", return immed";
		if ((p[6]&2) != 0) *p.out << ", clean up all";
		} break;
	case 19:	// make new character
		*p.out << "make new character(";
		doExpOper(25, p[4]);
		*p.out << ',';
		doExpOper(25, p[5]);
		*p.out << ',';
		doExpOper(25, p[6]);
		*p.out << ')';
		break;
	case 20: {	// run functional tree		// STR#201
		int t = p.oper(4);
		*p.out << "run ";
		extern int BhavStr201Len;	// functions
		if (t < BhavStr201Len) {
			extern const char *BhavStr201Run[];
			*p.out << '"' << BhavStr201Run[t] << '"';
		} else {
			*p.out << "function " << t;
		}
		t = short(p.oper(6));
		if (t != 0) *p.out << " with new icon";
		} break;
	case 21:	// show string
		// TODO print actual string
		*p.out	<< "show STR#[" << (p.oper(4))
			<< ", " << ((p.oper(6)) - 1) << ']';
		break;
	case 22: {	// look towards
		int how = p.oper(4);
		extern int BhavStr216Len;	// how to look towards
		if (how < BhavStr216Len) {
			extern const char *BhavStr216[];
			*p.out << BhavStr216[how];
		} else {
			*p.out << "look towards(" << how << ')';
		}
		} break;
	case 23: prim23(p.inst); break;
	case 24: prim24(p); break;
	case 25: {	// alter budget
		switch (p[8]) {
		case 0:	*p.out << "deduct "; break;
		case 1:	*p.out << "can deduct "; break;
		case 2:	*p.out << "add "; break;
		case 3:	*p.out << "can add "; break;
		default: *p.out << "BUDGET[" << int(p[8]) << "] ";
		}
		// select data owner (STR# 173 spend ref.)
		switch (p[4]) {
		case 0:	u = 7; break;	// literal amount
		case 1:	u = 9; break;	// param
		case 2:	u = 25; break;	// local
		default: u = p[5];	// why wasn't this always used?
		}
		doExpOper(u, p.oper(6));
		extern int BhavStr240Len;	// expense types
		if (p[10] < BhavStr240Len) {
			extern const char *BhavStr240[];
			*p.out << " as " << BhavStr240[p[10]];
		} else {
			*p.out << " as EXPENSE[" << int(p[10]) << ']';
		}
		if (p[11] != 0) *p.out << " (" << int(p[11]) << ')';
		} break;
	case 26: prim26(p.inst); break;
	case 27: {	// goto relative position
		*p.out << "go ";
		extern int BhavStr130Len;	// relative locations
		int t = (signed char)p[6] + 2;
		if (t < BhavStr130Len) {
			extern const char *BhavStr130[];
			*p.out << BhavStr130[t];
		} else {
			*p.out << "LOC=" << t;
		}
		*p.out << ", ";
		extern int BhavStr131Len;	// relative directions
		t = (signed char)p[7] + 2;
		if (t < BhavStr131Len) {
			extern const char *BhavStr131[];
			*p.out << BhavStr131[t];
		} else {
			*p.out << "DIR=" << t;
		}
		if ((p[10]&0x02) != 0) *p.out << ", no failure trees";
		// TODO: figure out options for goto relative
		if ((p[10]&0x01) != 0) *p.out << ", OPT1";
		if ((p[10]&0x04) != 0) *p.out << ", OPT4";
		if ((t = p.oper(4)) != 0) *p.out << ", OPTa=" << t;
		if ((t = p.oper(8)) != 0) *p.out << ", OPTb=" << t;
		} break;
	case 28:	// run named tree
		// STR#222 - how to call named tree
		switch (p[9]) {
		case 0: case 1:
			*p.out << "run"; break;
		case 2:	*p.out << "push"; break;
		default: *p.out << "HOW" << u;
		}
		switch (u = p.oper(6)) {
		case 0:	*p.out << " local"; break;
		case 1:	*p.out << " global"; break;
		default: *p.out << " LOC" << u;
		}
		// TODO - include strings from these resources
		*p.out	<< " STR#[" << (p.oper(4))
			<< ", " << int(p[8] - 1) << "] ";
		switch (p[9]) {
		case 0: case 2:
			*p.out << "in my stack"; break;
		case 1:	*p.out << "in stack obj's stack"; break;
		default: *p.out << "WHERE" << u;
		}
		break;
	case 29: {	// set motive delta
		if (p[7] != 0) {
			*p.out << "reset all motive deltas";
			break;
		}
		doExpOper(14, p[6]);
		*p.out << " += ";
		doExpOper(p[4], p.oper(8));
		*p.out << " per hr limit ";
		doExpOper(p[5], p.oper(10));
		} break;
	//case 30: *p.out << "gosub found action"; break;
	case 31: {	// set to next			// STR#164?
		doExpOper(((p[8]&0x80) != 0) ? p[9] : 10, p[11]);
		*p.out << " := next ";
		extern const char *BhavStr164[];
		extern int BhavStr164Len;
		int t = p[8]&127;
		if (t < BhavStr164Len) {
			*p.out << BhavStr164[t];
		} else {
			*p.out << "BAD CODE " << t;
		}
		switch (t) {
		case 4: case 7:
			*p.out << " 0x" << hex << setiosflags(ios::uppercase)
				<< GUID(p.inst+4)
				<< dec << resetiosflags(ios::uppercase);
			break;
		case 9:
			doExpOper(25, p[10]);
		}
		} break;
	case 32:	// test object type
		doExpOper(p[10], p.oper(8));
		*p.out	<< " == obj type 0x"
			<< hex << setiosflags(ios::uppercase)
			<< GUID(p.inst+4)
			<< dec << resetiosflags(ios::uppercase);
		break;
	case 33: {	// find 5 worst motives
		//*p.out << "find 5 worst motives";
		*p.out << "find ";
		extern const char *BhavStr153[];
		extern int BhavStr153Len;
		int t = p.oper(4);
		if (t < BhavStr153Len) {
			*p.out << BhavStr153[t];
		} else {
			*p.out << "WHO=" << t;
		}
		*p.out << " five worst ";
		extern const char *BhavStr165[];
		extern int BhavStr165Len;
		t = p.oper(4);
		if (t < BhavStr165Len) {
			*p.out << BhavStr165[t];
		} else {
			*p.out << "WHAT=" << t;
		}
		} break;
	case 34: {	// UI effect
		*p.out << ((p[8] != 0) ? "start" : "stop") << ' ';
		extern const char *BhavStr247[];
		extern int BhavStr247Len;
		if (p[4] < BhavStr247Len) {
			*p.out << BhavStr247[p[4]];
		} else {
			*p.out << "EFFECT=" << int(p[4]);
		}
		*p.out << ' ';
		doExpOper(p[5], p.oper(6));
		} break;
	case 35: {
		//*p.out << "user event: ";
		// TODO validate these options, shrink width
		if ((p[8]&0x01) == 0) {
			*p.out << "un-show stack obj";
			break;
		}
		int t = p.oper(4);
		*p.out << "show stack obj, timeout=";
		if ((p[8]&0x20) == 0) {
			*p.out << t;
		} else {
			doExpOper(25, t);
		}
		if (p[9] != 0) {
			*p.out << ", label STR#[305," << (p[9] - 1) << ']';
		}
		*p.out << (((p[8]&0x02) == 0) ? ", one frame" : ", live");
		if ((p[8]&0x04) != 0) *p.out << ", ignore visibility";
		if ((p[8]&0x10) != 0) *p.out << ", snapshot";
		switch (p[7]) {
		case 0:	*p.out << ", near"; break;
		case 1:	*p.out << ", mid"; break;
		case 2:	*p.out << ", far"; break;
		default: *p.out << ", DIST=" << int(p[7]);
		}
		*p.out << " zoom, ";
		if ((p[8]&0x08) != 0) *p.out << "centered ";
		switch (p[6]) {
		case 0:	*p.out << "small"; break;
		case 1:	*p.out << "medium"; break;
		case 2:	*p.out << "large"; break;
		default: *p.out << "SIZE=" << int(p[6]);
		}
		*p.out << " window";
		if ((p[8]&0x40) != 0) *p.out << ", slow down";
		} break;
	case 36: prim36(p.inst); break;
	//case 37: *p.out << "test interacting with"; break;
//	case 38: *p.out << "~UNUSED 38"; break;	// "dialog - global strings"
//	case 39: *p.out << "~UNUSED 39"; break;	// "dialog - semi-global strings"
//	case 40: *p.out << "~UNUSED 40"; break;
	case 41: {	// set balloon/headline
		int t = short(p.oper(8));
		if (t == 0) {
			*p.out << "clear balloon/headline";
			break;
		}
		// STR# 160 - set headline 2
		*p.out	<< (((p[4]&0x01) == 0) ? "my" : "stack obj's")
			<< ' ';
		extern int BhavStr162Len;	// balloon types
		if (p[10] < BhavStr162Len) {
			extern const char *BhavStr162[];
			*p.out << BhavStr162[p[10]];
		} else {
			*p.out << "TYPE=" << int(p[10]);
		}
		*p.out << assignop;
		const char **BhavStr;
		int BhavStrLen, BhavStrID;
		switch (p[7]) {		// STR# 500 - icon group labels
#define IconStr(n) {	extern const char *BhavStr##n[]; \
			extern int BhavStr##n##Len; \
			BhavStr = BhavStr##n; \
			BhavStrLen = BhavStr##n##Len; \
			BhavStrID = n; }
		// TODO -- where does STR# 161 fit?
		case 0: IconStr(502); break;	// old style
		case 1: IconStr(505); break;	// balloon
		case 2: IconStr(501); break;	// conversation
		case 3: IconStr(502); break;	// motive
		case 4: IconStr(503); break;	// relationship
		case 5: IconStr(504); break;	// headline
		case 6: IconStr(506); break;	// relationship/social/debug
		case 7: IconStr(507); break;	// algorithmic
		case 8: IconStr(508); break;	// route failure
		case 9: IconStr(509); break;	// progress
#undef IconStr
		default: BhavStr = 0; BhavStrLen = 0; BhavStrID = p[7];
		}
		if (p[6] < BhavStrLen) {
			*p.out << BhavStr[p[6]];
			if (p[7] == 7 && p[6] == 2) {
				doExpOper(25, p[4]>>1);
			}
		} else {
			*p.out	<< "GROUP " << int(p[7])
				<< " ICON " << int(p[6]);
		}
		if ((p[11]&0x10) != 0) {
			// TODO -- how is temp[0] included?
			*p.out << " + "; doExpOper(8,0);
		}
		if (t < 0) {
			*p.out << " forever";
		} else {
			*p.out	<< " for " << t << ' '
				<< (((p[11]&0x08) == 0) ? "ticks" : "loops");
		}
		// TODO verify these flags, may be STR# 159 or 163
		if ((p[11]&0x01) != 0) *p.out << ", show when inactive";
		if ((p[11]&0x02) != 0) *p.out << ", crossed out";
		if ((p[11]&0x04) != 0) *p.out << ", anim reversed";
		} break;
	case 42: prim42(p.inst); break;
	case 43:	// drop onto
		*p.out << "drop slot ";
		if ((p.oper(4)) == 0) {
			*p.out << (p.oper(6));
		} else {
			doExpOper(9, p.oper(6));
		}
		*p.out << " onto slot ";
		if ((p.oper(8)) == 0) {
			*p.out << (p.oper(10));
		} else {
			doExpOper(9, p.oper(10));
		}
		break;
	case 44: prim44(p.inst); break;
	case 45: prim45(p.inst); break;
	case 46: prim46(p.inst); break;
	case 47: prim47(p.inst); break;
	case 48: prim48(p.inst); break;
	case 49:
		*p.out << "notify stack object";
		break;
	case 50: prim50(p.inst); break;
	case 51: prim51(p.inst); break;
	//case 52: *p.out << "change light color[HD]"; break;
	//case 53: *p.out << "change sun color[HD]"; break;
	//case 54: *p.out << "point light at object[HD]"; break;
	//case 55: *p.out << "sync field[TSO]"; break;
	//case 56: *p.out << "ownership[TSO]"; break;
	//case 57: *p.out << "start persistant dialog[TSO]"; break;
	//case 58: *p.out << "end persistant dialog[TSO]"; break;
	//case 59: *p.out << "update persistant dialog[TSO]"; break;
	//case 60: *p.out << "poll persistant dialog[TSO]"; break;
//	case 61: *p.out << "UNUSED[TSO]"; break;
	//case 62: *p.out << "invoke plugin[TSO]"; break;
	//case 63: *p.out << "get terrain info[TSO]"; break;
	}
}
// allow debugging code to intercept when decoding primitive
void (*doPrimitive)(iffDecode &p) = decodePrim;

static void decodeInst(iffDecode &p)
{
	unsigned int k = p.oper(0);		// operation code
	if (k < 256) {
		doPrimitive(p);
		return;
	}
	extern int GlobalSubsLen;	// global subroutines
	extern const char *GlobalSubs[];
	const char *name = EntryName("BHAV", k);
	if (*name != '\0') {
		*p.out << name;
	} else if (k < unsigned(GlobalSubsLen + 256)) {
		*p.out << GlobalSubs[k-256];
	} else if (k < 4096) {
		*p.out << "Call global[" << k << ']';
	} else if (k < 8192) {
		*p.out << "Call local[" << k << ']';
	} else {
		*p.out << "Call semi-global[" << k << ']';
	}
	if (p.oper(4) == 0xFFFF && p.oper(6) == 0xFFFF &&
	    p.oper(8) == 0xFFFF && p.oper(10) == 0xFFFF)
	{
		*p.out	<< "(temps)";
	} else {
		*p.out	<< '(' << short(p.oper(4))
			<< ", " << short(p.oper(6))
			<< ", " << short(p.oper(8))
			<< ", " << short(p.oper(10))
			<< ')';
	}
}

simIFF_BHAV_analyze::simIFF_BHAV_analyze(simIFF_BHAV &p_bhav)
:	m_bhav(p_bhav), m_blocks(0), m_myfile(0), m_semiglobal(0)
{
	if (m_bhav.err()) return;
	m_blocks = new Block[m_bhav.count()];
	for (int i = 0; i < m_bhav.count(); ++i) {
		Block &b = m_blocks[i];
		b.m_flow = i + 1;
		b.m_loc = i;
		b.m_type = flow_orphan;
		b.m_pop = 0;
	}
	m_blocks[m_bhav.count() - 1].m_flow = 0;
}

void simIFF_BHAV_analyze::show(const unsigned char *inst, int dest1, int dest2)
{
	if (dest1 < 0) dest1 = inst[2];
	if (dest2 < 0) dest2 = inst[3];
	cout	<< hex << setfill('0') << setiosflags(ios::uppercase)
		<< setw(4) << int((inst[1]<<8)|inst[0])
		<< ' ' << setw(2) << dest1
		<< ' ' << setw(2) << dest2
		<< ' ' << setw(4) << int(Oper(inst+4))
		<< ' ' << setw(4) << int(Oper(inst+6))
		<< ' ' << setw(4) << int(Oper(inst+8))
		<< ' ' << setw(4) << int(Oper(inst+10))
		<< resetiosflags(ios::uppercase) << setfill(' ') << dec;
}

void simIFF_BHAV_analyze::show(int ix)
{
	int dest1 = m_bhav.inst(ix)[2], dest2 = m_bhav.inst(ix)[3];
	if (dest1 < m_bhav.count()) dest1 = m_blocks[dest1].m_loc;
	if (dest2 < m_bhav.count()) dest2 = m_blocks[dest2].m_loc;
	cout	<< hex << setfill('0') << setiosflags(ios::uppercase)
		<< setw(2) << int(m_blocks[ix].m_loc) << ": ";
	show(m_bhav.inst(ix), dest1, dest2);
}

void simIFF_BHAV_analyze::decode(int ix)
{
	iff = m_myfile;		// TEMP
	iffDecode p;
	p.inst = m_bhav.inst(ix);
	p.out = &cout;
	p.iff = m_myfile;
	decodeInst(p);
}

void simIFF_BHAV_analyze::resequence(void)
{
	int here = 0, ix = 0;
	do {
		m_blocks[here].m_loc = ix++;
	} while ((here = m_blocks[here].m_flow) != 0);
}

struct display_utilities : public iffDecode {
	int indent;
	simIFF_BHAV_analyze::Block *blocks;
	inline display_utilities(simIFF_BHAV_analyze::Block *b)
	:	indent(0), blocks(b)
	{}
	inline void tab_over(void)
	{
		*out << endl;
		// same width as raw instruction
		int spaces = 5*indent + 38;
		for (int i = 0; i < spaces; ++i) *out << ' ';
	}
	inline void go(int which)
	{
		switch (which) {
		case 0xFE:	*out << "return true"; break;
		case 0xFF:	*out << "return false"; break;
		case 0xFD:	*out << "return ERROR"; break;
		default:	*out << "go to " << int(blocks[which].m_loc);
				break;
		}
	}
	inline void exit_label(int which)
	{
		switch (which) {
		case 0xFE:	*out << "return true"; break;
		case 0xFF:	*out << "return false"; break;
		case 0xFD:	*out << "return ERROR"; break;
		default:	*out << "goto BAD " << which; break;
		}
	}
	inline void exit_common(int which)
	{
		tab_over();
		*out << "then "; exit_label(which);
	}
	inline void flow_next(int here, int which)
	{
		if (blocks[here].m_flow != which) {
			tab_over();
			go(which);
		}
	}
};

void simIFF_BHAV_analyze::display(void)
{
	iff = m_myfile;		// TEMP
	display_utilities u(m_blocks);
	u.iff = m_myfile,  u.out = &cout;
	//
	int here = 0, orphans = 0;
	enum marks { mark_nada, mark_then, mark_else } mark = mark_nada;
	do {
		u.inst = m_bhav.inst(here);
		//flows flow = flows((m_blocks[here].m_type>>4)&0x7);
		flows flow = flows(m_blocks[here].m_type&0x3F);
		if (orphans == 0 && flow == flow_orphan) {
			*u.out << "\t\t\tDEAD CODE FOLLOWS" << endl;
			orphans = 1;
		}
		*u.out << "  "; show(m_blocks[here].m_loc); *u.out << ' ';
		{	int spaces = u.indent*5;
			if ((m_blocks[here].m_type&0x80) != 0) {
				int label = m_blocks[here].m_loc;
				if (label < 10) spaces -= 2;
				else if (label < 100) spaces -= 3;
				else spaces -= 4;
				*u.out << label << ':';
			}
			for (int i = 0; i < spaces; ++i) *u.out << ' ';
		}
		*u.out << ' ';
		if (mark != mark_nada) {
			*u.out << ((mark == mark_then) ? "then " : "else ");
			++u.indent;
			mark = mark_nada;
		}
		enum my_flows {
			do_normal, do_unknown, do_both_exit,
			do_true_exits, do_false_exits
		} type = do_normal;
		int go_true = m_bhav.inst(here)[2];
		int go_false = m_bhav.inst(here)[3];
		int go_next = m_blocks[here].m_flow;
		int has_then = 0;
		switch (flow) {
		case flow_orphan:
#if DebugPrint
			*u.out << "DEAD ";
			// fall through to...
#endif // DebugPrint
		case flow_unknown:
			type = do_unknown;
			break;
		case flow_then:
			has_then = 1;	// suppress false
			mark = mark_then;
			break;
		case flow_else:
			has_then = 1;	// suppress true
			mark = mark_then;
			break;
		case flow_else_t:
			// suppress true branch (and possibly false)
			if (go_true == go_false) go_false = go_next;
			go_true = go_next;
			mark = mark_else;
			break;
		case flow_else_f:
			// suppress false branch
			go_false = go_next;
			mark = mark_else;
			break;
		case flow_else_x:
			mark = mark_else;
			break;
		default:
			if (go_true >= m_bhav.count()) {
				if (go_false >= m_bhav.count()) {
					type = do_both_exit;
					break;
				}
				//type = do_true_exits;
			} else if (go_false >= m_bhav.count()) {
				type = do_false_exits;
			}
			break;
		}
		switch (type) {
		case do_unknown:
			decodeInst(u);
			break;
		case do_both_exit:
			if (go_true == go_false) {
				decodeInst(u);
				u.tab_over();
				u.exit_label(go_true);
				break;
			}
			if (go_true == 0xFE) {
				if (go_false == 0xFF) {
					*u.out << "return ";
					decodeInst(u);
					break;
				}
				if (go_false == 0xFD) {
					decodeInst(u);
					u.tab_over();
					u.exit_label(go_true);
					break;
				}
			} else if (go_true == 0xFF) {
				if (go_false == 0xFE) {
					*u.out << "return ! ";
					decodeInst(u);
					break;
				}
				if (go_false == 0xFD) {
					decodeInst(u);
					u.tab_over();
					u.exit_label(go_true);
					break;
				}
			}
			*u.out << "if ";
			decodeInst(u);
			u.tab_over();
			*u.out << "then "; u.exit_label(go_true);
			u.tab_over();
			u.exit_label(go_false);
			break;
		case do_true_exits:
			*u.out << "if ";
			decodeInst(u);
			u.exit_common(go_true);
			u.flow_next(here, go_false);
			break;
		case do_false_exits:
			if (go_false == 0xFD) {
				decodeInst(u);
			} else {
				*u.out << "if ! ";
				decodeInst(u);
				u.exit_common(go_false);
			}
			u.flow_next(here, go_true);
			break;
		case do_normal:
			if (go_true == go_false) {
				decodeInst(u);
				u.flow_next(here, go_true);
			} else if (go_true == go_next) {
				if (has_then) {
					*u.out << "if "; decodeInst(u);
				} else if (go_false == go_next) {
					decodeInst(u);
				} else if (go_false == 0xFD) {
					decodeInst(u);
				} else {
					*u.out << "if ! "; decodeInst(u);
					u.tab_over();
					*u.out << "then "; u.go(go_false);
				}
			} else if (go_false == go_next && has_then) {
				*u.out << "if ! "; decodeInst(u);
			} else {
				*u.out << "if "; decodeInst(u);
				u.tab_over();
				*u.out << "then "; u.go(go_true);
				if (go_false != 0xFD) {
					u.flow_next(here, go_false);
				}
			}
			break;
		}
		if (mark == mark_else) --u.indent;
		//u.indent -= m_blocks[here].m_type&15;
		u.indent -= m_blocks[here].m_pop;
#if DebugPrint
{ if (m_blocks[here].m_pop > 7) *u.out << endl << "LOOK: POP OF " << int(m_blocks[here].m_pop); }
#endif // DebugPrint
		*u.out << endl;
	} while ((here = m_blocks[here].m_flow) != 0);
}

void simIFF_BHAV_analyze::set_file(simIFF *iff)
{
	m_myfile = iff;
	// TODO: maybe check for errors...
}

void simIFF_BHAV_analyze::set_semiglobal(simIFF *iff)
{
	m_semiglobal = iff;
	// TODO: maybe check for errors...
}

simIFF_BHAV_analyze::~simIFF_BHAV_analyze(void)
{
	delete[] m_blocks;
	delete m_myfile;
	delete m_semiglobal;
}

struct analBlock
{
	typedef unsigned char Ref;
	enum flows {
		flow_unknown		= simIFF_BHAV_analyze::flow_unknown,
		flow_orphan		= simIFF_BHAV_analyze::flow_orphan,
		flow_normal		= simIFF_BHAV_analyze::flow_normal,
		flow_then		= simIFF_BHAV_analyze::flow_then,
		flow_else		= simIFF_BHAV_analyze::flow_else,
		flow_else_t		= simIFF_BHAV_analyze::flow_else_t,
		flow_else_f		= simIFF_BHAV_analyze::flow_else_f,
		flow_else_x		= simIFF_BHAV_analyze::flow_else_x,
		};
	simIFF_BHAV_analyze::Block *m_block;
	analBlock *m_prev, *m_next;	// linked list of blocks
	analBlock *m_norm, *m_alt;	// normal and alternate flow
	analBlock *m_flow;		// next instruction in block
	analBlock *m_then;		// true fiow, if any
	analBlock *m_else;		// false fiow, if any
	analBlock *m_succ;		// successor fiow, if any
	analBlock *m_last;		// last instruction in block
	Ref m_true, m_false;		// normal and alternate flow
	Ref m_refs;			// references to lead instruction
	Ref m_resolved;			// resolved references
	Ref m_len;			// instruction count
	Ref m_height;			// max internal indents
	Ref m_depth;			// loop nesting depth
	Ref m_color;			// graph "color" for dominance
	Ref m_flags;			// various flags
	enum flags {	visited,	// marker to show previous visit
			labeled,	// unresolved entries that don't flow
			loop_head,	// label has back references
			comb,		// could be combined in a comb
			};
	//
	analBlock(void); ~analBlock(void);
	void setFlag(flags f)		{ m_flags |= 1<<f; }
	void clrFlag(flags f)		{ m_flags &= ~(1<<f); }
	bool isFlag(flags f)		{ return (m_flags & (1<<f)) != 0; }
	void setVisited(void)		{ setFlag(visited); }
	void clrVisited(void)		{ clrFlag(visited); }
	bool isVisited(void)		{ return isFlag(visited); }
	void setLabel(void)		{ setFlag(labeled); }
	void clrLabel(void)		{ clrFlag(labeled); }
	bool isLabeled(void)		{ return isFlag(labeled); }
	void setLoop(void)		{ setFlag(loop_head); }
	void clrLoop(void)		{ clrFlag(loop_head); }
	bool isLoop(void)		{ return isFlag(loop_head); }
	void setComb(void)		{ setFlag(comb); }
	void clrComb(void)		{ clrFlag(comb); }
	bool isComb(void)		{ return isFlag(comb); }
	void ref(void)			{ ++m_refs; }
	int refs(void)			{ return m_refs - m_resolved; }
	void resolve(void)		{ ++m_resolved; }
	void label(void)		{ resolve(), setLabel(); }
	void looper(void)		{ label(), setLoop(); }
	//Ref m_type, m_pop;
	void type(flows flow)		{ m_block->m_type = flow; }
	flows type(void)		{ return (flows)m_block->m_type; }
	void pop(void)			{ ++m_block->m_pop; }
	void higher(void)		{ ++m_height; }
	int out(void)			{ return (m_norm != 0) + (m_alt != 0); }
	//int out(void);
	void remove(void);		// remove ourselves from block list
	void merge(analBlock *p);	// merge with this block
	void add_succ(analBlock *p);	// add this block as successor
	void basic_block();		// collect basic block
	void loop_dominance(void);	// resolve loops, at least partially
	int shape_up(void);		// hammer child into shape
	int can_pull_up(analBlock *p, analBlock *q);
	void one_arm_pullup(analBlock *p, analBlock *q, flows flow);
	int block_flow(void);		// simple flow accumulation
	void snuggle_up(void);		// pull in all referenced blocks
};

analBlock::analBlock(void)
{
	m_norm = 0, m_alt = 0;
	m_flow = 0;
	m_last = this;
	m_then = 0, m_else = 0, m_succ = 0;
	m_refs = 0;
	m_resolved = 0;
	m_len = 1;
	m_height = 0;
	m_flags = 0;
}

inline void analBlock::remove(void)
{
	if (m_prev != 0) m_prev->m_next = m_next;
	if (m_next != 0) m_next->m_prev = m_prev;
	m_prev = 0, m_next = 0;		// just in case
}

inline void analBlock::merge(analBlock *p)
{
	// add subject block to this one
// { static int x; if (++x > 30) exit(-1); }
// { cout << "at " << int(m_block->m_loc) << '/' << int(m_last->m_block->m_loc) << '=' << int(m_len) << " add " << int(p->m_block->m_loc) << '=' << int(p->m_len) << endl; }
	p->remove();
	// add its list to ours
	m_last->m_flow = p;
	m_last = p->m_last;
	m_len += p->m_len;
	if (m_height < p->m_height) m_height = p->m_height;
	// by default, can no longer be a comb
	clrComb();
}

inline void analBlock::add_succ(analBlock *p)
{
	p->remove();
	analBlock *q = this;
	while (q->m_succ != 0) q = m_succ;
	q->m_succ = p;
}

#if 0
inline int analBlock::out(void)
{
	int result = 0;
	if (m_norm != 0) ++result;
	if (m_alt != 0) ++result;
	return result;
}
#endif

analBlock::~analBlock(void)
{
}

#define DebugVisitFlow 0	// track entrances and exits
#define DebugBackTrace 0	// track backtrace
class visitor
{
	analBlock &m_me;
	#if DebugBackTrace
	visitor *m_parent;
	static visitor *m_current;
	#endif	// DebugBackTrace
public:
	visitor(analBlock *me); ~visitor(void);
	#if DebugBackTrace
	void printStack(void);
	#endif	// DebugBackTrace
};
inline visitor::visitor(analBlock *me)
:	m_me(*me)
{
	m_me.setVisited();
	#if DebugVisitFlow
		static int xx = 0;
		if (++xx > 30) exit(-1);
		cout << "visiting " << int(m_me.m_block->m_loc) << endl;
	#endif  // DebugVisitFlow
	#if DebugBackTrace
		m_parent = m_current, m_current = this;
	#endif  // DebugBackTrace
}
inline visitor::~visitor(void)
{
	m_me.clrVisited();
	#if DebugVisitFlow
		cout << "leaving " << int(m_me.m_block->m_loc) << endl;
	#endif  // DebugVisitFlow
	#if DebugBackTrace
		m_current = m_parent;
	#endif  // DebugBackTrace
}
#if DebugBackTrace
visitor *visitor::m_current = 0;
void visitor::printStack(void)
{
	if (m_parent != 0) {
		m_parent->printStack();
		cout << ' ';
	}
	cout << int(m_me.m_block->m_loc);
}
#endif	// DebugBackTrace

// do a tree walk and mark all reachable instructions
//
static void visit(analBlock *p)
{
	if (p->type() == analBlock::flow_unknown) return; // already been here
	p->type(analBlock::flow_unknown);
	if (p->m_norm != 0) visit(p->m_norm);
	if (p->m_alt != 0) visit(p->m_alt);
}
// cull out orphans and form the linked list of blocks to analyze
//
static inline analBlock *find_orphans(analBlock *block, int count)
{
	visit(block);
	block[0].m_prev = 0;
	analBlock *prev = block, *orphans = 0, **o = &orphans;
	for (int i = 1; i < count; ++i) {
		analBlock &t = block[i];
		if (t.type() == analBlock::flow_unknown) {
			// it's reachable; add to list to analyze
			(t.m_prev = prev)->m_next = (prev = &t);
			t.clrVisited();
		} else {
			// it's not reachable; add to list of orphans
			*o = &t, o = &t.m_flow;
			t.m_prev = 0, t.m_next = 0;
		}
	}
	prev->m_next = 0;
	return orphans;
}

// A basic block is a sequence of instructions that has no internal
// branches.  That is, it is entered at the first instruction and always
// flows to the last one (modulo exits).  It reduces the work that flow
// analysis has to do by grouping instructions into larger units.
//
void analBlock::basic_block(void)
{
	if (type() != flow_unknown) return;	// we've already been here
	//
	// Preliminary instruction analysis
	// Instructions are categorized into zero-out (both flows exit),
	// two-out (both flows go different places), and single-out.  For
	// single-out, we try to extend the basic block to the next element.
	// As a side-effect, the normal exit is made the single exit.
	//
	type(flow_normal);		// for now...
	if (m_norm == 0) return;	// zero-out
	if (m_alt != 0) return;		// two-out
	//
	// If we have a single-out loop to ourself,
	// there's nothing we can do about it here
	if (m_norm == this) return;
	//
	// If we are a single-out and next block is single-in,
	// we can pull it up into this block
	if (m_norm->refs() != 1) return;
	//
	// next block has one reference and we are it
	// see if can successor pull up more
	m_norm->basic_block();
	//
	merge(m_norm);
	m_alt = m_norm->m_alt;
	m_norm = m_norm->m_norm;
}

// If all paths to a block flow through another block, the latter block is
// said to dominate the former.  To find out if a branch is part of a loop,
// the branch destination must dominate the source block.  The idea here is
// to see if we can reach the source block without going through the branch
// destination.  If we can't find such a path, then it must be a backward
// branch and we can resolve it.
//
// Yes, there are more efficient ways to calculate dominance, but the typical
// routine we're analyzing rarely has more than a couple of dozen blocks, so
// this quick-and-dirty graph-coloring implementation is adequate.
//
enum { no_color, no_path, dominates, direct };
int is_dom(analBlock *me, analBlock *branch, analBlock *block)
{
	if (me->m_color != no_color) return me->m_color; // already colored
	if (me->isVisited()) return no_path;	// no path this way
	if (me == branch) return dominates;	// dominates if via branch
	if (me == block) return direct;		// direct if via block
	visitor dummy(me);
	#if DebugBackTrace
	{ dummy.printStack(); cout << endl; }
	#endif  // DebugBackTrace
	int t = no_path;	// assume no path
	if (me->m_alt != 0) {
		if ((t = is_dom(me->m_alt, branch, block)) == direct) {
			// direct sub-path to block, report back
			return me->m_color = direct;
		}
	}
	if (me->m_norm == 0) return t;
	return me->m_color = is_dom(me->m_norm, branch, block);
}
int do_dom(analBlock *me, analBlock *branch, analBlock *block)
{
	// reset graph color before doing algorithm
	for (analBlock *p = me; p != 0; p = p->m_next) p->m_color = no_color;
	return is_dom(me, branch, block);
}
void analBlock::loop_dominance(void)
{
// cout << "sigh" << endl; // return
	for (analBlock *p = this; p != 0; p = p->m_next) {
		// if a branch dominates the block, resolve the branch
		if (p->m_alt != 0) {
			if (p->m_alt == p ||	// optimize branch-to-self
			    do_dom(this, p->m_alt, p) == dominates)
			{
// { cout << int(p->m_alt->m_block->m_loc) << " dominates " << int(p->m_last->m_block->m_loc) << " alt in " << int(p->m_block->m_loc) << endl; }
				p->m_alt->looper();
				p->m_alt = 0;
			}
		}
		if (p->m_norm != 0) {
			if (p->m_norm == p ||	// optimize branch-to-self
			    do_dom(this, p->m_norm, p) == dominates)
			{
// { cout << int(p->m_norm->m_block->m_loc) << " dominates " << int(p->m_last->m_block->m_loc) << " norm in " << int(p->m_block->m_loc) << endl; }
				p->m_norm->looper();
				p->m_norm = p->m_alt, p->m_alt = 0;
			}
		}
	}
}

void color_loop(analBlock *b, int depth, int color)
{
	if (b->isLoop()) {
		// start of loop; if new ref is at shallower
		// depth, need to adjust successors
		if (++depth >= b->m_depth) return;
		color = b->m_block->m_loc;
	} else if (b->m_color == 0xFF) {
		// uncolored; always color
	} else if (b->m_color == color) {
		// already colored with this color
		// if shallower depth, must adjust successors
		if (depth >= b->m_depth) return;
	} else {
		// already colored; if new ref at
		// shallower depth, must color successors
		if (depth >= b->m_depth) return;
	}
	b->m_depth = depth, b->m_color = color;
	if (b->m_norm != 0) color_loop(b->m_norm, depth, color);
	if (b->m_alt != 0) color_loop(b->m_alt, depth, color);
}
void color_loops(analBlock *b)
{
	// identify loop heads and resolve any back references to them
	b[0].loop_dominance();
	// reset graph color before doing algorithm
	for (analBlock *p = b; p != 0; p = p->m_next) {
		p->m_color = 0xFF, p->m_depth = 0xFF;
	}
	// color the loop contents with the label of the loop head
	color_loop(b, 0, 0);
}

int analBlock::shape_up(void)
{
	// We are the child of a two-branch flow and we've been told
	// to shape up.  We try to reduce own flow to the simplest
	// possible so that our parent can deal with us.
	//
	// see what we can pull in
	int progress = 0;
	while (block_flow() > 0) ++progress;
	return progress;
}

int analBlock::can_pull_up(analBlock *p, analBlock *q)
{
	if (p->refs() == 1 && !p->isVisited()) {
		int progress = p->shape_up();
		switch (p->out()) {
		case 0:
			// the flow exits; can pull it up
			return -1;
		case 1:
			// if the flow and other branch are the same
			// also can pull it up
			if (p->m_norm == q) return -2;
		}
		return progress;
	}
	return 0;
}

void analBlock::one_arm_pullup(analBlock *p, analBlock *q, flows flow)
{
	if (p->refs() == 1 && !p->isVisited()) {
		// can only combine into comb if block
		// ending in test is one instruction long
		int may_be_comb = m_len == 1;
		switch (p->out()) {
		case 0:
			// the flow exits; pull it in
			m_last->type(flow);
			merge(p); m_norm = q, m_alt = 0;
			higher(), m_last->pop();
			if (may_be_comb) setComb();
			block_flow();	// maybe can pull up next now
			break;
		case 1:
			// if the flow and other branch are the same
			// we can pull it in as well
			if (p->m_norm != q) break;
			m_last->type(flow);
			merge(p); m_norm = q, m_alt = 0;
			higher(), m_last->pop();
			if (may_be_comb) setComb();
			// we resolve one of the references to our common
			// successor, so maybe we can pull it in as well
			m_norm->resolve();
			block_flow();
			break;
		}
	}
}

int analBlock::block_flow(void)
{
	visitor dummy(this);
	//
	if (m_alt == 0) {
		// if we are zero-out, there's no more progress to make
		if (m_norm == 0) return 0;
		//
		// if only one reference, we can pull it in
		if (m_norm->refs() != 1 || m_norm->isVisited()) return 0;
		//
		// see if our successor can do any simplification
		// before we merge with it
		m_norm->block_flow();
		//
		merge(m_norm);
		//
		// has this now become a branch-to-self?
		if ((m_alt = m_norm->m_alt) == this) {
			// branch to self
			resolve();
			m_alt = 0;
		}
		if ((m_norm = m_norm->m_norm) == this) {
			// branch to self
			resolve();
			m_norm = m_alt, m_alt = 0;
		}
		return 1;
	}
	// we are a two-out block, so we try to merge
	// with each of our successors in turn
	int t = can_pull_up(m_norm, m_alt), f = can_pull_up(m_alt, m_norm);
	if (t == -1 && f == -1) {
		// can pull either up; pick the "better" one
		// better is defined as least nesting depth or shorter
		if (m_norm->m_height < m_alt->m_height) {
			one_arm_pullup(m_norm, m_alt, flow_then);
		} else if (m_alt->m_height < m_norm->m_height) {
			one_arm_pullup(m_alt, m_norm, flow_else);
		} else if (m_alt->m_len < m_norm->m_len) {
			one_arm_pullup(m_alt, m_norm, flow_else);
		} else {
			one_arm_pullup(m_norm, m_alt, flow_then);
		}
		return 1;
	} else if (t == -2) {
		one_arm_pullup(m_norm, m_alt, flow_then);
		return 1;
	} else if (f == -2) {
		one_arm_pullup(m_alt, m_norm, flow_else);
		return 1;
	}
	int progress = t + f;
	//
	if (m_norm->refs() == 1 && m_alt->refs() == 1
	    && m_norm->out() == 1 && m_alt->out() == 1
	    && !m_norm->isVisited() && !m_alt->isVisited()
	    && m_norm->m_norm == m_alt->m_norm)
	{
		// both branches go to a common destination; pull them in
		// and the common destination becomes our single-out
		int dest = m_norm->m_norm->m_block->m_loc;
		int may_be_comb = m_len == 1;
		if (m_norm->isComb() && !m_alt->isComb()) {
// TODO: if both branches are combs, pick the better one for the internal flow
			analBlock *t = m_norm;
			m_norm = m_alt, m_alt = t;
			m_last->type(flow_else);
		} else {
			m_last->type(flow_then);
		}
		merge(m_norm);
		if (m_last->m_true == dest) {
			m_last->type(flow_else_t);
		} else if (m_last->m_false == dest) {
			m_last->type(flow_else_f);
		} else {
			m_last->type(flow_else_x);
		}
		merge(m_alt);
		higher();
		if (m_alt->isComb()) {
			m_alt->pop();
		} else {
			m_last->pop();
		}
		m_norm = m_alt->m_norm, m_alt = 0;
		if (may_be_comb) setComb();
		++progress;
		// we might be able to pull in common destination now
		m_norm->resolve();
		progress += block_flow();
	}
	return progress;
}

// When all else fails and the flow is too complex for us to analyze,
// this simply pulls the blocks together.  At best, it will eliminate
// a goto in the displayed code, so it's worth doing.
//
void analBlock::snuggle_up(void)
{
// { static int x = 0; if (++x > 30) exit(-1); }
	setVisited();		// so we won't be pulled in multiple times
	if (m_norm != 0 && !m_norm->isVisited()) {
// { cout << "snuggling up " << int(m_norm->m_block->m_loc) << " from " << int(m_block->m_loc) << endl; }
		m_norm->setLabel();
		m_norm->snuggle_up();
		merge(m_norm);
	}
	if (m_alt != 0 && !m_alt->isVisited()) {
// { cout << "snuggling up " << int(m_alt->m_block->m_loc) << " from " << int(m_block->m_loc) << endl; }
		m_alt->setLabel();
		m_alt->snuggle_up();
		merge(m_alt);
	}
}

void simIFF_BHAV_analyze::analyze(void)
{
	analBlock block[m_bhav.count()];
	// initialize
	for (int i = 0; i < m_bhav.count(); ++i) {
		analBlock &t = block[i];
		t.m_block = m_blocks + i;
		t.m_true = m_bhav.inst(i)[2], t.m_false = m_bhav.inst(i)[3];
		if (t.m_true < m_bhav.count()) t.m_norm = block + t.m_true;
		if (t.m_false < m_bhav.count()) t.m_alt = block + t.m_false;
		// if a block has only one exit, we put it in m_norm
		if (t.m_norm == 0) t.m_norm = t.m_alt, t.m_alt = 0;
	}
	//
	// find and eliminate orphans from any analysis
	analBlock *orphans = find_orphans(block, m_bhav.count());
	//
	// force a reference on the initial instruction so
	// that it will never be absorbed by flow analysis
	block[0].m_refs = 1;
	//
	// initialize reference counts
	for (analBlock *p = block; p != 0; p = p->m_next) {
		if (p->m_true < m_bhav.count()) {
			block[p->m_true].ref();
		}
		if (p->m_false < m_bhav.count()) {
			// if both branches are the same,
			// we only need to track one
			if (p->m_true == p->m_false) {
				p->m_alt = 0;
			} else {
				block[p->m_false].ref();
			}
		}
	}
	// one pass is sufficient to pull all the basic blocks together
	//
	for (analBlock *p = block; p != 0; p = p->m_next) {
		p->basic_block();
	}
// { for (analBlock *p = block; p != 0; p = p->m_next) { cout << "blk " << int(p->m_block->m_loc); if (p->m_norm != 0) cout << " norm " << int(p->m_norm->m_block->m_loc); if (p->m_alt != 0) cout << " alt " << int(p->m_alt->m_block->m_loc); cout << endl; } }
	// color loop contents with the loop label
	//
	color_loops(block);
	// keep reducing the block flow as long as we're making progress
	//
	for (int progress = 1; progress > 0; ) {
		progress = 0;
		for (analBlock *p = block; p != 0; p = p->m_next) {
			progress += p->shape_up();
		}
	}
	//
	// accumulate all the blocks together
	block[0].snuggle_up();
	if (block[0].m_next != 0) cout << "LOOK: not all blocks merged" << endl;
	//
	// put the new sequence in the links
	Ref x, *last = &x;
	for (analBlock *p = block; p != 0; p = p->m_flow) {
		*last = p - block;
// { static int x = 0; if (++x > 30) abort(); }
// { cout << "link to " << int(*last) << endl; }
		last = &p->m_block->m_flow;
		//p->m_block->m_type = (p->m_type<<4)|p->m_pop;
		if (p->isLabeled()) p->m_block->m_type |= 0x80;
	}
	for (analBlock *p = orphans; p != 0; p = p->m_flow) {
		*last = p - block;
		last = &p->m_block->m_flow;
		//p->type(analBlock::flow_orphan);
		//p->m_block->m_type = flow_orphan<<4;
	}
	*last = 0;
}
