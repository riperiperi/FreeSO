#include "iff_fcns.h"
#include "crack.h"
#include <iostream>

inline simIFF_FCNS::Entry::Entry(void) {}
inline simIFF_FCNS::Entry::~Entry(void) { delete[] m_txt; delete[] m_tip; }

static const char *readString(crack &in, int version)
{
	switch (version) {
	case 1:
		return in.readEvenString();
	case 2:
		// same as format FCFF string
		int len = in.s()->get();
		if (len > 127) len = (len - 128) + (in.s()->get()<<7);
		if (len == 0) return 0;
		char *str = new char[len + 1];
		in.s()->read(str, len);
		str[len] = '\0';
		return str;
	}
	return 0;	// "can't happen"
}

simIFF_FCNS::simIFF_FCNS(std::istream *s)
:	m_entries(0)
{
	crackLittle in(s);
	if (in.readInt() != 0) return;
	int version = in.readInt();
	switch (version) {
	default:
		return;
	case 1: case 2:
		break;
	}
	if (in.readInt() != (((((('F'<<8)|'C')<<8)|'N')<<8)|'S')) return;
	m_count = in.readInt();
	if (m_count <= 0) return;
	m_entries = new Entry[m_count];
	for (int i = 0; i < m_count; ++i) {
		simIFF_FCNS::Entry &x = m_entries[i];
		x.m_txt = readString(in, version);
		x.m_value = in.readFloat();
		x.m_tip = readString(in, version);
	}
	// in.dump(512);
}

simIFF_FCNS::~simIFF_FCNS(void)
{
	delete[] m_entries;
}
