#include "iff.h"
#include "substream.h"
#include <iostream>
using std::cout;
using std::endl;
#include <fstream>
#include <string.h>

static int readBig(std::istream *in)
{
	unsigned char a, b, c, d;
	a = in->get(), b = in->get(), c = in->get(), d = in->get();
	return (((((a<<8) | b)<<8) | c)<<8) | d;
}

static int readLittle(std::istream *in)
{
	unsigned char a, b, c, d;
	a = in->get(), b = in->get(), c = in->get(), d = in->get();
	return (((((d<<8) | c)<<8) | b)<<8) | a;
}

static short readShort(std::istream *in)
{
	unsigned char a, b;
	a = in->get(), b = in->get();
	return (a<<8) | b;
}

static short readShortLittle(std::istream *in)
{
	unsigned char a, b;
	a = in->get(), b = in->get();
	return (b<<8) | a;
}

inline simIFF::Entry::Entry(void) : m_name(0) { }
inline simIFF::Entry::~Entry(void) { delete[] m_name; }

inline simIFF::Type::Type(void) : m_list(0) { }
inline simIFF::Type::~Type(void) { delete[] m_list; }

void simIFF::init(void)
{
	m_list = 0, m_type = 0;
	if (!m_stream->good()) return;
	for (char *p = signature(); *p; ++p) {
		int c = m_stream->get();
		if (c != *p) {
			return;	/// ERROR: invalid signature
		}
	}
	m_stream->seekg(64 - 4, std::ios::beg);
	int rsmp = readBig(m_stream);	// can IFF not have rsmp?
	for (m_entries = 0; m_stream->get() != EOF; ++m_entries) {
		// first pass, just count entries
		m_stream->seekg(3, std::ios::cur);
		m_stream->seekg(readBig(m_stream) - 8, std::ios::cur);
	}
	m_stream->clear();
	m_list = new Entry[m_entries];
	m_stream->seekg(64, std::ios::beg);
	m_rsmp = -1;
	for (unsigned int i = 0; i < m_entries; ++i) {
		// second pass, fill in info
		Entry *p = &m_list[i];
		p->m_parent = this;
		p->m_offset = m_stream->tellg();
		if (p->m_offset == rsmp) m_rsmp = i;
		p->m_offset += 76;
		m_stream->get(p->m_type[0]);
		m_stream->get(p->m_type[1]);
		m_stream->get(p->m_type[2]);
		m_stream->get(p->m_type[3]);
		p->m_length = readBig(m_stream) - 76;
		p->m_id = readShort(m_stream);
		p->m_flags = readShort(m_stream);
		char buf[66];
		m_stream->read(buf+1, 64);
		buf[65] = 0;
		if ((buf[0] = strlen(buf+1)) == 0) {
			p->m_name = 0;
		} else {
			p->m_name = new char[buf[0] + 2];
			memcpy(p->m_name, buf, buf[0] + 2);
		}
		m_stream->seekg(p->m_length, std::ios::cur);
		// p->rewind();
	}
}

simIFF::simIFF(const char *file)
{
	m_stream = new std::ifstream(file);
	init();
}

static inline void skipStuff(int version, std::istream *s)
{
	if (version == 0) {
		s->seekg(4, std::ios::cur);	// ID and flags
		// scan off variable-length name field
		for ( ; ; ) {
			char a, b;
			s->get(a), s->get(b);
			if (a == 0 || b == 0) break;
		}
	} else if (version == 1) {
		s->seekg(6, std::ios::cur);	// ID and flags
		// scan off Pascal-style counted string
		s->seekg(s->get(), std::ios::cur);
	} else {
		std::cerr << "FATAL: unknown rsmp version" << endl;
		exit(-1);
	}
}
int simIFF::types(void)
{
	// fast-path through if this has already been done
	if (m_type != 0) return m_types;
	// otherwise, create the secondary index
	if (m_rsmp < 0) return -1;
	m_stream->seekg(m_list[m_rsmp].m_offset);
	if (readLittle(m_stream) != 0) return -1;	// unknown field
	int version = readLittle(m_stream);
	if (readLittle(m_stream) != (((((('r'<<8)|'s')<<8)|'m')<<8)|'p')) {
		return -1;	/// ERROR: validator is not 'rsmp'
	}
	// don't check version until we think it ought to be a rsmp
	if (version != 0 && version != 1) {
		static int once = 0;
		if (once == 0) {
			once = 1;
			cout	<< "LOOK: cannot handle rsmp version "
				<< version << endl;
		}
		return -1;
	}
	// next field might be length, but sometimes
	// is zero, so we just skip it
	m_stream->seekg(4, std::ios::cur);
	//
	m_types = readLittle(m_stream);
	m_type = new Type[m_types];
	for (int i = 0; i < m_types; ++i) {
		Type *p = m_type + i;
		m_stream->get(p->m_type[3]);
		m_stream->get(p->m_type[2]);
		m_stream->get(p->m_type[1]);
		m_stream->get(p->m_type[0]);
		p->m_entries = readLittle(m_stream);
		p->m_list = new (Entry *)[m_entries];
		for (unsigned int j = 0; j < p->m_entries; ++j) {
			int offset = readLittle(m_stream) + 76;
			unsigned int x;
			for (x = 0; x < m_entries; ++x)
				if (m_list[x].m_offset == offset)
					goto FoundIndex;
			// FATAL ERROR: rsmp is corrupt
			delete m_type, m_type = 0;
			return m_rsmp = -2;
		    FoundIndex:
			skipStuff(version, m_stream);
			p->m_list[j] = m_list + x;
		}
	}
	return m_types;
}

// subroutine to validate rsmp entry v. index entry
static const char *whyInvalid;
static int validateStuff(int version, std::istream *s, simIFF::Entry &e)
{
	unsigned short id = readShortLittle(s);
	if (e.id() != id) { whyInvalid = "ID mismatch"; return 1; }
	if (version == 1) {
		int t = readShortLittle(s);
		if (t != 0) {
			/*DEBUG*/cout << "LOOK: top index " << t << endl;
			whyInvalid = "top index non-zero";
			return 1;
		}
	}
	int flags = readShortLittle(s);
	if (e.flags() != flags) { whyInvalid = "flags mismatch"; return 1; }
	char buf[64 + 2];	// for name field
	if (version == 0) {
		// scan in variable-length name field
		for (unsigned int p = 0; p < sizeof buf; p += 2) {
			s->get(buf[p]), s->get(buf[p+1]);
			if (buf[p] == 0 || buf[p+1] == 0) break;
		}
	} else if (version == 1) {
		// scan in Pascal-style counted string
		int t = s->get();
		s->read(buf, t);
		buf[t] = '\0';
	} else {
		std::cerr << "FATAL: unknown rsmp version in validate" << endl;
		exit(-1);
	}
	if (strcmp(e.name(), buf) != 0) { whyInvalid = "name mismatch"; return 1; }
	return 0;
}
// validate the data in the entries against the rsmp, if any
int simIFF::validate(void)
{
	if (m_rsmp == -1) return no_rsmp;
	if (types() == -1) {	// builds secondary index as side-effect
		// rsmp is corrupt somehow
		::whyInvalid = "rsmp corrupt";
		return invalid;
	}
	m_stream->seekg(m_list[m_rsmp].m_offset + 4);
	int version = readLittle(m_stream);
	m_stream->seekg(m_list[m_rsmp].m_offset + 20);
	for (int i = 0; i < m_types; ++i) {
		char c[4];
		m_stream->get(c[3]);
		m_stream->get(c[2]);
		m_stream->get(c[1]);
		m_stream->get(c[0]);
		int entries = readLittle(m_stream);
		for (int j = 0; j < entries; ++j) {
			int offset = readLittle(m_stream) + 76;
			unsigned int x;
			for (x = 0; x < m_entries; ++x)
				if (m_list[x].m_offset == offset)
					goto FoundIndex;
			::whyInvalid = "offset invalid";
			return invalid;	/// ERROR: no matching entry
		    FoundIndex:
			// compare rsmp values against entry
			if (m_list[x].m_type[0] != c[0]
			    || m_list[x].m_type[1] != c[1]
			    || m_list[x].m_type[2] != c[2]
			    || m_list[x].m_type[3] != c[3])
			{
				::whyInvalid = "type code mismatch";
				return invalid;
			}
			if (validateStuff(version, m_stream, m_list[x])) {
				return invalid;
			}
		}
	}
	return validated;
}
const char * simIFF::whyInvalid(void) const
{
	return ::whyInvalid;
}

simIFF::~simIFF(void)
{
	delete m_stream;
	delete[] m_list;
	delete[] m_type;
}

simIFF::Type &simIFF::operator[](const char *typeName)
{
	static Type dummy;
	if (dummy.m_type[0] == 0) {
		// initialize
		dummy.m_type[0] = 'e';
		dummy.m_type[1] = 'r';
		dummy.m_type[2] = 'r';
		dummy.m_type[3] = '_';
		dummy.m_entries = 0;
	}
	if (types() <= 0) return dummy;
	for (int i = 0; i < m_types; ++i) {
		Type *p = m_type + i;
		if (p->type(typeName)) return *p;
	}
	return dummy;
}

std::istream *simIFF::Entry::stream(void) const
{
	return new substream(m_parent->m_stream, m_offset, m_length);
	return 0;
}

simIFF::Entry *simIFF::Type::id(int ID) const
{
	for (unsigned int i = 0; i < m_entries; ++i) {
		if (m_list[i]->id() == ID) return m_list[i];
	}
	return 0;
}
