#include "mkfar.h"
#include <iostream>

int main(int argc, char **argv)
{
	if (argc < 3) {
		std::cout << "Usage: mk_far out.far arg ..." << std::endl;
		std::cout << " where arg can be a directory, file, "
			"or far archive" << std::endl;
		return 1;
	}
	simMkFAR far(argv[1]);
	int errs = 0;
	if (far.err()) {
		std::cout << "Could not open output file `" << argv[1] << "'"
			<< std::endl;
		++errs;
	}
	for (int i = 2; i < argc; ++i) far.addDir(argv[i]);
	return errs;
}
