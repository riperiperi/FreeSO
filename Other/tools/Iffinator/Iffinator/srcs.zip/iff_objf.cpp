#include "iff_objf.h"
#include "crack.h"
#include <iostream>

simIFF_OBJf::simIFF_OBJf(std::istream *s)
:	m_count(0)
{
	crackLittle in(s);
	if (in.readInt() != 0) return;
	if (in.readInt() != 0) return;
	if (in.readInt() != (((((('O'<<8)|'B')<<8)|'J')<<8)|'f')) return;
	m_count = in.readInt();
	if ((unsigned int)m_count > m_slots) {
		std::cout << "LOOK: OBJF count too big: "
			<< m_count << std::endl;
		m_count = m_slots;
	}
	int i = 0;
	for (; i < m_count; ++i) {
		m_fun[i].test = in.readShort();
		m_fun[i].act  = in.readShort();
	}
	for (; i < m_slots; ++i) {
		m_fun[i].test = m_fun[i].act = 0;
	}
	// in.dump(512, crack::dumpShort);
}
