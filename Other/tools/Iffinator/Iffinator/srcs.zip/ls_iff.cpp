#include "iff.h"
#include "iff_strings.h"
#include "iff_carr.h"
#include "iff_bcon.h"
#include "iff_bhav.h"
#include "iff_dgrp.h"
#include "iff_fcns.h"
#include "iff_fwav.h"
#include "iff_glob.h"
#include "iff_objd.h"
#include "iff_objf.h"
#include "iff_spr.h"
#include "iff_trcn.h"
#include "iff_ttab.h"
#include <stdio.h>
#include <ctype.h>
#include <iostream>
#include <iomanip>
using std::cout;
using std::endl;

static void printFlags(int v, char **flags, char *name = 0)
{
	if (name == 0) name = "flags";
	cout << name << ' ';
	if (v == 0) { cout << "(none set)" << endl; return; }
	for (; *flags != 0; ++flags) {
		if ((v&1) != 0) cout << '+' << *flags;
		v >>= 1;
	}
	if (v != 0) cout << "+more " << v;
	cout << endl;
}

static void printString(const char *s)
{
	putchar('<'); putchar('<'); putchar('<');
	for (int c; (c = *(unsigned char *)s) != '\0'; ++s) {
		if (c <= 127 && isprint(c)) {
			putchar(c);
		} else if (c == '\n') {
			putchar(c);
		} else if (c == '\r') {
			putchar('\\'), putchar('r');
		} else if (c == '\t') {
			putchar('\\'), putchar('t');
		} else if (c == '\b') {
			putchar('\\'), putchar('b');
		} else {
			printf("\\x%2.2x", c);
		}
	}
	putchar('>'); putchar('>'); putchar('>');
	putchar('\n');
}

static char *asc(unsigned char &c)
{
	static char hex[] = "0123456789abcdef";
	static char buf[4];
	if (isprint(c)) {
		buf[0] = c, buf[1] = '\0';
		return buf;
	}
	buf[0] = '\\';
	switch (c) {
	case '\0':	buf[1] = '0', buf[2] = '\0'; return buf;
	case '\r':	buf[1] = 'r', buf[2] = '\0'; return buf;
	case '\n':	buf[1] = 'n', buf[2] = '\0'; return buf;
	case '\v':	buf[1] = 'v', buf[2] = '\0'; return buf;
	case '\t':	buf[1] = 't', buf[2] = '\0'; return buf;
	case '\f':	buf[1] = 'f', buf[2] = '\0'; return buf;
	}
	buf[1] = hex[c>>4], buf[2] = hex[c&15], buf[3] = '\0';
	return buf;
}

static void dump(simIFF::Entry &e)
{
	unsigned char buf[128];
	std::istream *in = e.stream();
	int max = in->read((char*)buf, sizeof buf).gcount();
	delete in;
	for (int i = 0; i < max; i += 16) {
		int lim = (i + 16 < max) ? 16 : max - i;
		printf("%6o ", i);
		for (int j = 0; j < lim; ++j) printf(" %3.3o", buf[i+j]);
		printf("\n       ");
		for (int j = 0; j < lim; ++j) printf(" %3s", asc(buf[i+j]));
		printf("\n");
	}
}

static void dumpStrings(simIFF::Entry &e)
{
	simIFF_string t(e.stream());
	while (t.next() != EOF) {
		printf("    ");
		if (t.sets() > 1) printf("Set%3d ", t.set());
		printf("Idx%3d ", t.entry());
		if (t.code() != -1) printf("ID%3d ", t.code());
		printString(t.str1());
		if (t.len2() != 0) {
			putchar('\t'); putchar('\t');
			printString(t.str2());
		}
	}
}

static void dumpCARR(simIFF::Entry &e)
{
	simIFF_CARR t(e.stream());
	printf("%s career track with %d levels\n",
		t.name(), t.levels());
	for (int l = 1; l <= t.levels(); ++l) {
		printf("%3d:", l);
		printf("%3d", t[l-1].friends());
		printf("%3d", t[l-1].cooking()/100);
		printf("%3d", t[l-1].mechanical()/100);
		printf("%3d", t[l-1].charisma()/100);
		printf("%3d", t[l-1].body()/100);
		printf("%3d", t[l-1].logic()/100);
		printf("%3d|", t[l-1].creativity()/100);
		printf("%1d", t[l-1].unknown1());
		printf("%2d", t[l-1].unknown2());
		printf("%2d|", t[l-1].unknown3());
		printf("%2d", -(t[l-1].hunger()));
		printf("%3d", -(t[l-1].comfort()));
		printf("%3d", -(t[l-1].hygiene()));
		printf("%3d", -(t[l-1].bladder()));
		printf("%3d", -(t[l-1].energy()));
		printf("%3d", -(t[l-1].fun()));
		printf("%3d|", -(t[l-1].social()));
		printf("%4d", t[l-1].salary());
		printf("%3d", t[l-1].start());
		printf("%3d", t[l-1].end());
		printf("%2d", t[l-1].car());
		printf(" %.13s", t[l-1].name());
		putchar('\n');
	}
}

static void dumpOBJD(simIFF::Entry &e)
{
	simIFF_OBJD t(e.stream());
	if (!t.err()) t.prettyPrint(&cout);
}

static char *objf[] = {
	"init",
	"main",
	"load",
	"cleanup",
	"queue skipped",
	"allow intersection",
	"wall adjacency changed",
	"room changed",
	"dynamic multi-tile update",
	"placement",
	"pickup",
	"user placement",
	"user pickup",
	"level info request",
	"serving surface",
	"portal",
	"gardening",
	"wash hands",
	"prep",
	"cook",
	"surface",
	"dispose",
	"food",
	"pick up from slot",
	"wash dish",
	"eating surface",
	"sit",
	"stand",
	"clean",
	"repair",
	"UI event" };
static void dumpOBJf(simIFF::Entry &e)
{
	simIFF_OBJf t(e.stream());
	cout << "\tAction\tGuard\tType" << endl;
	for (int i = 0; i < t.count(); ++i) {
		if (t[i].act != 0 || t[i].test != 0) {
			cout	<< '\t' << t[i].act << '\t' << t[i].test
				<< '\t' << objf[i] << endl;
		}
	}
}

using std::hex;
using std::dec;
using std::setw;
using std::setfill;
static void dumpBCON(simIFF::Entry &e)
{
	simIFF_BCON b(e.stream());
	cout	<< ' ' << b.count() << " constants, flags 0x"
		<< hex << b.flags() << dec << endl;
	cout	<< "        hex signed";
	simIFF::Entry *entry = (*e.parent())["TRCN"].id(e.id());
	simIFF_TRCN t((entry == 0) ? 0 : entry->stream());
	if (!t.err()) cout << "  label";
	cout << endl;
	for (int i = 0; i < b.count(); ++i) {
		cout	<< setw(4) << i << ':'
			<< setw(6) << hex << (unsigned short)b[i]
			<< setw(7) << dec << (signed short)b[i];
		if (!t.err() && t.count() > i) cout << "  " << t[i].str1();
		cout << endl;
	}
}

using std::ios;
static void dumpTRCN(simIFF::Entry &e)
{
	simIFF_TRCN t(e.stream());
	if (t.err()) { dump(e); return; }
	cout << "         unknown used  ? min  max  label" << endl;
	for (int i = 0; i < t.count(); ++i) {
		const simIFF_TRCN::Label &l = t[i];
		cout	<< setw(4) << i << ":  " << ' '
			<< hex << setfill('0') << setiosflags(ios::uppercase)
			<< setw(8) << l.unknown()
			<< dec << setfill(' ') << resetiosflags(ios::uppercase)
			<< setw(5) << l.isUsed()
			<< setw(3) << l.isRange()
			<< setw(4) << l.low()
			<< setw(5) << l.high()
			<< "  " << l.str1() << endl;
		if (l.str2() != 0 && *l.str2() != '\0') {
			cout << "\t\tcomment: " << l.str2() << endl;
		}
	}
}

static void dumpFCNS(simIFF::Entry &e)
{
	simIFF_FCNS obj(e.stream());
	if (obj.err()) { dump(e); return; }
	for (int i = 0; i < obj.count(); ++i) {
		const simIFF_FCNS::Entry &x = obj[i];
		cout	<< setw(3) << i << ':'
			<< setw(7) << x.value()
			<< ' ' << x.txt() << endl;
		if (x.tip() != 0 && *x.tip() != 0) {
			cout << '\t' << x.tip() << endl;
		}
	}
}

static void dumpDGRP(simIFF::Entry &e)
{
	simIFF_DGRP obj(e.stream());
	//cout << "count " << obj.count() << endl;	// always 12
	if (obj.count() != 12) cout << "LOOK: count not 12" << endl;
	for (int i = 0; i < obj.count(); ++i) {
		const simIFF_DGRP::Image &img = obj[i];
		cout << "   direction " << img.orient()	// 1, 4, 16, 64 (equal)
			<< " zoom " << img.zoom()	// 1, 2, 3 (equal)
			<< " has " << img.count() << " frame(s)" << endl;
		for (int j = 0; j < img.count(); ++j) {
			const simIFF_DGRP::Sprite &s = img[j];
			cout << "     " << j << ':';
			//cout << " what? " << s.m_what;
			cout << " SPR " << s.m_id << '#' << s.m_index;
			cout	<< " pixel(x,y) " << s.m_pixelx
				<< ' ' << s.m_pixely;
			cout	<< " (x,y,z)offset " << s.m_xoffset
				<< ' ' << s.m_yoffset
				<< ' ' << s.m_zoffset;
			static char *flgs[] = { "flip", "bit2", "bit3", "bit4", "bit5", 0};
			printFlags(s.m_flags, flgs, " flags");
		}
	}
}

static void dumpSPR(simIFF::Entry &e)
{
	simIFF_SPR t(e.stream());
	cout	<< "\tSprite has " << t.count()
		<< " frames with default PALT of " << t.palette() << endl;
	for (int i = 0; i < t.count(); ++i) {
		simSprite s(t, i);
		cout	<< "\tFrame " << i
			<< " is " << s.width()
			<< 'x' << s.height()
			<< " at (" << s.xloc()
			<< ',' << s.yloc() << ')';
		if (t.palette() != s.palette()) {
			cout << " using PALT " << s.palette();
		}
		cout << endl;
	}
}

static inline simIFF::Entry *BHAV_by_ID(simIFF *iff, int id)
{
	return (*iff)["BHAV"].id(id);
}

static inline void BHAV_name(char *name, simIFF::Entry &e, int id)
{
	if (id == 0) return;
	cout << '\t' << name << '\t';
	simIFF::Entry *bhav = BHAV_by_ID(e.parent(), id);
	if (bhav != 0) {
		cout << bhav->name();
	} else {
		cout << "ID " << id;
	}
	cout << endl;
}

static void dumpTTAB(simIFF::Entry &e)
{
	simIFF_TTAB t(e.stream());
	if (t.err()) {
		cout << "\tLOOK: could not parse TTAB resource" << endl;
		return;
	}
	cout << "\tFound info for " << t.count() << " interactions" << endl;
	simIFF::Entry *strings = (*e.parent())["TTAs"].id(e.id());
	simIFF_strings *s = (strings == 0) ? 0 :
		new simIFF_strings(strings->stream());
	for (int i = 0; i < t.count(); ++i) {
		const simIFF_TTAB::Interact &x = t[i];
		cout << "\t***** menu " << i;
		if (s == 0) {
			cout << "\tTTAs index " << x.stringx() << endl;
		} else if (x.stringx() < 0 || x.stringx() >= s->entries()) {
			cout << "\tLOOK: TTAs index " << x.stringx() << endl;
		} else {
			cout << '\t' << (*s)[x.stringx()].str1() << endl;
		}
		BHAV_name("action", e, x.action());
		BHAV_name("guard", e, x.guard());
		static char *flag_names[] = {
			"visitor",
			"joinable", // ???
			"run immediately", // ???
			"allow consecutive",
			"child",
			"demo child",	// ???
			"adult",
			"debug",
			"auto first",
			"cat",
			"dog",
			"bit11",
			"bit12",
			"bit13",
			"bit14",
			"bit15",
			0 };
		printFlags(x.flags() ^ 0x50, flag_names, "\tflags");
		cout	<< "\tattenuation " << x.attenuation()
			<< " custom " << x.custom() << endl;
		cout << "\tautonomy " << x.autonomy() << endl;
		cout << "\tjoin " << x.join() << endl;
		// order set by STR# 134 "motive strings"
		static const char *motiveStrings[] = {
			"LOOK: UNUSED[0]",
			"LOOK: UNUSED[1]",
			"LOOK: UNUSED[2]",
			"mood",
			"LOOK: UNUSED[4]",
			"energy",
			"comfort",
			"hunger",
			"hygiene",
			"bladder",
			"LOOK: UNUSED[10]",
			"UNUSED sleep state",
			"UNUSED stress",
			"room",
			"social",
			"fun" };
#define numOf(s)	((int)(sizeof s/sizeof s[0]))
		for (int j = 0; j < numOf(motiveStrings); ++j) {
			if (x[j].limit == 0 && x[j].delta == 0 && x[j].type == 0) continue;
			// STR# 232 "personality ads"
			static const char *types[] = {
				/* 0*/ "none",
				/* 1*/ "nice",
				/* 2*/ "grouchy",
				/* 3*/ "active",
				/* 4*/ "lazy",
				/* 5*/ "generous",
				/* 6*/ "selfish",
				/* 7*/ "playful",
				/* 8*/ "serious",
				/* 9*/ "outgoing",
				/*10*/ "shy",
				/*11*/ "neat",
				/*12*/ "sloppy",
				/*13*/ "cleaning skill",	// old?
				/*14*/ "cooking skill",
				/*15*/ "charisma",		// social skill
				/*16*/ "mechanical skill",	// repair
				/*17*/ "gardening skill",	// old
				/*18*/ "music skill",		// old
				/*19*/ "creative skill",
				/*20*/ "literacy skill",	// old
				/*21*/ "body skill",		// physical
				/*22*/ "logic skill" };
			cout	<< '\t' << motiveStrings[j]
				<< ' ' << x[j].limit
				<< " delta " << x[j].delta;
			if (x[j].type != 0) {
				cout << ", ";
				if (x[j].type < numOf(types)) {
					cout << types[x[j].type];
				} else cout << "BAD TYPE " << x[j].type;
			}
			cout << endl;
		}
		if (x.WTF() != 0) cout << "\tWTF? " << x.WTF() << endl;
	}
	delete s;
}

static void dumpBHAV(simIFF::Entry &e)
{
	unsigned char header[20];
	simIFF_BHAV t(e.stream(), header);
	if (t.err()) {
		cout	<< "\tLOOK: could not parse BHAV resource: type "
			<< hex << t.sig() << dec << " count " << t.count()
			<< endl;
		return;
	}
	// display header
	cout	<< ' ' << hex << t.sig() << setfill('0')
		<< setiosflags(ios::uppercase);
	for (int i = 2; i < t.hdr(); ++i) {
		cout << ' ' << setw(2) << int(header[i]);
	}
	cout << setfill(' ') << dec << resetiosflags(ios::uppercase);
	// header information
	cout	<< " count=" << t.count()
		<< " params=" << t.params()
		<< " locals=" << t.locals();
	if (t.fld1() != 0) cout << " fld1=" << t.fld1();
	if (t.fld2() != 0) cout << " fld2=" << t.fld2();
	cout << endl;
	// display instructions
	simIFF_BHAV_analyze bhav(t);
	bhav.analyze();
	bhav.set_file(e.parent());
	bhav.display();
	bhav.set_file(0);       // so it won't be deleted
}

static void printName(const char *s)
{
	// this is dumb, but some resources put garbage in their name field
	for ( ; *s != '\0'; ++s) printf("%s", asc(*(unsigned char *)s));
}

static void dumpRSMP(simIFF::Entry &e)
{
	simIFF *p = e.parent();
	for (int i = 0; i < p->types(); ++i) {
		printf("   %.4s", p->type(i).type());
		for (int j = 0; j < p->type(i).entries(); ++j) {
			simIFF::Entry &ee = p->type(i)[j];
			// printf("\t%5d 0x%3.3X %5d\n",
			printf("\t%5d 0x%3.3x %8d ",
				ee.id(), ee.flags(), ee.length());
			printName(ee.name());
			putchar('\n');
		}
	}
}

int main(int argc, char **argv)
{
	char *my_name = argv[0];
	int is_dump = 0;
	while (argc > 1 && argv[1][0] == '-') {
		// very simple option processing...
		if (argv[1][1] == 'l' && argv[1][2] == '\0') {
			is_dump = 1;
		} else {
			printf("Usage: %s [options] filename\n", my_name);
			return 1;
		}
		--argc, ++argv;
	}
	if (argc != 2) {
		printf("Usage: %s [options] filename\n", my_name);
		return 1;
	}
	simIFF in(argv[1]);
	if (in.err()) {
		printf("Could not open IFF file\n");
		return 1;
	}
	switch (in.validate()) {
	case simIFF::no_rsmp:
		fprintf(stderr, "%s has no rsmp resource\n", argv[1]);
		break;
	case simIFF::invalid:
		fprintf(stderr, "%s failed to validate (%s)\n",
				argv[1], in.whyInvalid());
		break;
	case simIFF::validated:
		break;
	}
	printf("Type    ID Flags   Length Name or reference\n");
	for (int i = 0; i < in.entries(); ++i) {
		simIFF::Entry &e = in[i];
		printf("%4.4s %5d 0x%3.3x %8d "
			, e.type()
			, e.id()
			, e.flags()
			, e.length()
			);
		printName(e.name());
		if (e.type("FWAV")) {
			simIFF_FWAV r(e.stream());
			if (!r.err()) cout << ">>> " << r.fwav();
		} else if (e.type("GLOB")) {
			simIFF_GLOB r(e.stream());
			if (!r.err()) cout << ">>> " << r.glob();
		} else if (e.type("SLOT")) {	// DEBUG...
			std::istream *s = e.stream();
			unsigned char buf[16];
			s->read((char*)buf, sizeof buf);
			cout	<< ">>> version " << int(buf[4])
				<< " count " << int(buf[12]);
			delete s;
		}
		putchar('\n');
		if (!is_dump) continue;
		if (e.type("FWAV")) { } else
		if (e.type("GLOB")) { } else
		if (e.type("SLOT")) { } else
		if (e.type("BMP_")) { } else
		if (e.type("DGRP")) { dumpDGRP(e); } else
		if (e.type("SPR#")) { dumpSPR(e); } else
		if (e.type("SPR2")) { dumpSPR(e); } else
		if (e.type("PALT")) { /* dumpPALT(e); */ } else
		if (e.type("CTSS")) { dumpStrings(e); } else
		if (e.type("STR#")) { dumpStrings(e); } else
		if (e.type("TTAs")) { dumpStrings(e); } else
		if (e.type("FAMs")) { dumpStrings(e); } else
		if (e.type("CARR")) { dumpCARR(e); } else
		if (e.type("OBJD")) { dumpOBJD(e); } else
		if (e.type("OBJf")) { dumpOBJf(e); } else
		if (e.type("XXXX")) { } else
		if (e.type("TREE")) { } else
		if (e.type("TPRP")) { } else
		if (e.type("POSI")) { } else
		if (e.type("BHAV")) { dumpBHAV(e); } else
		if (e.type("TTAB")) { dumpTTAB(e); } else
		if (e.type("BCON")) { dumpBCON(e); } else
		if (e.type("TRCN")) { dumpTRCN(e); } else
		if (e.type("FCNS")) { dumpFCNS(e); } else
		if (e.type("rsmp")) { dumpRSMP(e); } else
		dump(e);
	}
	return 0;
}
