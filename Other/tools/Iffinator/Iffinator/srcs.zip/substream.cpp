#include "substream.h"
using namespace std;

int substream::overflow(int x)
{
	// put is exhausted; provide new output area
	// only support input (for now?)
	return EOF;
}

int substream::underflow(void)
{
	// get is exhausted; provide more input
	if (base() == 0) {	// no current allocation
		if (allocate() == EOF) return EOF;
	} else {
		if (in_avail()) return (unsigned char) *gptr();
	}
	if (m_tell >= m_length) {
		setg(0, 0, 0);
		return EOF;
	}
	int len = blen();
	if (m_tell + len > m_length) len = m_length - m_tell;
#if 0
	// can we hijack underlying streambuf to fill our buffer directly?
	streambuf *sb = m_source->rdbuf();
	// cout << "got underflow streambuf at " << (void*)sb << endl;
#else
	m_source->clear();
	m_source->seekg(m_offset + m_tell);
	len = m_source->read(base(), len).gcount();
#endif
	if (len == 0) {
		setstate(m_source->rdstate());
		setg(0, 0, 0);
		return EOF;
	}
	m_tell += len;
	setg(base(), base(), base() + len);
	return (unsigned char) *gptr();
}

streampos substream::seekoff(streamoff off, ios::seekdir from, int which)
{
	streampos here = m_tell - in_avail();
	switch (int(from)) {
	case ios::beg:
		here = off;
		break;
	case ios::cur:
		// fast-path for tellg
		if (off == 0) return here;
		here += off;
		break;
	case ios::end:
		here = m_length + off;
		break;
	}
	// since we do a lot of short seeks, we try to optimize
	// seeks that are still within our current buffer
	streampos my_tell = m_tell, ediff = egptr() - eback();
	if (here < my_tell && here >= my_tell - ediff) {
		// new position is within buffer, adjust pointer
		setg(eback(), egptr() - (m_tell - here), egptr());
	} else {
		// new position is outside buffer, force underflow
		m_tell = here, setg(0, 0, 0);
	}
	return here;
}

int substream::sync(void)
{
	m_tell -= in_avail();
	setg(0, 0, 0);
	return 0;
}
