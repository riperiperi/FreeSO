#include "cfp.h"
#include "crack.h"
#include <iostream>
#include <fstream>
using std::cout;
using std::endl;

static bool s_initialized = false;
static float s_table[254];
const static double K = 3.9676e-10;

static inline void init_defaults(void)
{
	// from pseudocode due to Don Hopkins
	// calculate in double precision for maximum
	// accuracy then store as a float
	const int tblSize = 253;
	const int halfTbl = (tblSize - 1)/2;
	for (int i = 0; i < halfTbl; ++i) {
		double h = i - halfTbl;
		double m = K * h * h * h * h;
		s_table[i] = -m;
		s_table[252-i] = m;
	}
	// s_table[halfTbl] init to zero by system
	s_initialized = true;
}

void simCFP::init(std::istream *s, int offsets, int rotations)
{
	m_offsets = offsets;
	m_rotations = rotations;
	crackLittle in(s);
	if (s->fail()) return;
	if (!s_initialized) init_defaults();
	// can parse this format, but can't do anything
	// with it until the table values are known.
	m_off_x = new float[3*offsets + 4*rotations];
	m_off_y = m_off_x + offsets;
	m_off_z = m_off_y + offsets;
	m_rot_w = m_off_z + offsets;
	m_rot_x = m_rot_w + rotations;
	m_rot_y = m_rot_x + rotations;
	m_rot_z = m_rot_y + rotations;
	float *fp = m_off_x, f;
	while (!in.isEOF()) {
		int type = in.readByte();
		switch (type) {
		case 0xFF:	// singleton value
			*fp++ = f = in.readFloat();
			break;
		case 0xFE: {	// zero-relative repeat count
			int l = in.readShort();
			for (int i = 0; i <= l; ++i) *fp++ = f;
			} break;
		default:	// delta table value
			#if DebugPrint == 1
				*fp++ = (f = s_table[type]);
			#else
				*fp++ = (f += s_table[type]);
			#endif
			break;
		}
	}
#if DebugPrint
	if (fp != m_rot_z + rotations) {
		cout << "didn't come out even" << endl;
	}
#endif
	//in.dump();
}

simCFP::simCFP(char *file, int offsets, int rotations)
:	m_off_x(0)
{
	init(new std::ifstream(file), offsets, rotations);
}

simCFP::~simCFP(void)
{
	delete[] m_off_x;
}
