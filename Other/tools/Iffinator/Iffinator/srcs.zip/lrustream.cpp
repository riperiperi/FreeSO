#include "lrustream.h"
using namespace std;

inline LRU::_entry::_entry(void) : m_indir(0) { }

LRU::_indir::_indir(LRU &base, const char *name)
:	istream(this), ios(this), m_base(base), m_real(0), m_tell(0)
{
	// m_name is const char, so we use this
	// indirection when creating the copy
	char *t = new char[strlen(name) + 1];
	::strcpy(t, name);
	m_name = t;
	init(this);
}
LRU::_indir::~_indir(void)
{
	if (m_real != 0) {
		// break the association
		m_real->m_indir = 0;
		m_real->close();
		if (m_real->m_prev != 0) {
			// if not already first, move to head of cache
			m_real->m_prev->m_next = m_real->m_next;
			if (m_real->m_next != 0) {
				m_real->m_next->m_prev = m_real->m_prev;
			} else {
				m_base.m_tail = m_real->m_prev;
			}
			m_real->m_prev = 0, m_real->m_next = m_base.m_head;
			m_base.m_head->m_prev = m_real, m_base.m_head = m_real;
		}
	}
	delete[] m_name;
}

#if 0
int LRU::_indir::overflow(int x)
{
	// put is exhausted; provide new output area
	// only support input (for now?)
	return EOF;
}
#endif

int LRU::_indir::underflow(void)
{
	// get is exhausted; provide more input
	m_base.assign_entry(*this);
	if (base() == 0) {	// no current allocation
		if (allocate() == EOF) return EOF;
	} else {
		if (in_avail()) return *(unsigned char *)gptr();
	}
	m_real->clear();
	m_real->seekg(m_tell);
	int len = m_real->read(base(), blen()).gcount();
	if (len == 0) {
		setstate(m_real->rdstate());
		setg(0, 0, 0);
		return EOF;
	}
	m_tell += len;
	setg(base(), base(), base() + len);
	return *(unsigned char *)gptr();
}

streampos LRU::_indir::seekoff(streamoff off,
			       ios::seekdir from,
			       ios::openmode which)
{
	streampos here = m_tell - streamoff(in_avail());
	switch (int(from)) {
	case ios::beg:
		here = off;
		break;
	case ios::cur:
		// fast-path for tellg
		if (off == 0) return here;
		here += off;
		break;
	case ios::end:
		m_base.assign_entry(*this);
		here = m_real->seekg(off, from).tellg();
		break;
	}
	// since we do a lot of short seeks, we try to optimize
	// seeks that are still within our current buffer
	streampos my_tell = m_tell, ediff = egptr() - eback();
	if (here < my_tell && here >= my_tell - ediff) {
		// new position is within buffer, adjust pointer
		setg(eback(), egptr() - (m_tell - here), egptr());
	} else {
		// new position is outside buffer, force underflow
		m_tell = here, setg(0, 0, 0);
	}
	return here;
}

int LRU::_indir::sync(void)
{
	m_tell -= in_avail();
	setg(0, 0, 0);
	return 0;
}

void LRU::assign_entry(LRU::_indir &here)
{
	_entry *p = here.m_real;
	if (p != 0) {
		// active entry; move to tail of LRU list
		if (p->m_next == 0) return;	// already at tail
		p->m_next->m_prev = p->m_prev;
		if (p->m_prev != 0) {
			p->m_prev->m_next = p->m_next;
		} else {
			m_head = p->m_next;
		}
		p->m_prev = m_tail, p->m_next = 0;
		m_tail->m_next = p, m_tail = p;
		return;
	}
	p = m_head, m_head = p->m_next, m_head->m_prev = 0;
	if (p->m_indir != 0) {
		// terminate prior association and close file
		p->m_indir->m_tell = p->tellg();
//cerr << "closing " << p->m_indir->m_name << " at " << p->m_indir->m_tell << " for " << here.m_name << " at " << here.m_tell << endl;
		p->m_indir->m_real = 0;
		p->m_indir = 0;
		p->close();
	}
	// create new association and open file to correct spot
	p->m_indir = &here, here.m_real = p;
	p->open(here.m_name, ios::in);
	p->seekg(here.m_tell);
	// put at end of LRU list
	p->m_prev = m_tail, p->m_next = 0;
	m_tail->m_next = p, m_tail = p;
}

LRU::LRU(void)
{
	(m_head = &m_cache[0])->m_prev = 0;
	for (int i = 1; i < cache_size; ++i) {
		m_cache[i - 1].m_next = &m_cache[i];
		m_cache[i].m_prev = &m_cache[i - 1];
	}
	(m_tail = &m_cache[cache_size-1])->m_next = 0;
}

LRU::~LRU(void)
{
}
