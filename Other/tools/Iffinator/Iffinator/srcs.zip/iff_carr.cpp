#include "iff_carr.h"
#include "crack.h"
#include <iostream>

inline simIFF_CARR::Job::Job(void)
:	m_name(0), m_male(0), m_fem(0), m_uni(0), m_unknown(0)
{ }
inline simIFF_CARR::Job::~Job(void)
{
	delete[] m_name;
	delete[] m_male;
	delete[] m_fem;
	delete[] m_uni;
	delete[] m_unknown;
}

// CARR resource format
simIFF_CARR::simIFF_CARR(std::istream *s)
:	m_name(0), m_jobs(0)
{
	crackLittle in(s);
	if (in.readInt() != 0) return;
	if (in.readInt() != 0) return;
	if (in.readInt() != (((((('C'<<8)|'A')<<8)|'R')<<8)|'R')) return;
	m_unknown = in.s()->get();
	m_name = in.readEvenString();
	m_levels = in.getField();
	m_jobs = new Job[m_levels];
	for (int lvl = 0; lvl < m_levels; ++lvl) {
		Job *p = m_jobs + lvl;
		p->m_friends = in.getField();
		p->m_cooking = in.getField();
		p->m_mechanical = in.getField();
		p->m_charisma = in.getField();
		p->m_body = in.getField();
		p->m_logic = in.getField();
		p->m_creativity = in.getField();
		p->m_unknown1 = in.getField();
		p->m_unknown2 = in.getField();
		p->m_unknown3 = in.getField();
		p->m_hunger = in.getField();
		p->m_comfort = in.getField();
		p->m_hygiene = in.getField();
		p->m_bladder = in.getField();
		p->m_energy = in.getField();
		p->m_fun = in.getField();
		p->m_social = in.getField();
		p->m_salary = in.getField();
		p->m_start = in.getField();
		p->m_end = in.getField();
		p->m_car = in.getField();
		in.flushField();
		p->m_name = in.readEvenString();
		p->m_male = in.readEvenString();
		p->m_fem = in.readEvenString();
		p->m_uni = in.readEvenString();
		p->m_unknown = in.readEvenString();
	}
	// in.dump();
}

simIFF_CARR::~simIFF_CARR()
{
	delete[] m_name;
	delete[] m_jobs;
}
