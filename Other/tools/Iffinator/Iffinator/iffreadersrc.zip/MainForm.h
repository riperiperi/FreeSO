//---------------------------------------------------------------------------

#ifndef MainFormH
#define MainFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "ApOpenDlg.hpp"
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include "ApSaveDlg.hpp"
#include <AppEvnts.hpp>
#include "CSPIN.h"
#include <MPlayer.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TIFFForm : public TForm
{
__published:	// IDE-managed Components
        TApOpenDialog *OpenDlg;
        TPanel *Panel1;
        TListBox *TypeList;
        TSplitter *Splitter1;
        TSplitter *Splitter2;
        TPanel *Panel2;
        TMemo *TypeDetail;
        TButton *Button2;
        TApSaveDialog *SaveDlg;
        TPanel *Panel3;
        TButton *Button1;
        TCSpinEdit *SprNo;
        TLabel *SprLabel;
        TLabel *DGRPLabel;
        TCSpinEdit *DGRPNo;
        TLabel *Spr1Label;
        TRadioButton *Sprite;
        TRadioButton *Alpha;
        TRadioButton *ZBuffer;
        TCSpinEdit *Spr1No;
        TPanel *Panel4;
        TStringGrid *PreviewText;
        TImage *PreviewImage;
        TButton *SaveBmp;
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall TypeListClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall PreviewImageMouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall SprNoChange(TObject *Sender);
        void __fastcall DGRPNoChange(TObject *Sender);
        void __fastcall Spr1NoChange(TObject *Sender);
        void __fastcall SaveBmpClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TIFFForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TIFFForm *IFFForm;
//---------------------------------------------------------------------------
#endif
