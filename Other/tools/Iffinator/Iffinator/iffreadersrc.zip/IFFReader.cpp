//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("IFFReader.res");
USEFORM("MainForm.cpp", IFFForm);
USE("math.h", File);
USE("Convert.h", File);
USE("..\..\includes\iff.h", File);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TIFFForm), &IFFForm);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
