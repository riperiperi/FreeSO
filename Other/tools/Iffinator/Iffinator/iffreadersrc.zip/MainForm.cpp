//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainForm.h"
#include "vector.h"
#include "iff.h"
#include "jpeg.hpp"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ApOpenDlg"
#pragma link "ApSaveDlg"
#pragma link "CSPIN"
#pragma resource "*.dfm"
TIFFForm *IFFForm;
//---------------------------------------------------------------------------
__fastcall TIFFForm::TIFFForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

vector<CIFFType> IFFTypes;
TStrings *FileInfo = new TStringList();
AnsiString FileName, PreviewType;
CSPR2Chunk CurSprite;
CDGRPChunk CurDGRP;

typedef struct {
  TLogPalette *lpal;
  TPaletteEntry dummy[256];
} LogPal;

void __fastcall TIFFForm::Button1Click(TObject *Sender)
{
//------------Initialization------------
if (OpenDlg->Execute() == false)
        {return;}

TFileStream *IFFFile = new TFileStream(OpenDlg->FileName, fmOpenRead | fmShareDenyWrite);
TypeDetail->Lines->Clear();
TypeDetail->Lines->Append("--File--");
TypeDetail->Lines->Append("File Name: " + OpenDlg->FileName);
TypeDetail->Lines->Append("Size: " + IntToStr(IFFFile->Size) + " bytes (" + IntToStr(IFFFile->Size/1024) + " Kb)");
char *Buffer;
AnsiString TempStr;

//Get version no
IFFFile->Seek(9, soFromBeginning);
Buffer = new char[4];
TempStr.SetLength(3);
TempStr = "";
IFFFile->Read(Buffer, 3);
TempStr = Buffer;
TempStr.SetLength(3); //Last byte is 0-byte
TypeDetail->Lines->Append("IFF Version: " + TempStr);

TypeDetail->Lines->Append("");
TypeDetail->Lines->Append("--Header--");

//------------Header------------

//Get header
delete Buffer;
Buffer = new char[35];
TempStr.SetLength(34);
TempStr = "";
IFFFile->Seek(0, soFromBeginning);
IFFFile->Read(Buffer, 35);
TempStr = Buffer;
TempStr.SetLength(34); //Last byte is 0-byte
if (TempStr != "IFF FILE 2.5:TYPE FOLLOWED BY SIZE")
        {
        //Invalid file
        return;
        }
//valid file - parse on filename
FileName = OpenDlg->FileName;
IFFForm->Caption = FileName + " - IFF Reader";
TypeDetail->Lines->Append("Header 1: " + TempStr);
delete Buffer;
TempStr.SetLength(25);
TempStr = "";
Buffer = new char[25];
IFFFile->Read(Buffer, 25);
TempStr = Buffer;
TempStr.SetLength(25);
delete Buffer;
Buffer = new char[4];
IFFFile->Read(Buffer, 4);
//Check if there's a Resource map
if (Buffer[0] == '9' && Buffer[1] == '9' && Buffer[2] == '6' && Buffer[3] == 0x00)
        {
        TypeDetail->Lines->Append("Header 2: " + TempStr + "996");
        //No resource map
        TypeDetail->Lines->Append("");
        TypeDetail->Lines->Append("--Resource Map Not available--");
        }
else
        {
        TypeDetail->Lines->Append("Header 2: " + TempStr);
        //------------Resource Map------------
        TypeDetail->Lines->Append("");
        TypeDetail->Lines->Append("--Resource Map--");
        int RSMPOffset = HexToInt(Buffer, 4);
        TypeDetail->Lines->Append("Offset: "  + IntToStr(RSMPOffset));

        //Now go to RSMP, get types etc.
        IFFFile->Seek(RSMPOffset, soFromBeginning);

        delete Buffer;
        TempStr.SetLength(4);
        TempStr = "";
        Buffer = new char[4];
        IFFFile->Read(Buffer, 4);
        TempStr = Buffer;
        TempStr.SetLength(4);
        TypeDetail->Lines->Append("Type: " + TempStr);

        delete Buffer;
        Buffer = new char[4];
        IFFFile->Read(Buffer, 4);
        int RSMPSize = HexToInt(Buffer, 4);
        TypeDetail->Lines->Append("Size: " + IntToStr(RSMPSize));

        delete Buffer;
        Buffer = new char[4];
        IFFFile->Read(Buffer, 4);
        TypeDetail->Lines->Append("ID: " + IntToStr(HexToInt(Buffer, 2)));

        delete Buffer;
        TempStr.SetLength(64);
        TempStr = "";
        Buffer = new char[64];
        IFFFile->Read(Buffer, 64);
        TempStr = Buffer;
        TempStr.SetLength(64);
        TypeDetail->Lines->Append("Label: " + TempStr);

        delete Buffer;
        TempStr.SetLength(8);
        TempStr = "";
        Buffer = new char[8];
        IFFFile->Read(Buffer, 8);
        TempStr = Buffer;
        TempStr.SetLength(8);
        TypeDetail->Lines->Append("Unknown 1: " + TempStr);

        delete Buffer;
        TempStr.SetLength(4);
        TempStr = "";
        Buffer = new char[4];
        IFFFile->Read(Buffer, 4);
        TempStr = Buffer;
        TempStr.SetLength(4);
        TypeDetail->Lines->Append("Inverted Type: " + TempStr + " (=" + InvString(TempStr) + ")");

        delete Buffer;
        TempStr.SetLength(4);
        TempStr = "";
        Buffer = new char[4];
        IFFFile->Read(Buffer, 4);
        TempStr = Buffer;
        TempStr.SetLength(4);
        TypeDetail->Lines->Append("Unknown 2: " + TempStr);

        delete Buffer;
        Buffer = new char[4];
        IFFFile->Read(Buffer, 4);
        int TypeCount = HexCharToInt(Buffer, 4);
        TypeDetail->Lines->Append("Amount of Types: " + IntToStr(TypeCount));
        }

//------------Clean up and Close------------
delete Buffer;
//int iHandle = IFFFile->Handle;
//FileClose(iHandle);
delete IFFFile;

TypeList->Items->Clear();
TypeList->Items->Append("*File*");
FileInfo->Assign(TypeDetail->Lines);
int CurSize;
IFFTypes = GetIFFTypes(FileName);

//Update Types list
for (unsigned int i=0; i < IFFTypes.size(); i++)
        {
        TypeList->Items->Append("#" + IntToStr(IFFTypes[i].ID) + ": \"" + IFFTypes[i].Label + "\" (" + IFFTypes[i].Type + ")");
        }

PreviewImage->Hide();
PreviewText->Hide();
SprLabel->Hide();
SprNo->Hide();
Spr1Label->Hide();
Spr1No->Hide();
DGRPLabel->Hide();
DGRPNo->Hide();
Sprite->Hide();
Alpha->Hide();
ZBuffer->Hide();
SaveBmp->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TIFFForm::TypeListClick(TObject *Sender)
{
char *Buffer;
int ID, DataSize;
ID = TypeList->ItemIndex - 1;

if (TypeList->ItemIndex == 0)
        {
        TypeDetail->Lines->Assign(FileInfo);
        Button2->Enabled = false;
        PreviewImage->Hide();
        }
else
        {
        TypeDetail->Clear();
        TypeDetail->Lines->Append("--Resource--");
        TypeDetail->Lines->Append("Type: " + IFFTypes[ID].Type);
        TypeDetail->Lines->Append("Type ID: " + IntToStr(IFFTypes[ID].TypeNo));
        TypeDetail->Lines->Append("Resource ID: " + IntToStr(IFFTypes[ID].ID));
        TypeDetail->Lines->Append("Label: " + IFFTypes[ID].Label);
        TypeDetail->Lines->Append("Offset: " + IntToStr(IFFTypes[ID].Offset));
        TypeDetail->Lines->Append("Size: " + IntToStr(IFFTypes[ID].Size));
        TypeDetail->Lines->Append("Data Offset: " + IntToStr(IFFTypes[ID].DataOffset));
        TypeDetail->Lines->Append("Data Size: " + IntToStr(IFFTypes[ID].DataSize));
        Button2->Enabled = true;
        
        if (IFFTypes[ID].Type.UpperCase() == "BMP_" || IFFTypes[ID].Type.UpperCase() == "FBMP")
                {
                PreviewType = "BMP";
                TMemoryStream *ImgStream = new TMemoryStream();
                ImgStream->Write(IFFTypes[ID].Data, IFFTypes[ID].DataSize);
                ImgStream->Seek(0, soFromBeginning);
                PreviewImage->Picture->Bitmap->LoadFromStream(ImgStream);
                PreviewImage->Show();
                SprLabel->Hide();
                SprNo->Hide();
                Spr1Label->Hide();
                Spr1No->Hide();
                DGRPLabel->Hide();
                DGRPNo->Hide();
                PreviewImage->Transparent = true;
                TypeDetail->Lines->Append("-------------------");
                TypeDetail->Lines->Append("BMP Info:");
                TypeDetail->Lines->Append("Width: " + IntToStr(PreviewImage->Picture->Width));
                TypeDetail->Lines->Append("Height: " + IntToStr(PreviewImage->Picture->Height));
                PreviewText->Hide();
                Sprite->Hide();
                Alpha->Hide();
                ZBuffer->Hide();
                SaveBmp->Show();

                //Destroy open streams
                delete ImgStream;
                }

        else if (IFFTypes[ID].Type.UpperCase() == "SPR2")
                {
                PreviewType = "SPR2";
                CurSprite = ReadSPR2(FileName, IFFTypes[ID]);
                SprNo->MaxValue = CurSprite.SpriteCount;
                SprNo->MinValue = 1;
                if (SprNo->Value > SprNo->MaxValue)
                        {
                        SprNo->Value = 1;
                        }
                PreviewImage->Transparent = true;
                if (Sprite->Checked)
                        PreviewImage->Picture->Bitmap->Assign(CurSprite.Sprites[SprNo->Value - 1].Sprite);
                else if (Alpha->Checked)
                        PreviewImage->Picture->Bitmap->Assign(CurSprite.Sprites[SprNo->Value - 1].Alpha);
                else if (ZBuffer->Checked)
                        PreviewImage->Picture->Bitmap->Assign(CurSprite.Sprites[SprNo->Value - 1].ZBuffer);                
                SprNo->Show();
                SprLabel->Show();
                Spr1No->Hide();
                Spr1Label->Hide();
                DGRPLabel->Hide();
                DGRPNo->Hide();
                PreviewImage->Show();
                TypeDetail->Lines->Append("-------------------");
                TypeDetail->Lines->Append("SPR2 Info:");
                TypeDetail->Lines->Append("Width: " + IntToStr(PreviewImage->Picture->Width));
                TypeDetail->Lines->Append("Height: " + IntToStr(PreviewImage->Picture->Height));
                TypeDetail->Lines->Append("Palette used: " + IntToStr(CurSprite.PaletteID));
                PreviewText->Hide();
                Sprite->Show();
                Alpha->Show();
                ZBuffer->Show();
                SaveBmp->Show();
                }

        else if (IFFTypes[ID].Type.UpperCase() == "DGRP")
                {
                PreviewType = "DGRP";
                CurDGRP = ReadDGRP(FileName, IFFTypes[ID]);
                DGRPNo->MaxValue = CurDGRP.DGRPCount;
                DGRPNo->MinValue = 1;
                if (DGRPNo->Value > DGRPNo->MaxValue)
                        {
                        DGRPNo->Value = 1;
                        }
                PreviewImage->Transparent = true;
                PreviewImage->Picture->Bitmap->Assign(CurDGRP.Groups[DGRPNo->Value - 1].GrpImage);

                SprNo->Hide();
                SprLabel->Hide();
                Spr1No->Hide();
                Spr1Label->Hide();
                DGRPLabel->Show();
                DGRPNo->Show();
                Sprite->Hide();
                Alpha->Hide();
                ZBuffer->Hide();
                PreviewImage->Show();
                PreviewText->Hide();
                SaveBmp->Show();
                }

        else if (IFFTypes[ID].Type.UpperCase() == "SPR#")
                {
                PreviewType = "SPR#";
		int RequestedSprite=0; // first sprite is all we want

                int Version, SprCount, PaletteID, SprLoc;

                TMemoryStream *SPRData = new TMemoryStream();
                SPRData->Write(IFFTypes[ID].Data, IFFTypes[ID].DataSize);
                SPRData->Seek(0, soFromBeginning);

		SPRData->Read(&Version, 4); //504
                SPRData->Read(&SprCount, 4);
                SPRData->Read(&PaletteID, 4);

                Spr1No->MaxValue = SprCount;
                if (Spr1No->Value > Spr1No->MaxValue)
                        {Spr1No->Value = 1;}

                RequestedSprite = Spr1No->Value - 1;

                if ((Version != 504 && Version != 502 && Version != 505) || RequestedSprite >= SprCount)
                        {
                        PreviewImage->Hide();
                        return;
                        }

                SPRData->Seek(RequestedSprite*4, soFromCurrent);
                SPRData->Read(&SprLoc, 4);
                SPRData->Seek(SprLoc + 4, soFromBeginning);

                WORD Height, Width, PaltID;
                TColor PALT[256];                
                SPRData->Read(&Height, 2);
                SPRData->Read(&Width, 2);
                SPRData->Read(&PaltID, 2);

                CIFFType Palette = GetSingleType(FileName, "PALT", PaletteID);
                if (Palette.Type.UpperCase() != "PALT")
                        {
                        Palette = GetSingleType(FileName, "PALT", PaltID);
                        }
                if (Palette.Type.UpperCase() != "PALT")
                        {
                        //default palette ID = 4096 (?)
                        Palette = GetSingleType(FileName, "PALT", 4096);
                        }

                if (Palette.Type.UpperCase() != "PALT")
                        {
                        PreviewImage->Hide();
                        return;
                        }

                TMemoryStream *PaletteData = new TMemoryStream();
                PaletteData->SetSize(Palette.DataSize);
                PaletteData->Clear();
                PaletteData->Write(Palette.Data, Palette.DataSize);

                PaletteData->Seek(16, soFromBeginning); // You now ignore Version, Count, Unused and Unused (4 x 4 bytes)
                char *Buffer;
                for (int j = 0; j < 256; j++)
                        {
                        Buffer = new char[3];
                        PaletteData->Read(Buffer, 3);
                        PALT[j] = RGB(Buffer[0], Buffer[1], Buffer[2]);
                        delete Buffer;
                        }
                delete PaletteData;

                Graphics::TBitmap *Image = new Graphics::TBitmap;
                int X, Y, LineWidth;
                X = 0;
                Y = 0;
                Image->Height = Height;
                Image->Width = Width;
                LineWidth = Width;
                Image->Canvas->Brush->Color = PALT[255];
                Image->Canvas->Pen->Color = PALT[255];
                Image->Canvas->Rectangle(0, 0, Width, Height);

                TStringList *SprTypes = new TStringList;
                SprTypes->Clear();

                while (SPRData->Position < SPRData->Size)
                        {
                        //Transparent = colour 255
                        BYTE opcode, data;
                        SPRData->Read(&opcode, 1);
                        SPRData->Read(&data, 1);
                        switch (opcode)
                        {
                        case 1: //transparent pixels
                                {
                                for (;data;data--)
                                        {
                                        Image->Canvas->Pixels[X][Y] = PALT[255];
                                        X++;
                                        }
                                break;
                                }

                        case 2:
                                {
                                BYTE Color;
                                SPRData->Read(&Color, 1);
                                for (;data;data--)
                                        {
                                        Image->Canvas->Pixels[X][Y] = PALT[Color];
                                        X++;
                                        }
                                break;
                                }

                        case 3: //pixels
                                {
                                for (;data;data--)
                                        {
                                        BYTE Pixel;
                                        SPRData->Read(&Pixel, 1);
                                        Image->Canvas->Pixels[X][Y] = PALT[Pixel];
                                        X++;
                                        }
                                break;
                                }

                        case 4: //New line
                                {
                                //Fill with transparency
                                for (;X < Width;X++)
                                        {
                                        Image->Canvas->Pixels[X][Y] = PALT[255];
                                        }
                                Y++; //next line
                                X = 0;
                                LineWidth = data;
                                }

                        case 5: //end of sprite
                                {
                                break;
                                }

                        case 9: //transparent rows
                                {
                                Image->Canvas->Rectangle(0, Y, Width, Y + data - 1);
                                X = 0;
                                Y = Y + data - 1;
                                }

                        default: //invalid
                                {
                                break;
                                }
                        }

                        //Alignment
                        SPRData->Seek(SPRData->Position&1, soFromCurrent);
                        SprTypes->Add(IntToStr(opcode));

                        if (opcode == 5)
                                {
                                break;
                                }
                        }

                PreviewImage->Picture->Assign(Image);
                PreviewImage->Picture->Bitmap->TransparentColor = PALT[255];
//                PreviewImage->Picture->SaveToFile("C:\\sprite.bmp");
                PreviewImage->Transparent = true;
                PreviewImage->Show();
                PreviewText->Hide();

                SprLabel->Hide();
                SprNo->Hide();
                Spr1Label->Show();
                Spr1No->Show();
                DGRPLabel->Hide();
                DGRPNo->Hide();
                Sprite->Hide();
                Alpha->Hide();
                ZBuffer->Hide();
                SaveBmp->Show();

                //Destroy open streams
                delete SPRData;
                }

        else if (IFFTypes[ID].Type.UpperCase() == "PALT")
                {
                PreviewType = "PALT";
                TMemoryStream *PaletteData = new TMemoryStream();
                PaletteData->Write(IFFTypes[ID].Data, IFFTypes[ID].DataSize);
                PaletteData->Seek(16, soFromBeginning);

                TColor PALT[256];
                for (int i = 0; i < 256; i++)
                        {
                        Buffer = new char[3];
                        PaletteData->Read(Buffer, 3);
                        PALT[i] = RGB(Buffer[0], Buffer[1], Buffer[2]);
                        delete Buffer;
                        }

                PreviewImage->Picture->Bitmap->Width = 256;
                PreviewImage->Picture->Bitmap->Height = 256;
                for (int i = 0; i < 16; i++)
                        {
                        for (int j = 0; j < 16; j++)
                                {
                                PreviewImage->Picture->Bitmap->Canvas->Brush->Color = PALT[(i*16)+j];
                                PreviewImage->Picture->Bitmap->Canvas->FillRect(Rect(j*16, i*16, (j*16) + 16, (i*16) + 16));
                                }
                        }

                PreviewImage->Transparent = false;
                PreviewImage->Show();
                PreviewText->Hide();
                SprLabel->Hide();
                SprNo->Hide();
                Spr1Label->Hide();
                Spr1No->Hide();
                DGRPLabel->Hide();
                DGRPNo->Hide();
                Sprite->Hide();
                Alpha->Hide();
                ZBuffer->Hide();
                SaveBmp->Show();
                }

        else if (IFFTypes[ID].Type.UpperCase() == "STR#" || IFFTypes[ID].Type.UpperCase() == "CTSS"
                 || IFFTypes[ID].Type.UpperCase() == "TTAS" || IFFTypes[ID].Type.UpperCase() == "FAMS"
                 || IFFTypes[ID].Type.UpperCase() == "UCHR")
                {
                bool CommonType, LanByte, Notes;
                char *Buffer;
                Buffer = new char[2];
                WORD StringCount;

                TStrings *STRStrings = new TStringList;
                TStrings *STRNotes = new TStringList;
                TStrings *STRNos = new TStringList;
                STRStrings->Text = "String";
                STRNotes->Text = "Note";
                STRNos->Text = "#";

                TMemoryStream *STRData = new TMemoryStream();
                STRData->Write(IFFTypes[ID].Data, IFFTypes[ID].DataSize);
                STRData->Seek(0, soFromBeginning);
                STRData->Read(Buffer, 2);

                if (Buffer[1] == -1 || Buffer[1] == 0xff)
                        {
                        CommonType = true;
                        LanByte = ~Buffer[0] & 2;
                        Notes = (~Buffer[0] & 1 || ~Buffer[0] & 2);
                        STRData->Read(&StringCount, 2);
                        }
                else
                        {
                        CommonType = false;
                        LanByte = true;
                        Notes = false;
                        StringCount = HexToInt(Buffer, 2);
                        }
                delete Buffer;

                for (int i = 0; i < StringCount; i++)
                        {
                        AnsiString Text, Note;
                        BYTE LanLen, LastChar;
                        int j = 0;
                        if (LanByte)
                                STRData->Read(&LanLen, 1);

                        do
                                {
                                STRData->Read(&LastChar, 1);
                                if (LastChar != 0x00)
                                        {
                                        Text.SetLength(Text.Length() + 1);
                                        Text[Text.Length()] = LastChar;
                                        }
                                j++;
                                }
                        while ((CommonType && LastChar != 0x00) || (!CommonType && j < LanLen));

                        if (CommonType && Notes)
                                {
                                do
                                        {
                                        STRData->Read(&LastChar, 1);
                                        if (LastChar != 0x00)
                                                {
                                                Note.SetLength(Note.Length() + 1);
                                                Note[Note.Length()] = LastChar;
                                                }
                                        }
                                while (LastChar != 0x00);
                                }

                        while (LastChar == 0x00 && STRData->Position < STRData->Size && CommonType)
                                {
                                STRData->Read(&LastChar, 1);
                                }

                        if (CommonType)
                                //go one byte back
                                STRData->Seek(-1, soFromCurrent);

                        STRStrings->Append(Text);
                        STRNotes->Append(Note);
                        STRNos->Append(IntToStr(i));
                        }

                PreviewText->RowCount = STRNos->Count;
                PreviewText->Cols[0]->Assign(STRNos);
                PreviewText->Cols[1]->Assign(STRStrings);
                PreviewText->Cols[2]->Assign(STRNotes);

                PreviewText->FixedCols = 1;
                if (PreviewText->RowCount <= 1)
                        {
                        PreviewText->RowCount = 2;
                        PreviewText->Cols[0]->Append("!");
                        PreviewText->Cols[1]->Append("No strings found in this chunk!");
                        PreviewText->Cols[2]->Append("");
                        }
                PreviewText->FixedRows = 1;
                SprLabel->Hide();
                SprNo->Hide();
                Spr1Label->Hide();
                Spr1No->Hide();
                DGRPLabel->Hide();
                DGRPNo->Hide();
                PreviewType = "STR#";
                PreviewImage->Hide();
                PreviewText->Show();
                Sprite->Hide();
                Alpha->Hide();
                ZBuffer->Hide();
                SaveBmp->Hide();
                }
        else if (IFFTypes[ID].Type.UpperCase() == "NBRS")
                {
                // Load neighbors thingy
                char *Buffer;
                Buffer = new char[4];
                WORD StringCount;

                TStrings *NBRSNames = new TStringList;
                TStrings *NBRSIDs = new TStringList;
                TStrings *NBRSNos = new TStringList;
                NBRSNames->Text = "Name";
                NBRSIDs->Text = "ID";
                NBRSNos->Text = "#";

                TMemoryStream *NBRSData = new TMemoryStream();
                NBRSData->Write(IFFTypes[ID].Data, IFFTypes[ID].DataSize);
                NBRSData->Seek(4, soFromBeginning);
                NBRSData->Read(Buffer, 4);
                NBRSData->Seek(4, soFromCurrent);

                DWORD CharCount;
                NBRSData->Read(&CharCount, 4);

                if (Buffer[0] == 0x3F)
                        NBRSData->Seek(32, soFromCurrent);
                delete Buffer;

                // Character number is NOT always accurate!!
//                for (int i = 0; i < (int)CharCount; i++)

                int i = 0;
                // Read 1 bit back at the end (because of 0x00 fillers)
                while (NBRSData->Position + 1 < NBRSData->Size)
                        {
                        // Unknown
                        NBRSData->Seek(8, soFromCurrent);
                        NBRSNos->Append(IntToStr(i++));

                        // Filename/NPC Name
                        char LastChar;
                        LastChar = 0xFF;
                        AnsiString CurName;
                        int j = 1;

                        while (LastChar != 0x00)
                                {
                                Buffer = new char[1];
                                NBRSData->Read(Buffer, 1);
                                LastChar = Buffer[0];
                                if (LastChar != 0x00)
                                        {
                                        CurName.SetLength(j);
                                        CurName[j] = LastChar;
                                        j++;
                                        }
                                delete Buffer;
                                }
                        NBRSNames->Append(CurName);

                        // Alignment
                        if (NBRSData->Position & 1)
                                NBRSData->Seek(1, soFromCurrent);

                        // 0x0000 0000 Unused/Unknown
                        NBRSData->Seek(4, soFromCurrent);

                        // Character data version/flags
                        Buffer = new char[4];
                        NBRSData->Read(Buffer, 4);
                        char Version;
                        Version = Buffer[0];
                        delete Buffer;

                        if (Version != 0x00)
                                {
                                // Unknown/Unused
                                NBRSData->Seek(4, soFromCurrent);

                                // Skills/Personality
                                NBRSData->Seek(34, soFromCurrent);

                                // Unused/Unknown/Extended interests?
                                NBRSData->Seek(54, soFromCurrent);

                                // Interests
                                NBRSData->Seek(20, soFromCurrent);

                                // Career Path
                                NBRSData->Seek(2, soFromCurrent);
                                // Promotion Level
                                NBRSData->Seek(2, soFromCurrent);

                                // Age + Unknown
                                NBRSData->Seek(4, soFromCurrent);

                                // Race
                                NBRSData->Seek(2, soFromCurrent);

                                // Ghost/NPC + Skin thing(?)
                                NBRSData->Seek(4, soFromCurrent);

                                // Skin thing 2 + Unknown
                                NBRSData->Seek(4, soFromCurrent);

                                // Gender + Unknown
                                NBRSData->Seek(4, soFromCurrent);

                                // Haunt Level (2) + Ghost (2)
                                NBRSData->Seek(4, soFromCurrent);

                                // Unknown
                                NBRSData->Seek(2, soFromCurrent);

                                // Unknown
                                NBRSData->Seek(4, soFromCurrent);

                                // Unused/Unknown
                                NBRSData->Seek(16, soFromCurrent);
                                }

                        // All versions again
                        // Relationship ID
                        NBRSData->Seek(2, soFromCurrent);

                        DWORD ID;
                        NBRSData->Read(&ID, 4);
                        NBRSIDs->Append(IntToHex((int)ID, 4));

                        // Unknown/Unused 0xFFFF FFFF
                        NBRSData->Seek(4, soFromCurrent);

                        // Amount of relationships
                        DWORD RelCount;
                        NBRSData->Read(&RelCount, 4);

                        // Relationship table
                        for (j = 0; j < (int)RelCount; j++)
                                {
                                // Unknown/Unused
                                NBRSData->Seek(4, soFromCurrent);

                                // Character ID
                                NBRSData->Seek(4, soFromCurrent);

                                // Amount of flags
                                DWORD Size;
                                NBRSData->Read(&Size, 4);

                                // Relationships etc
                                NBRSData->Seek((int)Size*4, soFromCurrent);
                                }

                        // Check fillers (0x00)
                        LastChar = 0x00;
                        while (LastChar == 0x00)
                                {
                                Buffer = new char[1];
                                NBRSData->Read(Buffer, 1);
                                LastChar = Buffer[0];
                                delete Buffer;
                                }
                        // 0x01 of next character read - go back to before that
                        NBRSData->Seek(-1, soFromCurrent);
                        }
                // Put details in list
                PreviewText->RowCount = NBRSNos->Count;
                PreviewText->Cols[0]->Assign(NBRSNos);
                PreviewText->Cols[1]->Assign(NBRSNames);
                PreviewText->Cols[2]->Assign(NBRSIDs);
                PreviewText->FixedCols = 1;
                if (PreviewText->RowCount <= 1)
                        {
                        PreviewText->RowCount = 2;
                        PreviewText->Cols[0]->Append("!");
                        PreviewText->Cols[1]->Append("No characters found in this chunk!");
                        PreviewText->Cols[2]->Append("");
                        }
                PreviewText->FixedRows = 1;
                SprLabel->Hide();
                SprNo->Hide();
                Spr1Label->Hide();
                Spr1No->Hide();
                DGRPLabel->Hide();
                DGRPNo->Hide();
                PreviewType = "STR#";
                PreviewImage->Hide();
                PreviewText->Show();
                Sprite->Hide();
                Alpha->Hide();
                ZBuffer->Hide();
                SaveBmp->Hide();
                }
        else
                {
                SprLabel->Hide();
                SprNo->Hide();
                Spr1Label->Hide();
                Spr1No->Hide();
                DGRPLabel->Hide();
                DGRPNo->Hide();
                PreviewType = "";
                PreviewImage->Hide();
                PreviewText->Hide();
                Sprite->Hide();
                Alpha->Hide();
                ZBuffer->Hide();
                SaveBmp->Hide();
                }
        }
}
//---------------------------------------------------------------------------

void __fastcall TIFFForm::FormCreate(TObject *Sender)
{
        Button2->Align = alBottom;
        Button2->Enabled = false;
        SaveBmp->Align = alBottom;
        PreviewText->ColWidths[0] = 20;
        PreviewText->ColWidths[1] = 150;
        PreviewText->ColWidths[2] = 150;
}
//---------------------------------------------------------------------------

void __fastcall TIFFForm::Button2Click(TObject *Sender)
{
if (SaveDlg->Execute() == true)
        {
        if (FileExists(SaveDlg->FileName) == true)
                {
                if (!DeleteFile(SaveDlg->FileName))
                        {
                        MessageDlg("Error Deleting existing file!", mtError, TMsgDlgButtons() << mbOK, 0);
                        return;
                        }
                }
        TFileStream *DataFile = new TFileStream(SaveDlg->FileName, fmCreate | fmShareExclusive);
//        DataFile->Size = IFFTypes[TypeList->ItemIndex].DataSize;
        DataFile->Seek(0, soFromBeginning);
        DataFile->Write(IFFTypes[TypeList->ItemIndex - 1].Data, IFFTypes[TypeList->ItemIndex - 1].DataSize);

        //Delete streams etc.
//        int Handle = DataFile->Handle;
        delete DataFile;
//        FileClose(Handle);
        }
}
//---------------------------------------------------------------------------

void __fastcall TIFFForm::PreviewImageMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
        if (PreviewType == "PALT")
                {
                int /*X, Y, */ColorNo;
                /*X = HintInfo.CursorPos.x;
                Y = HintInfo.CursorPos.y;
                */
                AnsiString HintStr;
                ColorNo = (X/16) + (Y/16)*16;
                HintStr = "Color: " + IntToStr(ColorNo);
                HintStr = HintStr + "\nRed: " + IntToStr((PreviewImage->Canvas->Pixels[X][Y] & 255));
                HintStr = HintStr + "\nGreen: " + IntToStr((PreviewImage->Canvas->Pixels[X][Y] >> 8 & 255));
                HintStr = HintStr + "\nBlue: " + IntToStr((PreviewImage->Canvas->Pixels[X][Y] >> 16 & 255));
                PreviewImage->Hint = HintStr;

                if (X >= PreviewImage->Picture->Width || Y >= PreviewImage->Picture->Height)
                        {
                        Application->HideHint();
                        }
                else
                        {
                        TPoint CurPos;
                        CurPos.x = X + PreviewImage->Left + IFFForm->Left + 16;
                        CurPos.y = Y + PreviewImage->Top + Panel3->Height + IFFForm->Top + 24;
                        Application->ActivateHint(CurPos);
                        }
                }
}
//---------------------------------------------------------------------------

void __fastcall TIFFForm::SprNoChange(TObject *Sender)
{
if (SprNo->Text != "")
        {
        if (SprNo->Value > SprNo->MaxValue)
                {
                SprNo->Value = SprNo->MaxValue;
                }
        if (SprNo->Value < SprNo->MinValue)
                {
                SprNo->Value = SprNo->MinValue;
                }
        if (Sprite->Checked)
                PreviewImage->Picture->Bitmap->Assign(CurSprite.Sprites[SprNo->Value - 1].Sprite);
        else if (Alpha->Checked)
                PreviewImage->Picture->Bitmap->Assign(CurSprite.Sprites[SprNo->Value - 1].Alpha);
        else if (ZBuffer->Checked)
                PreviewImage->Picture->Bitmap->Assign(CurSprite.Sprites[SprNo->Value - 1].ZBuffer);
        }
}
//---------------------------------------------------------------------------

void __fastcall TIFFForm::DGRPNoChange(TObject *Sender)
{
if (DGRPNo->Text != "")
        {
        if (DGRPNo->Value > DGRPNo->MaxValue)
                {
                DGRPNo->Value = DGRPNo->MaxValue;
                }
        if (DGRPNo->Value < DGRPNo->MinValue)
                {
                DGRPNo->Value = DGRPNo->MinValue;
                }
        PreviewImage->Picture->Bitmap->Assign(CurDGRP.Groups[DGRPNo->Value - 1].GrpImage);
//        ShowMessage(IntToStr(CurDGRP.Groups[DGRPNo->Value - 1].flags[1]));
        }
}
//---------------------------------------------------------------------------

void __fastcall TIFFForm::Spr1NoChange(TObject *Sender)
{
if (Spr1No->Text != "")
        {
        if (Spr1No->Value > Spr1No->MaxValue)
                {
                Spr1No->Value = Spr1No->MaxValue;
                }
        if (Spr1No->Value < Spr1No->MinValue)
                {
                Spr1No->Value = Spr1No->MinValue;
                }
        PreviewImage->Picture->Bitmap->Assign(CurSprite.Sprites[Spr1No->Value - 1].Sprite);
        }
}
//---------------------------------------------------------------------------

void __fastcall TIFFForm::SaveBmpClick(TObject *Sender)
{
SaveDlg->Filter = "Windows/OS2 Bitmap (*.bmp)|*.bmp";
if (SaveDlg->Execute())
        {
        PreviewImage->Picture->SaveToFile(SaveDlg->FileName);
        }
SaveDlg->Filter = "";        
}
//---------------------------------------------------------------------------

